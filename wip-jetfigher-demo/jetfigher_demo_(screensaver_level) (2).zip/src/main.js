// Main entry point for the dogfight game
// This is a temporary shim that imports from game-main.js
// TODO: Split game-main.js and move logic here

// Import game-main.js (still at root for now)
import * as GameMain from '../game-main.js';

// Re-export the public API
export const startGame = GameMain.startGame;
export const stopGame = GameMain.stopGame;
