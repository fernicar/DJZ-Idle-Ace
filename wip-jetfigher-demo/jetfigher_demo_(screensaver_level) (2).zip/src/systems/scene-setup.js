// Scene setup and terrain generation
// Initializes Three.js scene, lights, cameras, and procedural terrain

// Create procedural terrain - coastal landscape with water-colored low areas
function createIslands(scene) {
  // Create a coastal terrain - land transitions to water-colored flat areas
  // Sun is at (300, 200, 100), so put water area on the positive X side (right)
  // Land will be on the negative X side (left)

  // Main terrain - single surface from land to water
  const terrainGeometry = new THREE.PlaneGeometry(10000, 10000, 150, 150);
  const terrainMaterial = new THREE.MeshStandardMaterial({
    color: 0x4a7c59, // Green land (will be overridden by vertex colors)
    flatShading: false,
    roughness: 0.8,
    metalness: 0.2,
    vertexColors: true
  });

  const terrain = new THREE.Mesh(terrainGeometry, terrainMaterial);

  // Position much deeper - well below the dogfight
  terrain.position.set(0, -450, 0);
  terrain.rotation.x = -Math.PI / 2;

  // Create coastal terrain with land-to-water transition
  const positions = terrain.geometry.attributes.position;
  const colors = [];

  for (let i = 0; i < positions.count; i++) {
    const x = positions.getX(i);
    const y = positions.getY(i);

    // Organic coastline with variation - not a straight line
    // Base coastline position varies with Y coordinate
    const coastlineVariation = Math.sin(y * 0.003) * 300 + Math.cos(y * 0.007) * 150 + Math.sin(y * 0.015) * 80;
    const coastlineX = 1000 + coastlineVariation;
    const distanceFromCoast = x - coastlineX;

    let height = 0;
    let color;

    if (x < coastlineX - 500) {
      // LAND AREA (left side, away from coast)
      // Multi-layered terrain with mountains and valleys
      height = 20 + Math.sin(x * 0.002) * 15;
      height += Math.cos(y * 0.0015) * 12;
      height += Math.sin(x * 0.005 + y * 0.005) * 10;
      height += Math.cos(x * 0.008 - y * 0.006) * 7;
      height += Math.sin(x * 0.015) * 5;
      height += Math.cos(y * 0.012) * 4;
      height += (Math.random() - 0.5) * 3;
      height = Math.max(height, 0);

      // Color based on height - more saturated, less pastel
      if (height > 45) {
        color = new THREE.Color(0x6b5d48); // Mountain peaks - darker brown
      } else if (height > 30) {
        color = new THREE.Color(0x556b3a); // High elevation - olive green
      } else if (height > 15) {
        color = new THREE.Color(0x2d6b2d); // Mid elevation - forest green
      } else {
        color = new THREE.Color(0x1a5c1a); // Low elevation - dark forest green
      }
    } else if (x < coastlineX) {
      // COASTAL TRANSITION (beach area with natural variation)
      const transitionWidth = 500 + Math.sin(y * 0.01) * 100; // Variable beach width
      const transitionFactor = (x - (coastlineX - transitionWidth)) / transitionWidth;

      height = 20 * (1 - transitionFactor);
      height += Math.sin(x * 0.01 + y * 0.008) * 3 * (1 - transitionFactor);
      height += Math.cos(y * 0.02) * 2 * (1 - transitionFactor);
      height = Math.max(height, 0);

      // Sandy beach color - more saturated
      color = new THREE.Color(0xa89968).lerp(new THREE.Color(0xc4b896), transitionFactor * 0.5);
    } else {
      // WATER AREA (right side, toward sun) - FLAT
      height = 0; // Completely flat water surface

      // Water blue color - more saturated, deeper blues
      const distVariation = Math.sin(x * 0.005 + y * 0.005) * 0.1;
      if (distVariation > 0.05) {
        color = new THREE.Color(0x1a7fb8); // Saturated light blue
      } else if (distVariation > 0) {
        color = new THREE.Color(0x0d6ba0); // Saturated medium blue
      } else if (distVariation > -0.05) {
        color = new THREE.Color(0x065788); // Saturated standard blue
      } else {
        color = new THREE.Color(0x004370); // Deep saturated blue
      }
    }

    positions.setZ(i, height);
    colors.push(color.r, color.g, color.b);
  }

  positions.needsUpdate = true;
  terrain.geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  terrain.geometry.computeVertexNormals();

  scene.add(terrain);
}

export function setupScene(container) {
  // Clear only the WebGL canvas if it exists, preserve the cameraModeIndicator and radar canvases
  const existingCanvas = container.querySelector('canvas:not(#panoramicRadar):not(#radialRadar)');
  if (existingCanvas) {
    existingCanvas.remove();
  }

  const scene = new THREE.Scene();
  // Sky horizon color is vec3(0.5, 0.65, 0.85) = RGB(127, 166, 217) = 0x7FA6D9
  scene.background = new THREE.Color(0x7FA6D9); // Match sky horizon color
  scene.fog = new THREE.Fog(0x7FA6D9, 500, 30000); // Fog matches sky horizon: near=500, far=30000

  const camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 100000);
  camera.position.set(0, 60, 150);

  const renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  container.appendChild(renderer.domElement);

  // Lights
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
  scene.add(ambientLight);

  const dirLight = new THREE.DirectionalLight(0xfff4e6, 1.8);
  dirLight.position.set(300, 200, 100);
  scene.add(dirLight);

  // Add procedural sky with better colors - matched to terrain size
  const sky = new THREE.Mesh(
    new THREE.SphereGeometry(5000, 32, 15),
    new THREE.ShaderMaterial({
      uniforms: {
        sunPosition: { value: new THREE.Vector3(300, 200, 100) },
        time: { value: 0 }
      },
      vertexShader: `
        varying vec3 vWorldPosition;
        void main() {
          vec4 worldPosition = modelMatrix * vec4(position, 1.0);
          vWorldPosition = worldPosition.xyz;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 sunPosition;
        varying vec3 vWorldPosition;

        void main() {
          // Adjust for sphere position offset (-450 in Y) to get proper horizon at y=0
          // Since sphere is at y=-450, we need to shift world position up by 450
          vec3 adjustedPosition = vWorldPosition + vec3(0.0, 250.0, 0.0);
          vec3 direction = normalize(adjustedPosition);
          float sunAngle = dot(direction, normalize(sunPosition));

          // Enhanced sky gradient - darker, more saturated
          float elevation = direction.y;
          vec3 zenithColor = vec3(0.01, 0.03, 0.7);      // Darker blue at top
          vec3 horizonColor = vec3(0.5, 0.65, 0.85);    // Medium blue at horizon

          vec3 skyColor = mix(
            horizonColor,
            zenithColor,
            pow(max(elevation, 0.0), 0.7)
          );

          // Sun disc (visible sun)
          float sunSize = 0.999875; // Larger value = smaller sun (closer to 1.0 = smaller)
          float sunDisc = step(sunSize, sunAngle);
          vec3 sunColor = vec3(1.0, 1.0, 0.95) * sunDisc * 10.0;

          // Sun glow (halo around sun)
          float sunGlow = pow(max(sunAngle, 0.0), 50.0) * 0.5;
          vec3 glowColor = vec3(1.0, 0.95, 0.8) * sunGlow;

          gl_FragColor = vec4(skyColor + sunColor + glowColor, 1.0);
        }
      `,
      side: THREE.BackSide
    })
  );
  // Position sky sphere so its equator aligns with the ocean/terrain height (y = -450)
  sky.position.set(0, -450, 0);
  scene.add(sky);

  // Add terrain (includes ocean surface)
  createIslands(scene);

  const tempMatrix = new THREE.Matrix4();
  const targetQuaternion = new THREE.Quaternion();

  // Setup third-person camera (will be mounted to green_0 jet when it's created)
  const thirdPersonCamera = new THREE.PerspectiveCamera(90, window.innerWidth / window.innerHeight, 0.1, 100000);

  // Setup free camera for debugging
  const freeCamera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 100000);
  freeCamera.position.set(0, 50, 50);
  freeCamera.lookAt(0, 0, 0);

  return { scene, camera, renderer, thirdPersonCamera, freeCamera, tempMatrix, targetQuaternion };
}

export function cleanupScene(scene, renderer) {
  if (scene) {
    scene.clear();
  }
  if (renderer) {
    renderer.dispose();
  }
}
