// Radar display system
// Panoramic (360°) and Radial (forward cone) radar rendering

// Access THREE from global scope (loaded via CDN in index.html)
const THREE = window.THREE;

// Update 360° Panoramic Radar (top center, rectangular panoramic view)
export function updatePanoramicRadar(gameState) {
  const canvas = document.getElementById('panoramicRadar');
  if (!canvas || !gameState) return;

  const ctx = canvas.getContext('2d');
  const width = canvas.width;
  const height = canvas.height;
  const centerY = height / 2;

  // Clear canvas
  ctx.clearRect(0, 0, width, height);

  // Find player jet (green_0)
  const playerJet = gameState.jets.find(j => j.id === 'green_0');
  if (!playerJet) return;

  // Draw radar background
  ctx.fillStyle = 'rgba(0, 20, 40, 0.8)';
  ctx.fillRect(0, 0, width, height);

  // Draw jetfighter icon above radar (rear view showing wing span)
  const iconY = -8;
  const iconWidth = 40;
  ctx.strokeStyle = 'rgba(0, 255, 0, 0.9)';
  ctx.fillStyle = 'rgba(0, 255, 0, 0.9)';
  ctx.lineWidth = 2;

  // Wings (horizontal line)
  ctx.beginPath();
  ctx.moveTo(width / 2 - iconWidth / 2, iconY);
  ctx.lineTo(width / 2 + iconWidth / 2, iconY);
  ctx.stroke();

  // Fuselage (small vertical line in center)
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.moveTo(width / 2, iconY - 3);
  ctx.lineTo(width / 2, iconY + 3);
  ctx.stroke();

  // Draw horizontal center line (represents horizon/level flight)
  ctx.strokeStyle = 'rgba(0, 255, 255, 0.4)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(0, centerY);
  ctx.lineTo(width, centerY);
  ctx.stroke();

  // Draw vertical section lines (every 45 degrees)
  ctx.strokeStyle = 'rgba(0, 255, 255, 0.2)';
  for (let i = 0; i <= 8; i++) {
    const x = (i / 8) * width;
    ctx.beginPath();
    ctx.moveTo(x, 0);
    ctx.lineTo(x, height);
    ctx.stroke();
  }

  // Draw aircraft orientation labels (relative to jetfighter body)
  ctx.fillStyle = 'rgba(0, 255, 255, 0.8)';
  ctx.font = '10px monospace';
  ctx.textAlign = 'center';

  // Nose (center - front of aircraft)
  ctx.fillText('NOSE', width / 2, 12);
  // Left wing (25% from left - port side)
  ctx.fillText('L-WING', width * 0.25, 12);
  // Right wing (75% from left - starboard side)
  ctx.fillText('R-WING', width * 0.75, 12);
  // Tail/Engines (wrap around - show at both edges for 180° behind)
  ctx.fillText('TAIL', 5, 12);
  ctx.textAlign = 'right';
  ctx.fillText('TAIL', width - 5, 12);

  // Get player forward direction (2D, ignore Y)
  const playerForward = new THREE.Vector3(0, 0, 1);
  playerForward.applyQuaternion(playerJet.quaternion);
  const playerAngle = Math.atan2(playerForward.x, playerForward.z);

  // Draw player jet as horizontal line (wing span - rear view)
  ctx.strokeStyle = 'rgba(255, 255, 255, 1)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  // Horizontal line (wing span)
  ctx.moveTo(width / 2 - 12, centerY);
  ctx.lineTo(width / 2 + 12, centerY);
  // Left wing tip (pointing down)
  ctx.moveTo(width / 2 - 12, centerY);
  ctx.lineTo(width / 2 - 12, centerY + 4);
  // Right wing tip (pointing down)
  ctx.moveTo(width / 2 + 12, centerY);
  ctx.lineTo(width / 2 + 12, centerY + 4);
  ctx.stroke();

  // Draw fuselage center dot
  ctx.fillStyle = 'rgba(255, 255, 255, 1)';
  ctx.beginPath();
  ctx.arc(width / 2, centerY, 2, 0, Math.PI * 2);
  ctx.fill();

  // Draw other jets
  const radarRange = 300; // units
  gameState.jets.forEach(jet => {
    if (jet.id === 'green_0' || jet.isDestroyed) return;

    // Calculate relative position
    const dx = jet.position.x - playerJet.position.x;
    const dy = jet.position.y - playerJet.position.y;
    const dz = jet.position.z - playerJet.position.z;
    const distance2D = Math.sqrt(dx * dx + dz * dz);

    if (distance2D > radarRange) return;

    // Calculate angle relative to player's forward direction
    const jetAngle = Math.atan2(dx, dz);
    let relativeAngle = jetAngle - playerAngle;

    // Normalize to -PI to PI
    while (relativeAngle > Math.PI) relativeAngle -= Math.PI * 2;
    while (relativeAngle < -Math.PI) relativeAngle += Math.PI * 2;

    // Convert angle to X position on radar (-PI to PI maps to 0 to width)
    // Front (0) = center, Left (-PI/2) = 25%, Right (PI/2) = 75%, Back (PI/-PI) = edges
    const normalizedAngle = relativeAngle / Math.PI; // -1 to 1
    let radarX = width / 2 + (normalizedAngle * width / 2);

    // Handle wrap-around for targets near the back
    const shouldWrap = Math.abs(relativeAngle) > Math.PI * 0.85;

    // Calculate Y position based on height difference (clamped)
    const heightFactor = dy / radarRange; // Normalize height
    const radarY = centerY - (heightFactor * (height / 2 - 10)); // Invert Y (higher = up)
    const clampedY = Math.max(5, Math.min(height - 5, radarY));

    // Draw jet dot with team color
    if (jet.team === 'green') {
      ctx.fillStyle = 'rgba(0, 255, 0, 0.9)';
      ctx.strokeStyle = 'rgba(0, 255, 0, 0.6)';
    } else {
      ctx.fillStyle = 'rgba(255, 0, 0, 0.9)';
      ctx.strokeStyle = 'rgba(255, 0, 0, 0.6)';
    }

    // Draw the main dot
    ctx.beginPath();
    ctx.arc(radarX, clampedY, 4, 0, Math.PI * 2);
    ctx.fill();

    // If wrapping (near back), draw on the opposite side too
    if (shouldWrap) {
      const wrapX = relativeAngle > 0 ? radarX - width : radarX + width;
      ctx.beginPath();
      ctx.arc(wrapX, clampedY, 4, 0, Math.PI * 2);
      ctx.fill();
    }

    // Draw heading indicator (small line showing jet's direction)
    const jetForward = new THREE.Vector3(0, 0, 1);
    jetForward.applyQuaternion(jet.quaternion);
    const jetHeadingAngle = Math.atan2(jetForward.x, jetForward.z);
    let relativeHeading = jetHeadingAngle - playerAngle;

    while (relativeHeading > Math.PI) relativeHeading -= Math.PI * 2;
    while (relativeHeading < -Math.PI) relativeHeading += Math.PI * 2;

    const headingDiff = relativeHeading - relativeAngle;
    const headingX = Math.cos(headingDiff) * 8;
    const headingY = -Math.sin(headingDiff) * 8;

    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(radarX, clampedY);
    ctx.lineTo(radarX + headingX, clampedY + headingY);
    ctx.stroke();

    // Draw wrap heading indicator too
    if (shouldWrap) {
      const wrapX = relativeAngle > 0 ? radarX - width : radarX + width;
      ctx.beginPath();
      ctx.moveTo(wrapX, clampedY);
      ctx.lineTo(wrapX + headingX, clampedY + headingY);
      ctx.stroke();
    }
  });

  // Draw range text
  ctx.fillStyle = 'rgba(0, 255, 255, 0.6)';
  ctx.font = '9px monospace';
  ctx.textAlign = 'center';
  ctx.fillText(`RANGE: ${radarRange}m`, width / 2, height - 5);
}

// Update Radial Forward Radar (bottom left, includes height)
export function updateRadialRadar(gameState) {
  const canvas = document.getElementById('radialRadar');
  if (!canvas || !gameState) return;

  const ctx = canvas.getContext('2d');
  const centerX = canvas.width / 2;
  const centerY = canvas.height / 2;
  const radius = Math.min(canvas.width, canvas.height) / 2 - 10;

  // Clear canvas
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Find player jet (green_0)
  const playerJet = gameState.jets.find(j => j.id === 'green_0');
  if (!playerJet) return;

  // Draw radar background circle (complete circle)
  ctx.fillStyle = 'rgba(20, 40, 0, 0.8)';
  ctx.beginPath();
  ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
  ctx.fill();

  // Draw range rings
  ctx.strokeStyle = 'rgba(0, 255, 0, 0.3)';
  ctx.lineWidth = 1;
  for (let i = 1; i <= 3; i++) {
    ctx.beginPath();
    ctx.arc(centerX, centerY, (radius / 3) * i, 0, Math.PI * 2);
    ctx.stroke();
  }

  // Draw center crosshair (direction indicators)
  ctx.strokeStyle = 'rgba(0, 255, 0, 0.5)';
  ctx.lineWidth = 1;
  ctx.beginPath();
  // Vertical line (full length - top to bottom)
  ctx.moveTo(centerX, centerY - radius);
  ctx.lineTo(centerX, centerY + radius);
  // Horizontal line (left and right)
  ctx.moveTo(centerX - radius, centerY);
  ctx.lineTo(centerX + radius, centerY);
  ctx.stroke();

  // Draw player jet as horizontal line (wing span - rear view)
  ctx.strokeStyle = 'rgba(255, 255, 255, 1)';
  ctx.lineWidth = 2;
  ctx.beginPath();
  // Horizontal line (wing span)
  ctx.moveTo(centerX - 12, centerY);
  ctx.lineTo(centerX + 12, centerY);
  // Left wing tip (pointing down)
  ctx.moveTo(centerX - 12, centerY);
  ctx.lineTo(centerX - 12, centerY + 4);
  // Right wing tip (pointing down)
  ctx.moveTo(centerX + 12, centerY);
  ctx.lineTo(centerX + 12, centerY + 4);
  ctx.stroke();

  // Draw fuselage center dot
  ctx.fillStyle = 'rgba(255, 255, 255, 1)';
  ctx.beginPath();
  ctx.arc(centerX, centerY, 2, 0, Math.PI * 2);
  ctx.fill();

  // Draw other jets (forward hemisphere - pilot's 3D forward view perspective)
  const radarRange = 200; // units

  gameState.jets.forEach(jet => {
    if (jet.id === 'green_0' || jet.isDestroyed) return;

    // Calculate relative position in player's local space
    const relativePos = new THREE.Vector3()
      .copy(jet.position)
      .sub(playerJet.position);

    // Transform to player's local coordinate system
    const inverseQuat = playerJet.quaternion.clone().invert();
    relativePos.applyQuaternion(inverseQuat);

    // ONLY show targets in forward hemisphere (positive Z in local space = in front of nose)
    // This radar shows the 3D forward view from the cockpit
    if (relativePos.z <= 0) return; // Skip targets behind the nose

    // Calculate 3D distance
    const distance3D = relativePos.length();
    if (distance3D > radarRange) return;

    // Calculate spherical projection onto the radar circle
    // The radar shows angular position from the nose direction
    // In local space: X = left(-)/right(+), Y = down(-)/up(+), Z = forward(+)

    // Horizontal distance from forward axis
    const horizontalDist = Math.sqrt(relativePos.x * relativePos.x + relativePos.z * relativePos.z);

    // Calculate radar position based on angles from center (nose direction)
    // X position: left/right angle
    const radarX = centerX + (relativePos.x / horizontalDist) * (horizontalDist / radarRange) * radius;

    // Y position: up/down based on actual Y coordinate
    // Top of circle = above, bottom = below
    const verticalAngle = Math.atan2(relativePos.y, relativePos.z);
    const horizontalAngle = Math.atan2(relativePos.x, relativePos.z);

    // Calculate distance from center based on angular deviation from forward
    const angleFromForward = Math.acos(Math.min(1, relativePos.z / distance3D));
    const distFromCenter = (angleFromForward / (Math.PI / 2)) * radius;

    // Final position: combine horizontal and vertical angles
    const finalX = centerX + Math.sin(horizontalAngle) * distFromCenter;
    const finalY = centerY - Math.sin(verticalAngle) * distFromCenter;

    // Draw jet dot
    if (jet.team === 'green') {
      ctx.fillStyle = 'rgba(0, 255, 0, 0.9)';
    } else {
      ctx.fillStyle = 'rgba(255, 0, 0, 0.9)';
    }

    // Draw dot at 3D projected position
    ctx.beginPath();
    ctx.arc(finalX, finalY, 3, 0, Math.PI * 2);
    ctx.fill();
  });

  // Draw labels
  ctx.fillStyle = 'rgba(0, 255, 0, 0.6)';
  ctx.font = '9px monospace';
  ctx.textAlign = 'center';
  ctx.fillText(`${radarRange}m`, centerX, centerY + radius + 12);
  ctx.fillText('TOP', centerX, centerY - radius - 3);
}

