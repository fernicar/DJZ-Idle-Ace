// Jet fighter model loader
// Loads 3D model data from jetfighter.json

let jetFighterModel = null;

// Load jet fighter model from JSON
export async function loadJetFighterModel() {
  try {
    const response = await fetch('./jetfighter.json');
    jetFighterModel = await response.json();
    console.log('Jet fighter model loaded:', jetFighterModel);
    return jetFighterModel;
  } catch (error) {
    console.error('Failed to load jet fighter model:', error);
    throw error;
  }
}

// Get the cached jet fighter model
export function getJetFighterModel() {
  return jetFighterModel;
}

// Check if model is loaded
export function isModelLoaded() {
  return jetFighterModel !== null;
}
