// Mesh creation and management
// Handles 3D mesh creation for all game entities

import { getJetFighterModel } from './jet-loader.js';
import * as CONST from '../game/constants.js';

// Access THREE from global scope (loaded via CDN in index.html)
const THREE = window.THREE;

// Mesh caches (will be initialized by renderer)
export const meshCaches = {
  jetMeshes: new Map(),
  tracerMeshes: new Map(),
  missileMeshes: new Map(),
  flareMeshes: new Map(),
  jetTrails: new Map(),
  missileTrails: new Map(),
  flareTrails: new Map(),
  targetMarkers: new Map()
};

export function createJetMesh(jet, thirdPersonCamera = null) {
  const group = new THREE.Group();

  const jetFighterModel = getJetFighterModel();
  if (!jetFighterModel) {
    console.error('Jet fighter model not loaded yet');
    return group;
  }

  // Use low poly (3 segments) for all jets except green_0 (leader uses 8 segments)
  const segments = jet.id === 'green_0' ? 8 : 3;

  // Process each component from the model
  jetFighterModel.components.forEach(compData => {
    let geometry, material;

    // Get base color from model and replace based on team
    let color = compData.color;

    // Color replacement logic:
    // Green team: keep original colors from modeler (#132853, #13502b, etc.)
    // Purple team: replace blue/green/gray colors with purple variants
    if (jet.team === 'red') {
      // Replace blue (#132853, etc.) with purple
      if (color === '#132853') color = '#4a1370'; // Dark purple
      if (color === '#13502b') color = '#6b1a8f'; // Medium purple
      if (color === '#00ffff') color = '#ff00ff'; // Magenta for cockpit
      if (color === '#888888') color = '#9d4edd'; // Purple for gray wings/parts
      if (color === '#aaaaaa') color = '#b388eb'; // Light purple for light gray parts
      if (color === '#222222') color = '#3a0d5c'; // Very dark purple for dark parts
    }

    // Create material with team-adjusted color
    const isTransparent = compData.type === 'cockpit';
    material = new THREE.MeshStandardMaterial({
      color: color,
      transparent: isTransparent,
      opacity: isTransparent ? 0.7 : 1.0,
      emissive: isTransparent ? color : 0x000000,
      emissiveIntensity: isTransparent ? 0.3 : 0
    });

    // Create geometry based on type
    switch(compData.type) {
      case 'box':
        geometry = new THREE.BoxGeometry(1, 1, 1);
        break;
      case 'cylinder':
        geometry = new THREE.CylinderGeometry(0.5, 0.5, 1, segments);
        break;
      case 'sphere':
        geometry = new THREE.SphereGeometry(0.5, segments, segments);
        break;
      case 'cone':
        geometry = new THREE.ConeGeometry(0.5, 1, segments);
        break;
      case 'torus':
        geometry = new THREE.TorusGeometry(0.5, 0.2, segments, segments * 2);
        break;
      case 'wing':
        geometry = new THREE.BoxGeometry(2, 4, 0.1);
        break;
      case 'engine':
        geometry = new THREE.CylinderGeometry(0.3, 0.35, 1, segments);
        break;
      case 'cockpit':
        geometry = new THREE.SphereGeometry(0.5, segments, segments);
        break;
      case 'missile':
        geometry = new THREE.CylinderGeometry(0.08, 0.08, 1.2, 8);
        break;
      default:
        console.warn('Unknown component type:', compData.type);
        return;
    }

    const mesh = new THREE.Mesh(geometry, material);

    // Apply transformations from the model
    mesh.position.set(compData.position.x, compData.position.y, compData.position.z);
    mesh.rotation.set(
      compData.rotation.x * Math.PI / 180,
      compData.rotation.y * Math.PI / 180,
      compData.rotation.z * Math.PI / 180
    );
    mesh.scale.set(compData.scale.x, compData.scale.y, compData.scale.z);

    group.add(mesh);
  });

  // Scale the entire group to fit the game
  group.scale.set(0.15, 0.15, 0.15);

  // Add engine exhaust cones (positioned at smaller cap of engine cylinders)
  // Engine geometry: CylinderGeometry(0.3, 0.35, 1), with rotation x=-90
  // The smaller end (radius 0.3) points toward -Z (tail)

  if (jet.id === 'green_0') {
    // User jet: 2 cones per engine (outer reddish transparent + inner yellow solid)
    // Left engine exhaust
    const exhaustOuterLeft = new THREE.Mesh(
      new THREE.ConeGeometry(0.3, 2, 8), // Base matches engine smaller cap
      new THREE.MeshStandardMaterial({
        color: 0xff3333,
        emissive: 0xff3333,
        emissiveIntensity: 1.5,
        transparent: true,
        opacity: 0.33,
        toneMapped: false
      })
    );
    exhaustOuterLeft.position.set(0.4, 0, -3.2); // Behind engine_left
    exhaustOuterLeft.rotation.set(-Math.PI / 2, 0, 0); // Point toward -Z
    exhaustOuterLeft.name = 'exhaustOuterLeft';
    group.add(exhaustOuterLeft);

    const exhaustInnerLeft = new THREE.Mesh(
      new THREE.ConeGeometry(0.15, 1.5, 8),
      new THREE.MeshStandardMaterial({
        color: 0xffff00,
        emissive: 0xffff00,
        emissiveIntensity: 3,
        toneMapped: false
      })
    );
    exhaustInnerLeft.position.set(0.4, 0, -3.2);
    exhaustInnerLeft.rotation.set(-Math.PI / 2, 0, 0);
    exhaustInnerLeft.name = 'exhaustInnerLeft';
    group.add(exhaustInnerLeft);

    // Right engine exhaust
    const exhaustOuterRight = new THREE.Mesh(
      new THREE.ConeGeometry(0.3, 2, 8),
      new THREE.MeshStandardMaterial({
        color: 0xff3333,
        emissive: 0xff3333,
        emissiveIntensity: 1.5,
        transparent: true,
        opacity: 0.33,
        toneMapped: false
      })
    );
    exhaustOuterRight.position.set(-0.4, 0, -3.2); // Behind engine_right
    exhaustOuterRight.rotation.set(-Math.PI / 2, 0, 0);
    exhaustOuterRight.name = 'exhaustOuterRight';
    group.add(exhaustOuterRight);

    const exhaustInnerRight = new THREE.Mesh(
      new THREE.ConeGeometry(0.15, 1.5, 8),
      new THREE.MeshStandardMaterial({
        color: 0xffff00,
        emissive: 0xffff00,
        emissiveIntensity: 3,
        toneMapped: false
      })
    );
    exhaustInnerRight.position.set(-0.4, 0, -3.2);
    exhaustInnerRight.rotation.set(-Math.PI / 2, 0, 0);
    exhaustInnerRight.name = 'exhaustInnerRight';
    group.add(exhaustInnerRight);
  } else {
    // Other jets: 1 yellow cone per engine
    const exhaustLeft = new THREE.Mesh(
      new THREE.ConeGeometry(0.3, 1.5, 3), // Low poly (3 segments)
      new THREE.MeshStandardMaterial({
        color: 0xffff00,
        emissive: 0xffff00,
        emissiveIntensity: 2,
        toneMapped: false
      })
    );
    exhaustLeft.position.set(0.4, 0, -3.2);
    exhaustLeft.rotation.set(-Math.PI / 2, 0, 0);
    exhaustLeft.name = 'exhaustLeft';
    group.add(exhaustLeft);

    const exhaustRight = new THREE.Mesh(
      new THREE.ConeGeometry(0.3, 1.5, 3),
      new THREE.MeshStandardMaterial({
        color: 0xffff00,
        emissive: 0xffff00,
        emissiveIntensity: 2,
        toneMapped: false
      })
    );
    exhaustRight.position.set(-0.4, 0, -3.2);
    exhaustRight.rotation.set(-Math.PI / 2, 0, 0);
    exhaustRight.name = 'exhaustRight';
    group.add(exhaustRight);
  }

  // Add explosion sphere effect (initially hidden, shown when wrecked)
  const explosionSphere = new THREE.Mesh(
    new THREE.SphereGeometry(1, 16, 16),
    new THREE.MeshStandardMaterial({
      color: 'orange',
      emissive: 'orange',
      emissiveIntensity: 4,
      transparent: true,
      opacity: 0.6,
      toneMapped: false
    })
  );
  explosionSphere.scale.set(3, 3, 3); // Spherical shape (reduced elongation)
  explosionSphere.name = 'explosionSphere';
  explosionSphere.visible = false; // Hidden by default
  group.add(explosionSphere);

  // For green_0 only: add camera arm and mount third-person camera
  if (jet.id === 'green_0') {
    // Create camera arm with origin at jetfighter center
    const cameraArm = new THREE.Group();
    cameraArm.name = 'cameraArm';
    cameraArm.position.set(0, 0, 0); // Origin at jetfighter center
    group.add(cameraArm); // Arm is child of jet mesh

    // Mount third-person camera on the arm at the end position
    if (thirdPersonCamera && !thirdPersonCamera.parent) {
      cameraArm.add(thirdPersonCamera); // Camera is child of arm
      thirdPersonCamera.position.set(0, 7, -15); // Camera at end of arm (behind and above)

      // Camera is "soldered" to the arm - no rotation needed
      // Camera looks in default direction, will inherit arm's rotation
      thirdPersonCamera.rotation.set(0, Math.PI, 0); // Look forward

      console.log('Third-person camera mounted on green_0 jet');
    }
  }

  return group;
}

export function createTracerMesh(tracer) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.1, 0.1, 1.5, 8),
    new THREE.MeshStandardMaterial({ color: 'yellow', emissive: 'yellow', emissiveIntensity: 2 })
  );
  return mesh;
}

export function createMissileMesh(missile) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.2, 0.2, 3, 8),
    new THREE.MeshStandardMaterial({ color: 'white', emissive: 'white', emissiveIntensity: 1 })
  );
  return mesh;
}

export function createFlareMesh(flare) {
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.3, 8, 8),
    new THREE.MeshStandardMaterial({ color: 'white', emissive: 'white', emissiveIntensity: 4 })
  );
  return mesh;
}

export function createTargetMarker(color, scale = 5) {
  // Create 2D billboard diamond marker (flat diamond that always faces camera)
  const points = [
    new THREE.Vector3(0, scale, 0),      // Top
    new THREE.Vector3(scale, 0, 0),      // Right
    new THREE.Vector3(0, -scale, 0),     // Bottom
    new THREE.Vector3(-scale, 0, 0),     // Left
    new THREE.Vector3(0, scale, 0)       // Back to top to close the diamond
  ];

  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  const material = new THREE.LineBasicMaterial({
    color: color,
    transparent: true,
    opacity: 0.9,
    linewidth: 2
  });

  const line = new THREE.Line(geometry, material);
  line.userData.isBillboard = true; // Mark as billboard for camera-facing behavior

  return line;
}

// Update 360° Panoramic Radar (top center, rectangular panoramic view)
