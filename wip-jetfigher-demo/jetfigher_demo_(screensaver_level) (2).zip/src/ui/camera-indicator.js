// Camera mode indicator UI
// Updates the camera mode text display

export function updateCameraModeIndicator(currentCameraMode) {
  const indicatorText = document.getElementById('cameraModeText');
  if (indicatorText) {
    const modeNames = {
      'overview': 'OVERVIEW',
      'thirdPerson': 'THIRD PERSON',
      'free': 'FREE CAM (DEBUG)'
    };
    indicatorText.textContent = modeNames[currentCameraMode] || currentCameraMode.toUpperCase();
  }
}
