// Event Monitor System
// Handles event logging and radio chat display

const eventLog = [];
const MAX_EVENTS = 5; // Keep only last 5 radio chats visible

// Radio chat queue with priority and timing
const radioChatQueue = [];
let lastGreenChatTime = 0;
let lastRedChatTime = 0;
const CHAT_COOLDOWN = 2000; // 2 seconds between chats per team

// Event priorities (higher = more important)
const EVENT_PRIORITY = {
  'destroy': 5,
  'fox2': 4,
  'guns': 3,
  'swap': 2,
  'respawn': 1
};

// Radio chat templates by team and event
const RADIO_CHATS = {
  green: {
    destroy: [
      { pilot: 'green_0', line: "Splash one! Bandit down!" },
      { pilot: 'green_1', line: "Confirmed kill! Good shooting!" },
      { pilot: 'green_0', line: "That's how it's done!" },
      { pilot: 'green_1', line: "Target destroyed! Returning to patrol." }
    ],
    fox2: [
      { pilot: 'green_0', line: "Fox 2! Missile away!" },
      { pilot: 'green_1', line: "Fox 2! Heat seeker tracking!" },
      { pilot: 'green_0', line: "Magnum! Missile locked!" },
      { pilot: 'green_1', line: "Fox 2! Fox 2!" }
    ],
    guns: [
      { pilot: 'green_0', line: "Guns guns guns!" },
      { pilot: 'green_1', line: "Engaging with cannons!" },
      { pilot: 'green_0', line: "Taking the shot!" },
      { pilot: 'green_1', line: "Rifle! Rifle!" }
    ],
    swap: [
      { pilot: 'green_1', line: "Copy lead, switching targets!", connection: 'green_0' },
      { pilot: 'green_1', line: "Roger that, breaking off!", connection: 'green_0' },
      { pilot: 'green_1', line: "Switching to new target!", connection: 'green_0' },
      { pilot: 'green_0', line: "Hawk, switch targets!", connection: 'green_1' }
    ],
    respawn: [
      { pilot: 'green_0', line: "Back in the fight!" },
      { pilot: 'green_1', line: "Systems nominal, re-engaging!" },
      { pilot: 'green_0', line: "Let's try that again!" },
      { pilot: 'green_1', line: "I'm not done yet!" }
    ]
  },
  red: {
    destroy: [
      { pilot: 'red_0', line: "Scratch one green!" },
      { pilot: 'red_1', line: "Enemy down! Excellent work!" },
      { pilot: 'red_0', line: "Target eliminated!" },
      { pilot: 'red_1', line: "Splash! They won't see that coming again!" }
    ],
    fox2: [
      { pilot: 'red_0', line: "Fox 2! Engaging!" },
      { pilot: 'red_1', line: "Missile away! Tracking green!" },
      { pilot: 'red_0', line: "Fox 2! Heat signature locked!" },
      { pilot: 'red_1', line: "Magnum! Missile in flight!" }
    ],
    guns: [
      { pilot: 'red_0', line: "Opening fire!" },
      { pilot: 'red_1', line: "Guns guns guns!" },
      { pilot: 'red_0', line: "Engaging with cannons!" },
      { pilot: 'red_1', line: "In range, taking the shot!" }
    ],
    swap: [
      { pilot: 'red_1', line: "Acknowledged, switching targets!", connection: 'red_0' },
      { pilot: 'red_1', line: "Copy, engaging new target!", connection: 'red_0' },
      { pilot: 'red_1', line: "Roger, changing focus!", connection: 'red_0' },
      { pilot: 'red_0', line: "Bandit, change targets!", connection: 'red_1' }
    ],
    respawn: [
      { pilot: 'red_0', line: "Back online, engaging!" },
      { pilot: 'red_1', line: "Systems restored, returning!" },
      { pilot: 'red_0', line: "Round two begins!" },
      { pilot: 'red_1', line: "Rejoining the fight!" }
    ]
  }
};

export function addEvent(team, text) {
  const timestamp = new Date().toLocaleTimeString('en-US', { hour12: false });
  eventLog.unshift({ team, text, timestamp });

  // Keep only the last MAX_EVENTS
  if (eventLog.length > MAX_EVENTS) {
    eventLog.pop();
  }

  updateEventMonitor();
}

export function queueRadioChat(team, eventType, sourceJet = null) {
  const chats = RADIO_CHATS[team]?.[eventType];
  if (!chats || chats.length === 0) return;

  const chat = chats[Math.floor(Math.random() * chats.length)];
  const priority = EVENT_PRIORITY[eventType] || 0;

  radioChatQueue.push({
    team,
    eventType,
    priority,
    chat,
    sourceJet,
    timestamp: Date.now()
  });

  // Sort by priority (highest first), then by timestamp (oldest first)
  radioChatQueue.sort((a, b) => {
    if (b.priority !== a.priority) return b.priority - a.priority;
    return a.timestamp - b.timestamp;
  });
}

export function processRadioQueue() {
  const now = Date.now();

  // Process green team chat (max 1 per second)
  if (now - lastGreenChatTime >= CHAT_COOLDOWN) {
    const greenChat = radioChatQueue.find(c => c.team === 'green');
    if (greenChat) {
      displayRadioChat(greenChat);
      radioChatQueue.splice(radioChatQueue.indexOf(greenChat), 1);
      lastGreenChatTime = now;
    }
  }

  // Process red team chat (max 1 per second, independent of green)
  if (now - lastRedChatTime >= CHAT_COOLDOWN) {
    const redChat = radioChatQueue.find(c => c.team === 'red');
    if (redChat) {
      displayRadioChat(redChat);
      radioChatQueue.splice(radioChatQueue.indexOf(redChat), 1);
      lastRedChatTime = now;
    }
  }
}

function displayRadioChat(chatData) {
  const { chat, team } = chatData;

  // Add radio chat with avatar info to event log
  if (chat.connection) {
    eventLog.unshift({
      team,
      type: 'radio',
      pilot: chat.pilot,
      connection: chat.connection,
      text: chat.line
    });
  } else {
    eventLog.unshift({
      team,
      type: 'radio',
      pilot: chat.pilot,
      text: chat.line
    });
  }

  // Keep only the last MAX_EVENTS
  if (eventLog.length > MAX_EVENTS) {
    eventLog.pop();
  }

  updateEventMonitor();
}

function updateEventMonitor() {
  const monitorContent = document.getElementById('eventMonitorContent');
  if (!monitorContent) return;

  monitorContent.innerHTML = eventLog.map(event => {
    if (event.type === 'radio') {
      // Radio chat with avatar(s)
      const teamClass = event.team;
      const avatarsHTML = event.connection
        ? `<div class="radio-avatars">
             <div class="pilot-avatar-small ${teamClass} ${event.pilot}"></div>
             <span class="radio-connection">↔</span>
             <div class="pilot-avatar-small ${teamClass} ${event.connection}"></div>
           </div>`
        : `<div class="radio-avatars">
             <div class="pilot-avatar-small ${teamClass} ${event.pilot}"></div>
           </div>`;

      return `
        <div class="radio-chat ${teamClass}">
          ${avatarsHTML}
          <div class="radio-content">
            <div class="radio-text">"${event.text}"</div>
          </div>
        </div>
      `;
    } else {
      // Regular event (hidden)
      return '';
    }
  }).join('');
}

export function clearEventLog() {
  eventLog.length = 0;
  radioChatQueue.length = 0;
  lastGreenChatTime = 0;
  lastRedChatTime = 0;
  updateEventMonitor();
}
