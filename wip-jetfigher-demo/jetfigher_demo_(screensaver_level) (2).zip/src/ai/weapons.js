import * as CONST from '../game/constants.js';

// Fire tracers from a jet
export function fireBurst(jet, jets, newTracers) {
  const target = jets.find(j => j.id === jet.targetId && !j.isDestroyed && !j.isWrecked);
  if (!target) return;

  const forwardDir = new THREE.Vector3(0, 0, 1).applyQuaternion(jet.quaternion);
  const dirToTarget = target.position.clone().sub(jet.position).normalize();
  const dotProduct = forwardDir.dot(dirToTarget);
  const isTargetInFront = dotProduct > CONST.FIRING_CONE_DOT_PRODUCT;
  const distanceToTarget = jet.position.distanceTo(target.position);

  jet.fireCooldown -= 0.016; // Assume 60fps

  if (jet.fireCooldown <= 0 && !jet.burstState.active && isTargetInFront) {
    if (distanceToTarget > CONST.WEAPON_RANGE_THRESHOLD) {
      // Fire missile (handled separately)
      return 'missile';
    } else {
      // Fire tracer burst
      jet.burstState.active = true;
      jet.burstState.burstsLeft = CONST.BURST_COUNT;
      jet.burstState.tracersLeftInBurst = CONST.TRACERS_PER_BURST;
      jet.burstState.nextShotTimer = 0;
      jet.fireCooldown = CONST.FIRING_COOLDOWN + (Math.random() - 0.5);
      return 'guns'; // Signal that guns burst started
    }
  }
}

export function updateBurst(jet, jets, newTracers, delta) {
  const target = jets.find(j => j.id === jet.targetId && !j.isDestroyed && !j.isWrecked);
  if (!jet.burstState.active || !target) return null;

  jet.burstState.nextShotTimer -= delta;
  if (jet.burstState.nextShotTimer <= 0) {
    const fireDirection = new THREE.Vector3(0, 0, 1).applyQuaternion(jet.quaternion);
    fireDirection.add(new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(0.02)).normalize();

    const tracerVelocity = jet.velocity.clone().add(fireDirection.multiplyScalar(CONST.TRACER_SPEED));
    const tracerQuaternion = new THREE.Quaternion();
    tracerQuaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), tracerVelocity.clone().normalize());

    newTracers.push({
      id: `t_${jet.id}_${Date.now()}_${Math.random()}`,
      position: jet.position.clone(),
      velocity: tracerVelocity,
      quaternion: tracerQuaternion,
      life: CONST.TRACER_LIFESPAN
    });

    // Kill shot execution
    if (jet.burstState.isKillShot) {
      const targetJet = jets.find(j => j.id === jet.targetId && !j.isDestroyed && !j.isWrecked);
      if (targetJet) {
        targetJet.isWrecked = true;
        targetJet.destroyedAt = Date.now();
        targetJet.wreckageAngularVelocity = new THREE.Vector3(
          (Math.random() - 0.5) * 10,
          (Math.random() - 0.5) * 5,
          (Math.random() - 0.5) * 10
        );
        // Return kill information
        jet.burstState.active = false;
        jet.burstState.isKillShot = false;
        return { killerId: jet.id, victimId: targetJet.id };
      }
      jet.burstState.active = false;
      jet.burstState.isKillShot = false;
    }

    if (jet.burstState.active) {
      jet.burstState.tracersLeftInBurst--;
      if (jet.burstState.tracersLeftInBurst <= 0) {
        jet.burstState.burstsLeft--;
        if (jet.burstState.burstsLeft <= 0) {
          jet.burstState.active = false;
          jet.burstState.isKillShot = false;
        } else {
          jet.burstState.tracersLeftInBurst = CONST.TRACERS_PER_BURST;
          jet.burstState.nextShotTimer = CONST.TIME_BETWEEN_BURSTS;
          if (jet.burstState.burstsLeft === 1 && Math.random() < 0.5) {
            jet.burstState.isKillShot = true;
          } else {
            jet.burstState.isKillShot = false;
          }
        }
      } else {
        jet.burstState.nextShotTimer = CONST.TIME_BETWEEN_TRACERS;
      }
    }
  }

  return null;
}

// Fire missile
export function fireMissile(jet, jets, newMissiles) {
  const fireDirection = new THREE.Vector3(0, 0, 1).applyQuaternion(jet.quaternion);
  const missileVelocity = fireDirection.multiplyScalar(CONST.MISSILE_SPEED);
  const finalVelocity = jet.velocity.clone().add(missileVelocity);
  const missileQuaternion = new THREE.Quaternion();
  missileQuaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), finalVelocity.clone().normalize());

  newMissiles.push({
    id: `m_${jet.id}_${Date.now()}`,
    position: jet.position.clone(),
    velocity: finalVelocity,
    quaternion: missileQuaternion,
    life: CONST.MISSILE_LIFESPAN,
    targetId: jet.targetId,
    willDetonate: Math.random() < 0.8,
  });

  // Trigger flares on target
  const targetJet = jets.find(j => j.id === jet.targetId && !j.isDestroyed && !j.isWrecked);
  if (targetJet && !targetJet.flareState.deploying) {
    targetJet.flareState.deploying = true;
    targetJet.flareState.flaresLeft = CONST.FLARES_TO_DEPLOY;
    targetJet.flareState.nextFlareTimer = 0;
  }

  jet.fireCooldown = CONST.FIRING_COOLDOWN + (Math.random() - 0.5);
}

// Deploy flares
export function deployFlares(jet, newFlares, delta) {
  if (!jet.flareState.deploying) return;

  jet.flareState.nextFlareTimer -= delta;
  if (jet.flareState.nextFlareTimer <= 0 && jet.flareState.flaresLeft > 0) {
    const right = new THREE.Vector3(1, 0, 0).applyQuaternion(jet.quaternion);
    const back = new THREE.Vector3(0, 0, -1).applyQuaternion(jet.quaternion);

    // Left flare
    const leftVel = right.clone().negate().add(back.clone().multiplyScalar(0.5)).normalize().multiplyScalar(CONST.FLARE_EJECTION_SPEED);
    const leftPos = jet.position.clone().add(right.clone().negate().multiplyScalar(CONST.FLARE_WING_OFFSET));
    newFlares.push({
      id: `f_${jet.id}_${Date.now()}_l`,
      position: leftPos,
      velocity: leftVel,
      life: CONST.FLARE_LIFESPAN
    });

    // Right flare
    const rightVel = right.clone().add(back.clone().multiplyScalar(0.5)).normalize().multiplyScalar(CONST.FLARE_EJECTION_SPEED);
    const rightPos = jet.position.clone().add(right.clone().multiplyScalar(CONST.FLARE_WING_OFFSET));
    newFlares.push({
      id: `f_${jet.id}_${Date.now()}_r`,
      position: rightPos,
      velocity: rightVel,
      life: CONST.FLARE_LIFESPAN
    });

    jet.flareState.flaresLeft -= 2;
    if (jet.flareState.flaresLeft <= 0) {
      jet.flareState.deploying = false;
    } else {
      jet.flareState.nextFlareTimer = CONST.TIME_BETWEEN_FLARE_PAIRS;
    }
  }
}
