# Phase 2: Deduplication Plan

**Current State:**
- game-main.js: 2070 lines, 73KB (monolithic, has ALL code inline)
- Extracted modules: 14 modules created in Phase 1 (scene-setup, mesh-manager, radar, event-log, etc.)
- **Problem:** game-main.js has NOT been updated to use the extracted modules - all code is duplicated

**Goal:** Remove duplicate code from game-main.js and use the extracted modules

---

## Functions to REMOVE from game-main.js (Already in Modules)

###  Lines 1224-1236: `loadJetFighterModel()`
**Module:** `src/systems/jet-loader.js` ✅
**Action:** DELETE - Already imported

### Lines 1238-1469: `createJetMesh(jet)`
**Module:** `src/systems/mesh-manager.js` ✅
**Action:** DELETE - Already imported

### Lines 1471-1476: `createTracerMesh(tracer)`
**Module:** `src/systems/mesh-manager.js` ✅
**Action:** DELETE - Already imported

### Lines 1479-1486: `createMissileMesh(missile)`
**Module:** `src/systems/mesh-manager.js` ✅
**Action:** DELETE - Already imported

### Lines 1487-1492: `createFlareMesh(flare)`
**Module:** `src/systems/mesh-manager.js` ✅
**Action:** DELETE - Already imported

### Lines 1495-1515: `createTargetMarker(color, scale)`
**Module:** `src/systems/mesh-manager.js` ✅
**Action:** DELETE - Already imported

### Lines 1520-1709: `updatePanoramicRadar()`
**Module:** `src/systems/radar.js` ✅
**Action:** DELETE - Already imported

### Lines 1713-1843: `updateRadialRadar()`
**Module:** `src/systems/radar.js` ✅
**Action:** DELETE - Already imported

### Lines 1846-1856: `updateCameraModeIndicator()`
**Module:** `src/ui/camera-indicator.js` ✅
**Action:** DELETE - Already imported

### Lines 1859-2070: Event log functions
**Module:** `src/ui/event-log.js` ✅
**Functions:** `addEvent()`, `queueRadioChat()`, `processRadioQueue()`, `displayRadioChat()`, `updateEventMonitor()`, `clearEventLog()`
**Action:** DELETE - Already imported

### Lines 121-221: `createIslands()`
**Module:** `src/systems/scene-setup.js` ✅
**Action:** DELETE - Already in module

### Lines 224-471: `setupScene()`
**Module:** `src/systems/scene-setup.js` ✅
**Action:** REPLACE with call to `setupSceneModule(container)` (already imported)

---

## Estimated Result After Deduplication

**Lines to REMOVE:** ~1650 lines
**Lines to KEEP:** ~420 lines

### What STAYS in game-main.js:
1. **Imports** (15 lines) - Already updated ✅
2. **Global variables** (50 lines) - Game state, cameras, mesh caches
3. **startGame()** (25 lines) - Game initialization
4. **stopGame()** (15 lines) - Cleanup
5. **animate()** (10 lines) - Game loop
6. **updateGame()** (280 lines) - Game state updates (camera, jets, physics, weapons)
7. **renderScene()** (455 lines) - Mesh updates and rendering

**Total:** ~850 lines (still too big, but Phase 2A goal)

---

## Phase 2 Sub-Phases

### Phase 2A: Remove Duplicates (This phase)
- Remove ~1200 lines of duplicate functions
- Result: ~850 lines

### Phase 2B: Extract renderScene() (Future)
- Move renderScene() to src/systems/renderer.js
- Result: ~400 lines

### Phase 2C: Extract updateGame() logic (Future)
- Extract camera updates to src/systems/camera.js
- Extract game loop to src/systems/loop.js
- Result: ~100 lines (TARGET)

---

## Execution Plan for Phase 2A

1. Remove lines 1224-2070 (all duplicate functions)
2. Update setupScene() call to use setupSceneModule()
3. Test game
4. Verify all features work

**Ready to proceed?**
