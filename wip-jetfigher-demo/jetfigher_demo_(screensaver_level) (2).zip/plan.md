# TINS - Targeted Intercept Navigation System
## Implementation Plan for Browser-Based HTML5 Game

**Target Environment:** Vite MPA + TypeScript/JavaScript
**Working Directory:** `/home/runtime/.seadata/apps/app-1768839129626-139aa28a`
**Platform:** Browser-based HTML5 Canvas game
**Inspired by:** Ace Combat's lock-on missile targeting and arcade dogfighting

---

## Project Overview

Adapt the TINS (Targeted Intercept Navigation System) concept into a browser-based HTML5 game that recreates Ace Combat's signature gameplay:
- Radar-based target acquisition and lock-on progression
- Multi-missile barrage system ("missile spam")
- Arcade flight physics with high-G maneuvers
- Cinematic camera angles and visual effects
- Countermeasures and evasion mechanics

### Core Design Principles
- **Arcade over Realism**: Fun, responsive controls with impossible maneuvers
- **Browser-Native**: No plugins, runs in any modern browser
- **Modular Architecture**: Separation of physics, rendering, input, and game logic
- **Performance-First**: Smooth 60 FPS even with multiple missiles and effects

---

## Technical Architecture

### Technology Stack
- **TypeScript** - Type-safe game logic
- **HTML5 Canvas** - 2D rendering (with pseudo-3D projection)
- **Vite** - Development server and bundling
- **Web Audio API** - Lock-on tones, missile sounds, radio chatter
- **No external game engines** - Pure Canvas API for maximum control

### File Structure
```
./
├── index.html          # Main entry point
├── manifest.json       # App metadata
├── main.ts            # Game initialization and main loop
├── style.css          # UI styling
├── src/
│   ├── core/
│   │   ├── Aircraft.ts        # Aircraft entity with physics
│   │   ├── Missile.ts         # Missile entity with homing logic
│   │   ├── Radar.ts           # Target scanning and tracking
│   │   ├── LockSystem.ts      # Lock-on progression logic
│   │   └── PhysicsEngine.ts   # Flight dynamics and collisions
│   ├── systems/
│   │   ├── InputHandler.ts    # Keyboard/mouse/gamepad input
│   │   ├── Renderer.ts        # Canvas drawing and camera
│   │   ├── AudioManager.ts    # Sound effects and music
│   │   └── HUD.ts             # Heads-up display elements
│   ├── ai/
│   │   ├── EnemyAI.ts         # Enemy aircraft behavior
│   │   └── MissileGuidance.ts # Proportional navigation
│   ├── game/
│   │   ├── GameState.ts       # Game state management
│   │   ├── Mission.ts         # Mission objectives and waves
│   │   └── ScoreSystem.ts     # Combo and scoring
│   └── utils/
│       ├── Vector3D.ts        # 3D vector math
│       ├── Math.ts            # Utility functions
│       └── Config.ts          # Game configuration
└── assets/
    ├── audio/
    │   ├── lock-search.mp3    # Radar searching tone
    │   ├── lock-acquired.mp3  # Hard lock tone
    │   ├── missile-fire.mp3   # Launch sound
    │   └── explosion.mp3      # Impact effect
    └── sprites/
        ├── aircraft.png       # Aircraft sprites
        ├── missile.png        # Missile sprite
        └── hud-elements.png   # UI graphics
```

---

## Implementation Phases

### Phase 1: Core Foundation (Week 1)
**Goal:** Establish rendering pipeline and basic entities

#### Tasks:
1. **Project Setup**
   - Create `index.html` with fullscreen canvas
   - Set up TypeScript with Vite configuration
   - Initialize main game loop with fixed timestep

2. **Vector Math Library** (`src/utils/Vector3D.ts`)
   - 3D vector class with add, subtract, scale, normalize
   - Dot product, cross product, distance calculations
   - Rotation matrices for aircraft orientation

3. **Basic Renderer** (`src/systems/Renderer.ts`)
   - Canvas setup with 2D context
   - Pseudo-3D projection (orthographic or simple perspective)
   - Camera system (follow player, missile cam, cinematic angles)
   - Draw basic shapes (triangles for aircraft, lines for missiles)

4. **Aircraft Entity** (`src/core/Aircraft.ts`)
   - Position, velocity, acceleration (Vector3D)
   - Orientation (pitch, yaw, roll)
   - Team identifier (player, ally, enemy)
   - Health and status

5. **Input Handler** (`src/systems/InputHandler.ts`)
   - Keyboard controls (WASD for pitch/yaw, Q/E for roll)
   - Mouse input for camera/targeting
   - Input state buffering

**Deliverable:** Blue triangle (player aircraft) moving in 3D space with camera following

---

### Phase 2: Radar and Targeting (Week 2)
**Goal:** Implement target acquisition and lock-on system

#### Tasks:
1. **Radar System** (`src/core/Radar.ts`)
   ```typescript
   interface RadarConfig {
     rangeKm: number;        // Detection range
     scanAngleDeg: number;   // Forward cone angle
     updateRate: number;     // Scans per second
   }

   class Radar {
     scan(origin: Aircraft, targets: Aircraft[]): Aircraft[];
     getClosestThreat(): Aircraft | null;
     cycleTarget(): void;
   }
   ```

2. **Lock-On System** (`src/core/LockSystem.ts`)
   - States: SEARCH → SOFT_LOCK → HARD_LOCK
   - Lock progress (0-100%) based on:
     - Target in radar cone
     - Target distance
     - Target angle rate
   - Lock break conditions:
     - Target leaves radar cone
     - High angular velocity
     - Countermeasures deployed

3. **HUD System** (`src/systems/HUD.ts`)
   - Target boxes (yellow = detected, orange = soft lock, red = hard lock)
   - Lock progress circle
   - Missile count display
   - Speed/altitude indicators
   - Minimap/radar display

4. **Audio Manager** (`src/systems/AudioManager.ts`)
   - Load and play lock-on tones
   - Rising pitch as lock progresses
   - 3D positional audio for missiles

**Deliverable:** Player can scan, acquire, and lock enemy aircraft with visual/audio feedback

---

### Phase 3: Missile System (Week 3)
**Goal:** Implement homing missiles with realistic guidance

#### Tasks:
1. **Missile Entity** (`src/core/Missile.ts`)
   ```typescript
   interface MissileConfig {
     thrust: number;          // Acceleration (m/s²)
     dragCoeff: number;       // Air resistance
     maxSpeed: number;        // Terminal velocity
     maxG: number;            // Turn rate limit
     fuelTime: number;        // Boost duration
     proximityFuse: number;   // Detonation radius
   }

   class Missile {
     position: Vector3D;
     velocity: Vector3D;
     target: Aircraft;
     guidanceMode: 'LEAD' | 'PURE' | 'PROPORTIONAL';
   }
   ```

2. **Guidance Algorithm** (`src/ai/MissileGuidance.ts`)
   - **Proportional Navigation**:
     ```
     acceleration = N × closingSpeed × lineOfSightRate
     ```
   - Lead pursuit for fast targets
   - Terminal guidance for close range
   - Fuel depletion → gravity ballistics

3. **Missile Physics** (integrate with `PhysicsEngine.ts`)
   - Thrust vector along missile axis
   - Drag force opposing velocity
   - G-limit constraints on turning
   - Proximity detection and detonation

4. **Visual Effects**
   - Smoke trail particles
   - Launch flash
   - Explosion animation
   - Missile camera mode (switch to missile POV)

**Deliverable:** Functional missiles that chase and intercept targets with realistic physics

---

### Phase 4: Evasion and Countermeasures (Week 4)
**Goal:** Add defensive mechanics and advanced maneuvers

#### Tasks:
1. **Arcade Flight Model** (`src/core/PhysicsEngine.ts`)
   - Speed-based turn rate (slower = tighter turns)
   - G-force limits (player can pull 12G, missiles 30G)
   - Energy management (trading speed for altitude)
   - Post-stall recovery

2. **Countermeasures** (extend `Aircraft.ts`)
   ```typescript
   interface Countermeasures {
     flares: number;         // IR decoys
     chaff: number;          // Radar decoys
     cooldown: number;       // Deploy rate limit
   }

   deployFlares(): void;  // Success chance vs missile seeker type
   ```

3. **Evasive Maneuvers**
   - Barrel roll (rapid roll + pitch)
   - High-G turn (bleed speed for tight turn)
   - Vertical loop / Immelmann
   - (Optional) PSM: Cobra, Kulbit (advanced, low priority)

4. **Missile Evasion Logic** (AI and player)
   - Detect incoming missiles
   - Calculate optimal evasion vector
   - Deploy countermeasures at correct timing
   - Terrain masking (fly low to break lock)

**Deliverable:** Player can evade missiles; enemies use countermeasures

---

### Phase 5: AI and Combat (Week 5)
**Goal:** Intelligent enemy aircraft and engaging dogfights

#### Tasks:
1. **Enemy AI** (`src/ai/EnemyAI.ts`)
   - Behaviors:
     - **Pursuit**: Chase player, maintain firing position
     - **Evasion**: Break locks, deploy countermeasures
     - **Cooperative**: Wingman tactics, pincer attacks
   - State machine: PATROL → ENGAGE → EVADE → REGROUP

2. **Difficulty Scaling**
   - Rookie: Slow reactions, poor aim
   - Veteran: Uses countermeasures, basic tactics
   - Ace: Perfect evasion, multi-lock capability, PSM

3. **Multi-Lock System** (extend `LockSystem.ts`)
   - Allow locking 4-8 targets simultaneously
   - Fire salvos (ripple fire)
   - Track multiple missiles in-flight

4. **Damage Model**
   - Hit detection (proximity + raycast)
   - Damage types (missile, gun, collision)
   - Aircraft states: HEALTHY → DAMAGED → CRITICAL → DESTROYED

**Deliverable:** Challenging AI opponents that dogfight dynamically

---

### Phase 6: Mission System and Polish (Week 6)
**Goal:** Structured gameplay with objectives and presentation

#### Tasks:
1. **Mission Framework** (`src/game/Mission.ts`)
   ```typescript
   interface Mission {
     name: string;
     objectives: Objective[];
     waves: EnemyWave[];
     timeLimit?: number;
     briefing: string;
   }

   interface Objective {
     type: 'DESTROY_ALL' | 'DEFEND' | 'SURVIVE';
     target?: string;
     completed: boolean;
   }
   ```

2. **Score and Combo System** (`src/game/ScoreSystem.ts`)
   - Points for kills, style (multi-lock, evasion)
   - Combo multiplier (sustained combat)
   - Rank: D, C, B, A, S

3. **Cinematic Elements**
   - Slow-motion on critical hits
   - Dynamic camera cuts (missile tracking, kill cam)
   - Radio chatter (procedural or scripted messages)

4. **UI/UX Polish**
   - Main menu (start, settings, aircraft selection)
   - Mission briefing screen
   - Results screen (score, rank, stats)
   - Pause menu

5. **Performance Optimization**
   - Object pooling (missiles, particles)
   - Spatial partitioning for collision detection
   - Throttle rendering for off-screen entities

**Deliverable:** Complete playable game with missions and progression

---

## Key Technical Challenges

### Challenge 1: Pseudo-3D Rendering
**Problem:** Canvas is 2D, but we need 3D combat
**Solution:**
- Use orthographic or simple perspective projection
- Sort entities by Z-depth for draw order
- Implement camera matrix transformations
- Consider using 2.5D (isometric) if full 3D is too complex

### Challenge 2: Missile Homing Performance
**Problem:** Complex physics for 10+ missiles causes lag
**Solution:**
- Fixed timestep physics (60 Hz)
- Simplified guidance when off-screen
- Object pooling to avoid garbage collection
- Web Workers for physics calculations (advanced)

### Challenge 3: Lock-On Feel
**Problem:** Making lock-on feel satisfying like Ace Combat
**Solution:**
- Audio feedback with rising pitch
- Visual feedback (pulsing target box, screen flash)
- Haptic feedback (gamepad rumble)
- Smooth interpolation of lock progress

### Challenge 4: Browser Compatibility
**Problem:** Audio latency, input lag, performance variance
**Solution:**
- Use Web Audio API with preloaded buffers
- RequestAnimationFrame with deltaTime
- Progressive enhancement (gamepad optional)
- Test on Chrome, Firefox, Safari

---

## Configuration System

Create `src/utils/Config.ts` with tunable parameters:

```typescript
export const GameConfig = {
  physics: {
    gravity: 9.81,           // m/s²
    airDensity: 1.225,       // kg/m³
    maxAltitude: 15000,      // meters
  },

  player: {
    maxSpeed: 800,           // m/s (Mach 2.3)
    maxG: 12,                // G-force limit
    rollRate: 180,           // deg/s
    pitchRate: 90,           // deg/s
    missiles: 60,            // Starting count
    flares: 30,
  },

  radar: {
    range: 80000,            // meters
    scanAngle: 60,           // degrees
    updateRate: 10,          // Hz
  },

  missile: {
    thrust: 150,             // m/s²
    maxSpeed: 1200,          // m/s (Mach 3.5)
    maxG: 30,                // Turn limit
    fuelTime: 8,             // seconds
    proximityFuse: 10,       // meters
    navigationConstant: 4,   // Proportional nav gain
  },

  rendering: {
    fov: 90,                 // degrees
    farClip: 100000,         // meters
    targetFPS: 60,
  },
};
```

---

## Minimum Viable Product (MVP)

For initial playable demo, prioritize:
1. ✅ Player aircraft with arcade flight model
2. ✅ 3-5 enemy aircraft with basic AI
3. ✅ Radar scanning and single-target lock
4. ✅ Working missile physics with homing
5. ✅ HUD with targeting reticle and lock indicator
6. ✅ Audio feedback (lock tone, missile fire, explosion)
7. ✅ Simple score system
8. ✅ One playable mission ("Destroy all enemies")

**Cut from MVP** (add later):
- Multi-lock system
- Countermeasures
- PSM maneuvers
- Cinematic cameras
- Multiple aircraft types
- Campaign mode

---

## Testing Strategy

### Unit Tests
- Vector math operations
- Guidance algorithms
- Lock-on state transitions
- Collision detection

### Integration Tests
- Full dogfight simulation (player vs AI)
- Mission completion flow
- Performance benchmarks (30+ entities at 60 FPS)

### Playtesting Focus
- Controls feel responsive?
- Lock-on satisfying?
- Difficulty balanced?
- Performance smooth?

---

## Assets Needed

### Audio (Web Audio API compatible formats)
- Lock tones (search, soft, hard): 3 × .mp3
- Missile fire: 1 × .mp3
- Explosion: 1 × .mp3
- Engine sound (loopable): 1 × .mp3
- Radio chatter (optional): 5-10 × .mp3

### Graphics (Canvas 2D sprites/shapes)
- Aircraft silhouettes (player, enemy): 2D sprites or procedural triangles
- Missile sprite: Simple elongated shape
- Particle effects: Small circles for smoke/explosion
- HUD elements: Can be drawn programmatically

**Note:** For MVP, use geometric shapes (triangles, circles) instead of detailed sprites.

---

## Deployment

### Build Process
```bash
npm run build
# Output to dist/ directory
```

### Hosting
- Static hosting via Vite preview
- Works with file:// protocol (no server needed)
- Can be deployed to GitHub Pages, Netlify, etc.

### Distribution
- Single HTML file with inlined assets (optional)
- Progressive Web App (PWA) for offline play
- Share via URL (no installation required)

---

## Future Enhancements (Post-Launch)

### v1.1 Features
- Gamepad support (Xbox/PS controllers)
- Multiple aircraft with unique stats
- Special weapons (laser, railgun, multi-lock)
- More mission types (escort, defense, time attack)

### v2.0 Features
- Multiplayer (WebRTC peer-to-peer dogfights)
- Procedural mission generator
- Mod support (JSON aircraft/weapon definitions)
- VR support (WebXR API)

### Advanced Features
- 3D rendering with Three.js or Babylon.js
- Terrain/ground targets
- Weather effects (clouds, rain, turbulence)
- Narrative campaign with voice acting

---

## Success Metrics

**Technical:**
- Maintains 60 FPS with 10 aircraft + 20 missiles
- Input latency < 16ms
- Lock-on response time < 0.5s

**Gameplay:**
- Players can complete first mission within 3 attempts
- Lock-on feel rated 8/10 or higher
- AI provides challenge without frustration

**Engagement:**
- Average play session > 15 minutes
- Replay rate > 50% for mission variety

---

## Risk Mitigation

| Risk | Impact | Mitigation |
|------|--------|------------|
| Performance issues on low-end devices | High | Object pooling, LOD system, settings menu |
| Complex physics causes bugs | Medium | Extensive unit tests, config tweaks |
| Audio latency ruins lock-on feel | High | Preload all sounds, use AudioContext |
| Controls feel unresponsive | High | Playtesting, tunable sensitivity |
| Scope creep delays launch | Medium | Strict MVP definition, feature freeze |

---

## Final Notes

This plan adapts TINS from a Python library to a **browser-based TypeScript game** that preserves the core Ace Combat inspiration:
- Satisfying lock-on and missile spam
- Arcade flight physics
- Cinematic presentation
- High replayability

The modular architecture allows for incremental development and easy extension. Start with Phase 1-3 for a technical proof-of-concept, then add AI and missions for a full game experience.

**Next Steps:**
1. Review and approve this plan
2. Set up initial project structure
3. Begin Phase 1 implementation
4. Iterate based on playtesting feedback

**"Missiles away! Fox 2!"** 🚀
