import { createInitialState } from './src/core/state.js';
import * as AI from './src/ai/enemy-ai.js';
import * as Physics from './src/core/physics.js';
import * as Weapons from './src/ai/weapons.js';
import { PlayerControls, createHUD, updateHUD } from './src/systems/controls.js';
import * as CONST from './src/game/constants.js';
import * as Radio from './src/game/radio.js';
import { loadJetFighterModel, getJetFighterModel } from './src/systems/jet-loader.js';
import { updateCameraModeIndicator } from './src/ui/camera-indicator.js';
import { addEvent, queueRadioChat, processRadioQueue, clearEventLog } from './src/ui/event-log.js';
import { updatePanoramicRadar, updateRadialRadar } from './src/systems/radar.js';
import { createJetMesh, createTracerMesh, createMissileMesh, createFlareMesh, createTargetMarker, meshCaches } from './src/systems/mesh-manager.js';
import { setupScene as setupSceneModule, cleanupScene } from './src/systems/scene-setup.js';
import { updateOverviewCamera, updateFreeCamera, updateThirdPersonCamera } from './src/systems/camera.js';
import { renderScene } from './src/systems/renderer.js';

let gameState = null;
let playerControls = null;
let scene, camera, renderer;
let tempMatrix, targetQuaternion;
let animationId = null;

// Track if event listeners have been set up
let eventListenersSetup = false;

// Camera system
let currentCameraMode = 'overview'; // 'overview', 'thirdPerson', or 'free'
let thirdPersonCamera = null;
let freeCamera = null;
let freeCameraControls = {
  moveForward: false,
  moveBackward: false,
  moveLeft: false,
  moveRight: false,
  moveUp: false,
  moveDown: false,
  mouseMovement: { x: 0, y: 0 },
  rotation: { yaw: 0, pitch: 0 },
  isPointerLocked: false
};

// Green team target swap timer
let greenSwapTimer = 10; // seconds

// Mesh caching (imported from mesh-manager)
const { jetMeshes, tracerMeshes, missileMeshes, flareMeshes, jetTrails, missileTrails, flareTrails, targetMarkers } = meshCaches;

// Sky and water references
let sky, sun, water;
let islands = [];

export function startGame() {
  // Clear event log when starting a new game
  clearEventLog();

  // Initialize game state
  gameState = createInitialState();
  playerControls = new PlayerControls();

  addEvent('system', '🎮 NEW GAME STARTED');

  // Load jet fighter model first
  loadJetFighterModel().then(() => {
    addEvent('system', '🛠️ SCENE INITIALIZED');

    // Setup Three.js scene
    const container = document.getElementById('gameContainer');
    const sceneData = setupSceneModule(container);
    scene = sceneData.scene;
    camera = sceneData.camera;
    renderer = sceneData.renderer;
    thirdPersonCamera = sceneData.thirdPersonCamera;
    freeCamera = sceneData.freeCamera;
    tempMatrix = sceneData.tempMatrix;
    targetQuaternion = sceneData.targetQuaternion;

    // Setup event listeners only once
    setupEventListeners();

    // HUD removed - not working
    // Start game loop
    animate();

    addEvent('system', '▶️ GAME LOOP STARTED');
  });
}

export function stopGame() {
  if (animationId) {
    cancelAnimationFrame(animationId);
    animationId = null;
  }

  // Clean up scene - only remove the WebGL canvas, keep the cameraModeIndicator and radar canvases
  if (renderer) {
    const container = document.getElementById('gameContainer');
    const existingCanvas = container.querySelector('canvas:not(#panoramicRadar):not(#radialRadar)');
    if (existingCanvas) {
      existingCanvas.remove();
    }
    renderer.dispose();
    renderer = null;
  }

  // Clean up scene objects
  if (scene) {
    scene.clear();
    scene = null;
  }

  // Clear mesh caches
  jetMeshes.clear();
  tracerMeshes.clear();
  missileMeshes.clear();
  flareMeshes.clear();
  jetTrails.clear();
  missileTrails.clear();
  flareTrails.clear();
  targetMarkers.clear();

  gameState = null;
  playerControls = null;
  currentCameraMode = 'overview';
  updateCameraModeIndicator(currentCameraMode);
}

// Setup event listeners only once
function setupEventListeners() {
  if (eventListenersSetup) return;
  eventListenersSetup = true;

  // Camera toggle with 'C' and 'F' keys, and Esc to return to menu
  window.addEventListener('keydown', (e) => {
    if (e.key === 'c' || e.key === 'C') {
      currentCameraMode = currentCameraMode === 'overview' ? 'thirdPerson' : 'overview';
      updateCameraModeIndicator(currentCameraMode);
      addEvent('system', `📷 CAMERA: ${currentCameraMode === 'overview' ? 'OVERVIEW' : 'THIRD PERSON'}`);
      if (freeCameraControls.isPointerLocked) {
        document.exitPointerLock();
      }
    }
    if (e.key === 'f' || e.key === 'F') {
      currentCameraMode = currentCameraMode === 'free' ? 'overview' : 'free';
      updateCameraModeIndicator(currentCameraMode);
      addEvent('system', `📷 CAMERA: ${currentCameraMode === 'free' ? 'FREE CAM' : 'OVERVIEW'}`);
      if (currentCameraMode === 'free') {
        document.body.requestPointerLock();
      } else if (freeCameraControls.isPointerLocked) {
        document.exitPointerLock();
      }
    }
    if (e.key === 'Escape') {
      if (freeCameraControls.isPointerLocked) {
        document.exitPointerLock();
      }
      stopGame();
      document.getElementById('mainMenu').style.display = 'flex';
      document.getElementById('gameContainer').classList.remove('active');
    }

    // Free camera movement controls
    if (currentCameraMode === 'free') {
      switch(e.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          freeCameraControls.moveForward = true;
          break;
        case 'ArrowDown':
        case 's':
        case 'S':
          freeCameraControls.moveBackward = true;
          break;
        case 'ArrowLeft':
        case 'a':
        case 'A':
          freeCameraControls.moveLeft = true;
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          freeCameraControls.moveRight = true;
          break;
        case 'q':
        case 'Q':
          freeCameraControls.moveUp = true;
          break;
        case 'e':
        case 'E':
          freeCameraControls.moveDown = true;
          break;
      }
    }
  });

  window.addEventListener('keyup', (e) => {
    if (currentCameraMode === 'free') {
      switch(e.key) {
        case 'ArrowUp':
        case 'w':
        case 'W':
          freeCameraControls.moveForward = false;
          break;
        case 'ArrowDown':
        case 's':
        case 'S':
          freeCameraControls.moveBackward = false;
          break;
        case 'ArrowLeft':
        case 'a':
        case 'A':
          freeCameraControls.moveLeft = false;
          break;
        case 'ArrowRight':
        case 'd':
        case 'D':
          freeCameraControls.moveRight = false;
          break;
        case 'q':
        case 'Q':
          freeCameraControls.moveUp = false;
          break;
        case 'e':
        case 'E':
          freeCameraControls.moveDown = false;
          break;
      }
    }
  });

  // Mouse movement for free camera
  document.addEventListener('mousemove', (e) => {
    if (currentCameraMode === 'free' && freeCameraControls.isPointerLocked) {
      const sensitivity = 0.002;
      freeCameraControls.rotation.yaw -= e.movementX * sensitivity;
      freeCameraControls.rotation.pitch -= e.movementY * sensitivity;
      freeCameraControls.rotation.pitch = Math.max(-Math.PI / 2, Math.min(Math.PI / 2, freeCameraControls.rotation.pitch));
    }
  });

  // Pointer lock change events
  document.addEventListener('pointerlockchange', () => {
    freeCameraControls.isPointerLocked = document.pointerLockElement === document.body;
  });

  // Handle window resize
  window.addEventListener('resize', () => {
    if (!camera || !renderer) return;
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    if (thirdPersonCamera) {
      thirdPersonCamera.aspect = window.innerWidth / window.innerHeight;
      thirdPersonCamera.updateProjectionMatrix();
    }
    if (freeCamera) {
      freeCamera.aspect = window.innerWidth / window.innerHeight;
      freeCamera.updateProjectionMatrix();
    }
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
}


function animate() {
  animationId = requestAnimationFrame(animate);

  const delta = Math.min(0.1, 1 / 60);

  if (!gameState) return;

  updateGame(delta);
  renderScene(gameState, scene, renderer, camera, thirdPersonCamera, freeCamera, currentCameraMode, meshCaches);
}

function updateGame(delta) {
  // Update player input
  const input = playerControls.update();

  // Process radio chat queue
  processRadioQueue();

  // Handle target switch request
  if (input.targetSwitchRequest) {
    const playerJet = gameState.jets.find(j => j.id === 'green_0');
    const wingmanJet = gameState.jets.find(j => j.id === 'green_1');
    if (playerJet && wingmanJet) {
      // Swap targets between player and wingman
      const tempTarget = playerJet.targetId;
      playerJet.targetId = wingmanJet.targetId;
      wingmanJet.targetId = tempTarget;
    }
  }

  // Calculate green barycenter for AI and update overview camera
  const greenBarycenter = updateOverviewCamera(camera, gameState, delta);

  // Update free camera position and rotation
  updateFreeCamera(freeCamera, freeCameraControls, delta, currentCameraMode);

  // Update third-person camera pitch compensation
  updateThirdPersonCamera(thirdPersonCamera, scene, gameState, jetMeshes, delta);

  // Green team target swapping (every 10 seconds)
  greenSwapTimer -= delta;
  if (greenSwapTimer <= 0) {
    greenSwapTimer = 10; // Reset timer
    const greenJetsToSwap = gameState.jets.filter(j => j.team === 'green' && !j.isDestroyed && !j.isWrecked);
    if (greenJetsToSwap.length === 2) {
      const tempTargetId = greenJetsToSwap[0].targetId;
      greenJetsToSwap[0].targetId = greenJetsToSwap[1].targetId;
      greenJetsToSwap[1].targetId = tempTargetId;
      console.log('Green team swapped targets:', greenJetsToSwap[0].id, '→', greenJetsToSwap[0].targetId, '|', greenJetsToSwap[1].id, '→', greenJetsToSwap[1].targetId);

      queueRadioChat('green', 'swap');
    }
  }

  // Process each jet (ALL use AI including green_0)
  gameState.jets.forEach(jet => {
    if (jet.isWrecked || jet.isDestroyed) {
      // Track respawn
      const wasWrecked = jet.isWrecked;
      Physics.handleRespawn(jet);

      // Detect if jet just respawned
      if (wasWrecked && !jet.isWrecked) {
        queueRadioChat(jet.team, 'respawn', jet.id);
      }

      Physics.updateJetPhysics(jet, delta);
      return;
    }

    // AI behavior for ALL jets (including player's green_0)
    AI.handleRedTeamRoleSwap(jet, gameState.jets, delta);
    AI.handleGreenTargetAssignment(jet, gameState.jets);

    const steering = AI.calculateAISteering(jet, gameState.jets, greenBarycenter, tempMatrix, targetQuaternion);
    if (steering) {
      jet.quaternion.slerp(steering.targetQuaternion, delta * steering.turnSpeed);
    }

    // Update physics (automated for ALL)
    Physics.updateJetPhysics(jet, delta);

    // Weapons (automated for ALL attacking jets)
    if (jet.aiState === 'attacking') {
      const weaponType = Weapons.fireBurst(jet, gameState.jets, gameState.tracers);
      if (weaponType === 'missile') {
        Weapons.fireMissile(jet, gameState.jets, gameState.missiles);
        queueRadioChat(jet.team, 'fox2', jet.id);
      } else if (weaponType === 'guns') {
        queueRadioChat(jet.team, 'guns', jet.id);
      }

      // Check for gun kills
      const killInfo = Weapons.updateBurst(jet, gameState.jets, gameState.tracers, delta);
      if (killInfo) {
        const killer = gameState.jets.find(j => j.id === killInfo.killerId);
        const victim = gameState.jets.find(j => j.id === killInfo.victimId);
        if (killer && victim) {
          queueRadioChat(killer.team, 'destroy', killer.id);
        }
      }
    }

    Weapons.deployFlares(jet, gameState.flares, delta);
  });

  // Track jets before missile detonation to detect kills
  const jetsBeforeDetonation = new Map();
  gameState.jets.forEach(jet => {
    jetsBeforeDetonation.set(jet.id, { isWrecked: jet.isWrecked, isDestroyed: jet.isDestroyed });
  });

  // Update missiles
  gameState.missiles = Physics.checkMissileDetonation(gameState.missiles, gameState.jets);

  // Detect missile kills
  gameState.jets.forEach(jet => {
    const before = jetsBeforeDetonation.get(jet.id);
    if (before && !before.isWrecked && jet.isWrecked) {
      // Find the attacker and add destroy radio chat
      const attacker = gameState.jets.find(j => j.targetId === jet.id && j.team !== jet.team && !j.isWrecked);
      if (attacker) {
        queueRadioChat(attacker.team, 'destroy', attacker.id);
      }
    }
  });

  gameState.missiles.forEach(m => Physics.updateMissilePhysics(m, gameState.jets, delta));
  gameState.missiles = gameState.missiles.filter(m => m.life > 0);

  // Update tracers
  gameState.tracers.forEach(t => Physics.updateTracerPhysics(t, delta));
  gameState.tracers = gameState.tracers.filter(t => t.life > 0);

  // Update flares
  gameState.flares.forEach(f => Physics.updateFlarePhysics(f, delta));
  gameState.flares = gameState.flares.filter(f => f.life > 0);

}