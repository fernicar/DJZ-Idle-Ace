# game-main.js Split Execution Plan
**Total Lines:** 2070
**Target:** 10 modules
**Status:** Phase 2 in progress

---

## Function Inventory (from game-main.js)

| Line | Function | Target Module | Dependencies |
|------|----------|---------------|--------------|
| 54 | `startGame()` | `src/main.js` | All modules |
| 79 | `stopGame()` | `src/main.js` | renderer, scene |
| 121 | `createIslands()` | `src/systems/scene-setup.js` | THREE.js |
| 222 | `setupScene()` | `src/systems/scene-setup.js` | THREE.js, createIslands |
| 472 | `animate()` | `src/systems/loop.js` | updateGame, renderScene |
| 483 | `updateGame(delta)` | `src/systems/loop.js` | All game systems |
| 774 | `renderScene()` | `src/systems/renderer.js` | mesh-manager, camera |
| 1228 | `loadJetFighterModel()` | ✅ `src/systems/jet-loader.js` | DONE |
| 1238 | `createJetMesh(jet)` | `src/systems/mesh-manager.js` | jet-loader, THREE |
| 1469 | `createTracerMesh()` | `src/systems/mesh-manager.js` | THREE |
| 1477 | `createMissileMesh()` | `src/systems/mesh-manager.js` | THREE |
| 1485 | `createFlareMesh()` | `src/systems/mesh-manager.js` | THREE |
| 1493 | `createTargetMarker()` | `src/systems/mesh-manager.js` | THREE |
| 1518 | `updatePanoramicRadar()` | `src/systems/radar.js` | gameState |
| 1711 | `updateRadialRadar()` | `src/systems/radar.js` | gameState |
| 1844 | `updateCameraModeIndicator()` | `src/ui/camera-indicator.js` | DOM |
| 1943 | `addEvent()` | `src/ui/event-log.js` | DOM |
| 1955 | `queueRadioChat()` | `src/ui/event-log.js` | Radio module |
| 1978 | `processRadioQueue()` | `src/ui/event-log.js` | Radio module |
| 2002 | `displayRadioChat()` | `src/ui/event-log.js` | Radio module, DOM |
| 2031 | `updateEventMonitor()` | `src/ui/event-log.js` | DOM |
| 2064 | `clearEventLog()` | `src/ui/event-log.js` | DOM |

---

## Module Extraction Order

### ✅ Step 1: jet-loader.js (DONE)
- **Lines:** 1228-1236 (9 lines)
- **Variables:** `jetFighterModel`
- **Functions:** `loadJetFighterModel()`, `getJetFighterModel()`, `isModelLoaded()`
- **Status:** ✅ Created at `src/systems/jet-loader.js`

### Step 2: camera-indicator.js
- **Lines:** 1844-1942 (~100 lines)
- **Function:** `updateCameraModeIndicator()`
- **Dependencies:** None (pure DOM)
- **Exports:** `updateCameraModeIndicator(mode)`

### Step 3: event-log.js
- **Lines:** 1943-2070 (~127 lines)
- **Functions:**
  - `addEvent(team, text)`
  - `queueRadioChat(team, eventType, sourceJet)`
  - `processRadioQueue()`
  - `displayRadioChat(chatData)`
  - `updateEventMonitor()`
  - `clearEventLog()`
- **Variables:** Event log arrays
- **Dependencies:** `Radio` module
- **Exports:** All 6 functions

### Step 4: radar.js
- **Lines:** 1518-1710 (panoramic) + 1711-1843 (radial) = ~326 lines
- **Functions:**
  - `updatePanoramicRadar()`
  - `updateRadialRadar()`
- **Dependencies:** `gameState`, THREE.js
- **Exports:** Both functions

### Step 5: mesh-manager.js
- **Lines:** 1238-1517 (~280 lines) - All mesh creation functions
- **Functions:**
  - `createJetMesh(jet)`
  - `createTracerMesh(tracer)`
  - `createMissileMesh(missile)`
  - `createFlareMesh(flare)`
  - `createTargetMarker(color, scale)`
- **Variables:** Mesh caches (jetMeshes, tracerMeshes, etc.)
- **Dependencies:** `jet-loader`, THREE.js, CONST
- **Exports:** All 5 create functions + cache management

### Step 6: scene-setup.js
- **Lines:** 121-221 (createIslands) + 222-471 (setupScene) = ~350 lines
- **Functions:**
  - `createIslands()`
  - `setupScene(container)`
  - `cleanupScene(scene, renderer)`
- **Variables:** sky, sun, water, islands arrays
- **Dependencies:** THREE.js
- **Exports:** `setupScene`, `cleanupScene`

### Step 7: camera.js
- **Lines:** Spread throughout updateGame() and setupScene() - ~300 lines total
- **Variables:**
  - `currentCameraMode`
  - `thirdPersonCamera`
  - `freeCamera`
  - `freeCameraControls`
- **Functions:**
  - `getCameraMode()`
  - `setCameraMode(mode)`
  - `updateCamera(delta, jets, cameras)`
  - `getActiveCamera()`
  - Camera event listeners
- **Dependencies:** THREE.js
- **Exports:** Camera management functions

### Step 8: renderer.js
- **Lines:** 774-1227 (~453 lines)
- **Function:** `renderScene()`
- **Sub-tasks:**
  - Update jet meshes
  - Update tracer meshes
  - Update missile meshes
  - Update flare meshes
  - Update target markers
  - Trail rendering
  - Final render call
- **Dependencies:** mesh-manager, camera, radar
- **Exports:** `renderScene(gameState, scene, cameras, renderer)`

### Step 9: loop.js
- **Lines:** 472-773 (~301 lines)
- **Functions:**
  - `animate()`
  - `updateGame(delta)`
- **Variables:** `animationId`, delta calculation
- **Dependencies:** All game systems (AI, Physics, Weapons, etc.)
- **Exports:** `startGameLoop()`, `stopGameLoop()`

### Step 10: Finalize main.js
- **Lines:** 54-120 (startGame, stopGame) + coordination logic
- **Functions:**
  - `startGame()`
  - `stopGame()`
- **Dependencies:** All extracted modules
- **Exports:** `startGame`, `stopGame`

---

## Estimated Line Distribution After Split

| Module | Est. Lines | Status |
|--------|-----------|--------|
| `src/systems/jet-loader.js` | 30 | ✅ Done |
| `src/ui/camera-indicator.js` | 100 | Pending |
| `src/ui/event-log.js` | 150 | Pending |
| `src/systems/radar.js` | 350 | Pending |
| `src/systems/mesh-manager.js` | 300 | Pending |
| `src/systems/scene-setup.js` | 400 | Pending |
| `src/systems/camera.js` | 300 | Pending |
| `src/systems/renderer.js` | 200 | Pending |
| `src/systems/loop.js` | 200 | Pending |
| `src/main.js` | 100 | Pending |
| **Total** | **~2130** | 1/10 done |

---

## Recommended Approach

Due to the complexity and interdependencies, I recommend:

**Option A: Automated Extraction** (Fast, 10-15 minutes)
- I create all modules in one go using systematic line extraction
- Test once at the end
- Higher risk but much faster

**Option B: Incremental Extraction** (Safe, 60-90 minutes)
- Extract one module at a time
- Test after each extraction
- Lower risk but time-consuming (10 test cycles)

**Option C: Hybrid Approach** (Recommended, 30 minutes)
- Group by dependency level:
  - **Wave 1:** UI modules (camera-indicator, event-log) - no game dependencies
  - **Wave 2:** Standalone systems (radar, jet-loader) - minimal dependencies
  - **Wave 3:** Core systems (mesh-manager, scene-setup, camera) - moderate dependencies
  - **Wave 4:** Integration (renderer, loop, main) - all dependencies
- Test after each wave (4 test cycles)

**Which approach would you prefer?**

---

## Next Actions

1. **User decision:** Choose approach (A, B, or C)
2. **Execute extractions:** Create modules according to plan
3. **Update imports:** Fix all import paths in game-main.js and new modules
4. **Test:** Verify game works after extractions
5. **Document:** Update CHANGELOG with Phase 2 results
6. **Cleanup:** Remove old game-main.js once verified

**Ready to proceed when you give the go-ahead!**
