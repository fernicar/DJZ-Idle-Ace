# game-main.js Split Strategy
**File:** game-main.js (71KB / 2070 lines)
**Target:** 8 modules (<300 lines each, <13KB each)

---

## Analysis Summary

After reading the first 500 lines of game-main.js, I can identify the following major sections:

### Section Breakdown (Estimated):

1. **Imports & Globals** (lines 1-53)
2. **Lifecycle Functions** (lines 54-118): `startGame()`, `stopGame()`
3. **Terrain Generation** (lines 119-220): `createIslands()`
4. **Scene Setup** (lines 221-470): `setupScene()` + event listeners
5. **Main Loop** (lines 471-500+): `animate()`, `updateGame()`
6. **Mesh Management** (lines ?): Jet/missile/tracer mesh creation and caching
7. **Radar Rendering** (lines ?): Panoramic and radial radar canvas drawing
8. **Camera System** (lines ?): Free cam, third-person logic
9. **Event Logging** (lines ?): Event monitor UI updates
10. **Jet Model Loading** (lines ?): `loadJetFighterModel()` from JSON

---

## Proposed Split

### Module 1: `src/systems/loop.js` (~150 lines)
**Purpose:** Main game loop and timing
**Exports:**
- `startGameLoop()`
- `stopGameLoop()`
- `getAnimationId()`

**Contains:**
- `animate()` - requestAnimationFrame loop
- `updateGame(delta)` - game state updates
- Delta-time calculation
- Frame rate management

**Dependencies:**
- `./renderer.js` (for renderScene)
- `../core/physics.js`
- `../ai/enemy-ai.js`
- `../ai/weapons.js`
- `./radar.js`

---

### Module 2: `src/systems/renderer.js` (~200 lines)
**Purpose:** Scene rendering and visual updates
**Exports:**
- `renderScene(camera, scene, renderer, gameState)`
- `updateMeshes(gameState)`
- `updateTrails(jets, missiles, flares)`

**Contains:**
- Main render call
- Mesh position/rotation synchronization
- Trail rendering logic
- Visibility updates

**Dependencies:**
- `./mesh-manager.js`
- `./camera.js`

---

### Module 3: `src/systems/mesh-manager.js` (~400 lines)
**Purpose:** 3D mesh creation, caching, and management
**Exports:**
- `createJetMesh(jetModel, teamColor)`
- `createMissileMesh()`
- `createTracerMesh()`
- `createFlareMesh()`
- `getMeshCache(type, id)` - Returns cached mesh
- `updateTrailGeometry(trailId, positions)`
- `createTargetMarker(jetId)`

**Contains:**
- Mesh caching maps (jetMeshes, tracerMeshes, missileMeshes, flareMeshes)
- Trail position history (jetTrails, missileTrails, flareTrails)
- 3D geometry creation
- Material definitions
- Trail LineGeometry updates
- Target marker cubes for HUD

**Dependencies:**
- THREE.js

---

### Module 4: `src/systems/camera.js` (~300 lines)
**Purpose:** Camera modes and controls
**Exports:**
- `getCameraMode()`
- `setCameraMode(mode)` - 'overview' | 'thirdPerson' | 'free'
- `updateCamera(delta, jets, camera, thirdPersonCamera, freeCamera)`
- `setupCameraControls()`
- `getActiveCamera()` - Returns current camera to render with

**Contains:**
- `currentCameraMode` state
- `freeCameraControls` object (movement keys, rotation, pointer lock)
- Free camera movement logic (WASD + QE + mouse look)
- Third-person camera positioning (mount to green_0 jet)
- Overview camera positioning
- Pointer lock handling
- Camera mode indicator updates

**Dependencies:**
- THREE.js
- `../ui/camera-indicator.js` (new module for UI update)

---

### Module 5: `src/systems/radar.js` (~350 lines)
**Purpose:** Radar canvas rendering (panoramic + radial)
**Exports:**
- `setupRadarCanvases()` - Get canvas elements and contexts
- `updatePanoramicRadar(jets, playerJet)`
- `updateRadialRadar(jets, playerJet)`
- `clearRadarCanvases()`

**Contains:**
- Panoramic radar (400x80 top center) rendering:
  - 360° arc drawing
  - Green/red blip positioning based on world angle
  - Distance scaling
- Radial radar (180x180 bottom left) rendering:
  - Forward-cone arc (120° cone)
  - Blip positioning based on forward vector
  - Range circles
- Canvas 2D drawing code
- Blip color/size logic

**Dependencies:**
- None (pure canvas rendering)

---

### Module 6: `src/systems/scene-setup.js` (~450 lines)
**Purpose:** Three.js scene initialization
**Exports:**
- `setupScene(container)` - Returns { scene, camera, renderer, thirdPersonCamera, freeCamera }
- `cleanupScene(scene, renderer)` - Dispose resources

**Contains:**
- Scene creation with background color and fog
- Camera setup (3 cameras: overview, third-person, free)
- Renderer initialization (WebGL, antialiasing)
- Lighting (ambient + directional)
- **Sky shader:** Custom shader material with sun disc and gradient
- **Terrain generation:** `createIslands()` function
  - Procedural coastal landscape
  - Vertex coloring (land → beach → ocean)
  - Multi-frequency height variation
- tempMatrix and targetQuaternion initialization
- Window resize handler

**Dependencies:**
- THREE.js
- `./terrain.js` (optional: extract `createIslands()` if too large)

---

### Module 7: `src/systems/jet-loader.js` (~250 lines)
**Purpose:** Load and parse jetfighter.json 3D model data
**Exports:**
- `loadJetFighterModel()` - Returns Promise<ModelData>
- `getJetFighterModel()` - Returns cached model
- `parseJetComponents(jsonData)` - Convert JSON to component data

**Contains:**
- `fetch('./jetfighter.json')` call
- JSON parsing and validation
- Component data structure conversion
- Model caching (`jetFighterModel` variable)
- Error handling for missing/invalid JSON

**Dependencies:**
- None (just fetch API)

---

### Module 8: `src/ui/event-log.js` (~200 lines)
**Purpose:** Event monitor UI updates
**Exports:**
- `addEvent(category, message)` - Add event to log
- `clearEventLog()` - Clear all events
- `updateEventMonitor()` - Refresh UI
- `processRadioQueue()` - Handle radio chatter display

**Contains:**
- Event log array
- Event categorization (system, combat, movement)
- DOM manipulation for event monitor
- Radio chatter integration
- Timestamp formatting
- Auto-scroll logic

**Dependencies:**
- `../game/radio.js` (for radio system)

---

### Module 9: `src/ui/camera-indicator.js` (~50 lines)
**Purpose:** Camera mode indicator UI
**Exports:**
- `updateCameraModeIndicator(mode)` - Update displayed text
- `setupCameraIndicator()` - Initialize indicator element

**Contains:**
- Update `#cameraModeText` element
- Display camera hints
- Show/hide indicator

**Dependencies:**
- None (pure DOM)

---

### Module 10: `src/main.js` (Entry Point - ~150 lines remaining)
**Purpose:** Game lifecycle and coordination
**Exports:**
- `startGame()` - Public API for index.html
- `stopGame()` - Public API for index.html

**Contains:**
- Import all systems
- Global state coordination
- Initialize game state
- Load jet model → setup scene → start loop
- Cleanup on stop
- Player controls initialization
- Green team swap timer
- High-level event listeners (C/F/Esc keys)

**Dependencies:**
- All other modules

---

## Migration Plan

### Step 1: Extract Low-Dependency Modules First

1. ✅ **jet-loader.js** - No dependencies, just fetch
2. ✅ **camera-indicator.js** - Pure DOM, no game logic
3. ✅ **event-log.js** - Self-contained UI
4. ✅ **radar.js** - Pure canvas rendering

### Step 2: Extract Core Systems

5. ✅ **mesh-manager.js** - Only depends on THREE.js
6. ✅ **scene-setup.js** - Only depends on THREE.js
7. ✅ **camera.js** - Depends on camera-indicator.js

### Step 3: Extract Game Loop

8. ✅ **renderer.js** - Depends on mesh-manager, camera
9. ✅ **loop.js** - Depends on renderer, radar, all systems

### Step 4: Finalize Entry Point

10. ✅ **main.js** - Imports everything, minimal logic

---

## File Size Estimates

| Module | Lines | Est. Size | Status |
|--------|-------|-----------|--------|
| `loop.js` | ~150 | ~5KB | ✅ Safe |
| `renderer.js` | ~200 | ~7KB | ✅ Safe |
| `mesh-manager.js` | ~400 | ~15KB | ⚠️ Monitor |
| `camera.js` | ~300 | ~11KB | ✅ Safe |
| `radar.js` | ~350 | ~12KB | ✅ Safe |
| `scene-setup.js` | ~450 | ~17KB | ⚠️ Monitor |
| `jet-loader.js` | ~250 | ~9KB | ✅ Safe |
| `event-log.js` | ~200 | ~7KB | ✅ Safe |
| `camera-indicator.js` | ~50 | ~2KB | ✅ Safe |
| `main.js` | ~150 | ~5KB | ✅ Safe |
| **TOTAL** | **~2500** | **~90KB** | ⚠️ 2 files near limit |

**Action:** If `mesh-manager.js` or `scene-setup.js` exceed 13KB, split further:
- `mesh-manager.js` → `mesh-cache.js` + `trail-renderer.js`
- `scene-setup.js` → `scene.js` + `terrain.js` + `sky.js`

---

## Testing Checklist

After each module extraction:
- [ ] Import paths correct
- [ ] Exports match imports
- [ ] Game starts without errors
- [ ] All 3 camera modes work
- [ ] Jets render and move
- [ ] Missiles fire and track
- [ ] Flares deploy
- [ ] Radar displays update
- [ ] Radio chatter appears
- [ ] Event log updates
- [ ] Esc returns to menu
- [ ] No console errors

---

## Rollback Strategy

If split causes issues:
1. **Git backup:** Commit before splitting each module
2. **Keep original:** Rename `game-main.js` to `game-main.js.backup`
3. **Test incrementally:** Don't split all at once
4. **Revert if broken:** `git checkout game-main.js`

---

## Next Steps

1. ✅ Complete reading game-main.js (first 500 lines done, need 1570 more)
2. 🔨 Create `src/` directory structure
3. 🔨 Extract modules in order (jet-loader → camera-indicator → event-log → radar)
4. 🔨 Test after each extraction
5. 🔨 Update imports in main.js
6. 🔨 Verify game functionality
7. ✅ Update plan.md with new structure

---

**Status:** Ready to proceed with split
**Risk Level:** Medium (large refactor, but clear module boundaries)
**Estimated Time:** 4-6 hours for full split + testing
