import { createInitialState } from './src/core/state.js';
import * as AI from './src/ai/enemy-ai.js';
import * as Physics from './src/core/physics.js';
import * as Weapons from './src/ai/weapons.js';
import { PlayerControls } from './src/systems/controls.js';
import * as CONST from './src/game/constants.js';
import { loadJetFighterModel, getJetFighterModel } from './src/systems/jet-loader.js';
import { updateCameraModeIndicator } from './src/ui/camera-indicator.js';
import { addEvent, queueRadioChat, processRadioQueue, clearEventLog } from './src/ui/event-log.js';
import { updatePanoramicRadar, updateRadialRadar } from './src/systems/radar.js';
import { createJetMesh, createTracerMesh, createMissileMesh, createFlareMesh, createTargetMarker, meshCaches } from './src/systems/mesh-manager.js';

let gameState = null;
let playerControls = null;
let scene, camera, renderer;
let tempMatrix, targetQuaternion;
let animationId = null;

// Track if event listeners have been set up
let eventListenersSetup = false;

// Camera system
let currentCameraMode = 'overview'; // 'overview', 'thirdPerson', or 'free'
let thirdPersonCamera = null;
let freeCamera = null;
let freeCameraControls = {
  moveForward: false,
  moveBackward: false,
  moveLeft: false,
  moveRight: false,
  moveUp: false,
  moveDown: false,
  mouseMovement: { x: 0, y: 0 },
  rotation: { yaw: 0, pitch: 0 },
  isPointerLocked: false
};

// Green team target swap timer
let greenSwapTimer = 10; // seconds

// Mesh caching (imported from mesh-manager)
const { jetMeshes, tracerMeshes, missileMeshes, flareMeshes, jetTrails, missileTrails, flareTrails, targetMarkers } = meshCaches;

// Sky and water references
let sky, sun, water;
let islands = [];

export function startGame() {
  // Clear event log when starting a new game
  clearEventLog();

  // Initialize game state
  gameState = createInitialState();
  playerControls = new PlayerControls();

  addEvent('system', '🎮 NEW GAME STARTED');

  // Load jet fighter model first
  loadJetFighterModel().then(() => {
    addEvent('system', '🛠️ SCENE INITIALIZED');

    // Setup Three.js scene
    setupScene();

    // Start game loop
    animate();

    addEvent('system', '▶️ GAME LOOP STARTED');
  });
}
