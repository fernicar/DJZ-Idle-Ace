#!/bin/bash

# Quick extraction script for remaining game-main.js modules
# This extracts: scene-setup.js, camera.js (partial), renderer.js (partial), loop.js (partial)

echo "Extracting scene-setup.js..."
cat > ./src/systems/scene-setup.js << 'EOF'
// Scene setup and terrain generation
// Initializes Three.js scene, lights, cameras, and procedural terrain

// Create procedural terrain - coastal landscape with water-colored low areas
function createIslands(scene) {
EOF
sed -n '122,220p' game-main.js >> ./src/systems/scene-setup.js
cat >> ./src/systems/scene-setup.js << 'EOF'
}

export function setupScene(container) {
  // Clear only the WebGL canvas if it exists, preserve the cameraModeIndicator and radar canvases
  const existingCanvas = container.querySelector('canvas:not(#panoramicRadar):not(#radialRadar)');
  if (existingCanvas) {
    existingCanvas.remove();
  }

  const scene = new THREE.Scene();
EOF
sed -n '232,313p' game-main.js >> ./src/systems/scene-setup.js
cat >> ./src/systems/scene-setup.js << 'EOF'

  // Add terrain (includes ocean surface)
  createIslands(scene);

  const tempMatrix = new THREE.Matrix4();
  const targetQuaternion = new THREE.Quaternion();

  // Setup third-person camera (will be mounted to green_0 jet when it's created)
  const thirdPersonCamera = new THREE.PerspectiveCamera(90, window.innerWidth / window.innerHeight, 0.1, 100000);

  // Setup free camera for debugging
  const freeCamera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 100000);
  freeCamera.position.set(0, 50, 50);
  freeCamera.lookAt(0, 0, 0);

  return { scene, camera, renderer, thirdPersonCamera, freeCamera, tempMatrix, targetQuaternion };
}

export function cleanupScene(scene, renderer) {
  if (scene) {
    scene.clear();
  }
  if (renderer) {
    renderer.dispose();
  }
}
EOF

echo "scene-setup.js created ($(wc -l < ./src/systems/scene-setup.js) lines)"

