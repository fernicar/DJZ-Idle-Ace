// Radio chatter system for pilot callouts with paired interactions
// Pilot portrait mapping (2x2 grid, 256x256 image):
// Top-left (0,0) = Green Leader (Viper)
// Bottom-left (0,1) = Green Wingman (Hawk)
// Top-right (1,0) = Red Leader (Reaper)
// Bottom-right (1,1) = Red Wingman (Bandit)

const PILOT_NAMES = {
  'green_0': { name: 'Green Leader', callsign: 'Viper', portrait: { x: 0, y: 0 }, team: 'green' },
  'green_1': { name: 'Green Wingman', callsign: 'Hawk', portrait: { x: 0, y: 1 }, team: 'green' },
  'red_0': { name: 'Red Leader', callsign: 'Reaper', portrait: { x: 1, y: 0 }, team: 'red' },
  'red_1': { name: 'Red Wingman', callsign: 'Bandit', portrait: { x: 1, y: 1 }, team: 'red' }
};

// Paired interactions - actual conversations between pilots
const PAIRED_INTERACTIONS = {
  // Green initiates engagement
  engagement_1: [
    { speaker: 'green_0', messages: ["Reaper, you're mine!"] },
    { speaker: 'red_0', delay: 900, messages: ["Come and get me, Viper!"] },
    { speaker: 'green_0', delay: 1400, messages: ["Fox 2!"] },
    { speaker: 'red_0', delay: 1900, messages: ["Missile! Breaking right!"] }
  ],

  engagement_2: [
    { speaker: 'green_1', messages: ["I've got the wingman!"] },
    { speaker: 'red_1', delay: 700, messages: ["You'll have to catch me first!"] },
    { speaker: 'green_1', delay: 1500, messages: ["You're not getting away!"] }
  ],

  // Red initiates engagement
  engagement_3: [
    { speaker: 'red_0', messages: ["Greens at 12 o'clock!"] },
    { speaker: 'red_1', delay: 600, messages: ["I see them! Engaging!"] },
    { speaker: 'green_0', delay: 1200, messages: ["Here they come! Break!"] }
  ],

  engagement_4: [
    { speaker: 'red_1', messages: ["I've got tone on Hawk!"] },
    { speaker: 'green_1', delay: 800, messages: ["Defensive! Popping flares!"] },
    { speaker: 'red_1', delay: 1600, messages: ["Damn, he shook it!"] }
  ],

  // Post-kill exchanges
  victory_green: [
    { speaker: 'green_0', messages: ["Splash one! Reaper's down!"] },
    { speaker: 'red_1', delay: 800, messages: ["Lead is hit! I'm taking command!"] },
    { speaker: 'green_1', delay: 1400, messages: ["Good kill, Viper!"] }
  ],

  victory_red: [
    { speaker: 'red_0', messages: ["Splash! Viper's out!"] },
    { speaker: 'green_1', delay: 700, messages: ["Lead! No!"] },
    { speaker: 'red_1', delay: 1300, messages: ["Nice shot, boss!"] }
  ],

  // Team coordination - Green
  green_coord_1: [
    { speaker: 'green_0', messages: ["Hawk, split right!"] },
    { speaker: 'green_1', delay: 500, messages: ["Roger, breaking right!"] },
    { speaker: 'green_0', delay: 1100, messages: ["I'll take lead!"] }
  ],

  green_coord_2: [
    { speaker: 'green_1', messages: ["Viper, bandit on your six!"] },
    { speaker: 'green_0', delay: 600, messages: ["Copy! Evading!"] },
    { speaker: 'green_1', delay: 1200, messages: ["I've got him! Guns guns guns!"] }
  ],

  // Team coordination - Red
  red_coord_1: [
    { speaker: 'red_0', messages: ["Bandit, pincer maneuver!"] },
    { speaker: 'red_1', delay: 500, messages: ["Copy! Going wide!"] },
    { speaker: 'red_0', delay: 1100, messages: ["Now! Close the trap!"] }
  ],

  red_coord_2: [
    { speaker: 'red_1', messages: ["Reaper, I need support!"] },
    { speaker: 'red_0', delay: 700, messages: ["On my way! Hold on!"] },
    { speaker: 'red_1', delay: 1300, messages: ["He's breaking off!"] }
  ],

  // Close combat exchanges
  dogfight_1: [
    { speaker: 'green_0', messages: ["Can't shake him!"] },
    { speaker: 'red_0', delay: 800, messages: ["Gotcha now!"] },
    { speaker: 'green_0', delay: 1400, messages: ["Not yet! Rolling!"] }
  ],

  dogfight_2: [
    { speaker: 'red_1', messages: ["Where'd he go?!"] },
    { speaker: 'green_1', delay: 700, messages: ["Right behind you!"] },
    { speaker: 'red_1', delay: 1300, messages: ["Dammit! Defensive!"] }
  ],

  // Taunts and banter
  taunt_1: [
    { speaker: 'green_0', messages: ["Is that all you got, Reaper?"] },
    { speaker: 'red_0', delay: 900, messages: ["Just getting started, Viper!"] }
  ],

  taunt_2: [
    { speaker: 'red_0', messages: ["You're getting slow, old man!"] },
    { speaker: 'green_0', delay: 800, messages: ["Old age and treachery!"] }
  ],

  // Respect after good moves
  respect_1: [
    { speaker: 'green_0', messages: ["Nice break!"] },
    { speaker: 'red_0', delay: 700, messages: ["Learned from the best!"] }
  ],

  respect_2: [
    { speaker: 'red_1', messages: ["Good shot!"] },
    { speaker: 'green_1', delay: 600, messages: ["You too! Stay sharp!"] }
  ]
};

// Single callouts for individual events
const CALLOUTS = {
  missile_launch: [
    "Fox 2! Fox 2!",
    "Missile away!",
    "Fox 2, tracking!",
    "Heat seeker away!",
    "Magnum!"
  ],
  guns_attack: [
    "Guns guns guns!",
    "Engaging with guns!",
    "Taking the shot!",
    "Rifle!"
  ],
  splash: [
    "Splash one!",
    "Target destroyed!",
    "Good kill!",
    "Bandit down!",
    "Confirmed kill!"
  ],
  flares: [
    "Popping flares!",
    "Flares out!",
    "Countermeasures!",
    "Flares away!"
  ]
};

let radioQueue = [];
let lastCalloutTime = 0;
const CALLOUT_COOLDOWN = 800;
const DISPLAY_DURATION = 3500;
let interactionCooldown = 0;
let recentInteractions = []; // Track recent interactions to avoid repetition
const MAX_RECENT_INTERACTIONS = 5; // Don't repeat last 5 interactions

export function addCallout(pilotId, eventType) {
  if (!PILOT_NAMES[pilotId] || !CALLOUTS[eventType]) return;

  const pilot = PILOT_NAMES[pilotId];
  const messages = CALLOUTS[eventType];
  const message = messages[Math.floor(Math.random() * messages.length)];

  radioQueue.push({
    pilotId,
    pilot,
    message,
    timestamp: Date.now(),
    eventType,
    isPaired: false
  });
}

export function addPairedInteraction(interactionType) {
  if (!PAIRED_INTERACTIONS[interactionType]) return;

  const interaction = PAIRED_INTERACTIONS[interactionType];
  const baseTime = Date.now();

  interaction.forEach((part, index) => {
    const delay = part.delay || 0;

    const pilotId = part.speaker;
    const pilot = PILOT_NAMES[pilotId];
    if (!pilot) return;

    const message = part.messages[Math.floor(Math.random() * part.messages.length)];

    radioQueue.push({
      pilotId,
      pilot,
      message,
      timestamp: baseTime + delay,
      eventType: interactionType,
      isPaired: true
    });
  });
}

export function getNextCallout() {
  const now = Date.now();

  const readyCallouts = radioQueue.filter(c => c.timestamp <= now);
  if (readyCallouts.length === 0) return null;

  const nextCallout = readyCallouts[0];
  if (now - lastCalloutTime < (nextCallout.isPaired ? 100 : CALLOUT_COOLDOWN)) return null;

  const index = radioQueue.indexOf(nextCallout);
  radioQueue.splice(index, 1);
  lastCalloutTime = now;

  return nextCallout;
}

export function updateRadioDisplay(callout) {
  if (!callout) return;

  const messageDiv = document.createElement('div');
  messageDiv.className = 'radio-message';
  messageDiv.innerHTML = `
    <div class="radio-message-portrait" style="background-position: -${callout.pilot.portrait.x * 48}px -${callout.pilot.portrait.y * 48}px"></div>
    <div class="radio-message-content">
      <div class="radio-message-name">${callout.pilot.callsign}</div>
      <div class="radio-message-text">${callout.message}</div>
    </div>
  `;

  const container = document.getElementById('radioStack');
  if (!container) return;

  container.appendChild(messageDiv);
  setTimeout(() => messageDiv.classList.add('active'), 10);

  setTimeout(() => {
    messageDiv.classList.add('fade-out');
    setTimeout(() => {
      if (messageDiv.parentNode) {
        messageDiv.parentNode.removeChild(messageDiv);
      }
    }, 300);
  }, DISPLAY_DURATION);

  while (container.children.length > 4) {
    container.removeChild(container.firstChild);
  }
}

export function triggerRandomInteraction(delta) {
  interactionCooldown -= delta * 1000;

  if (interactionCooldown <= 0 && Math.random() < 0.08) {
    const interactionTypes = Object.keys(PAIRED_INTERACTIONS);

    // Filter out recently used interactions
    const availableTypes = interactionTypes.filter(type => !recentInteractions.includes(type));

    // If all interactions were recent, reset the list
    if (availableTypes.length === 0) {
      recentInteractions = [];
      availableTypes.push(...interactionTypes);
    }

    // Pick random from available types
    const randomType = availableTypes[Math.floor(Math.random() * availableTypes.length)];

    addPairedInteraction(randomType);

    // Track this interaction
    recentInteractions.push(randomType);
    if (recentInteractions.length > MAX_RECENT_INTERACTIONS) {
      recentInteractions.shift(); // Remove oldest
    }

    interactionCooldown = 10000 + Math.random() * 15000; // 10-25 seconds
  }
}

export function clearRadioQueue() {
  radioQueue = [];
  const container = document.getElementById('radioStack');
  if (container) {
    container.innerHTML = '';
  }
}
