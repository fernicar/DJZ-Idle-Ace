import * as CONST from './game-constants.js';

// Update jet physics and movement (ALL jets use AI, including player's jet)
export function updateJetPhysics(jet, delta) {
  if (jet.isWrecked) {
    // Wreckage physics
    jet.velocity.multiplyScalar(1 - (delta * 0.9));
    jet.velocity.y -= 9.8 * delta;
    jet.position.add(jet.velocity.clone().multiplyScalar(delta));

    if (jet.wreckageAngularVelocity) {
      const deltaRotation = new THREE.Quaternion().setFromEuler(
        new THREE.Euler(
          jet.wreckageAngularVelocity.x * delta,
          jet.wreckageAngularVelocity.y * delta,
          jet.wreckageAngularVelocity.z * delta
        )
      );
      jet.quaternion.multiply(deltaRotation).normalize();
    }

    if (jet.position.length() > CONST.WORLD_RADIUS) {
      jet.destroyedAt = Date.now() - CONST.RESPAWN_TIME - 1;
    }
    return;
  }

  if (jet.isDestroyed) return;

  // Normal flight physics (automated for ALL jets including player)
  const forward = new THREE.Vector3(0, 0, 1).applyQuaternion(jet.quaternion);
  jet.velocity.lerp(forward.clone().multiplyScalar(CONST.JET_SPEED), delta * 2.0);
  jet.position.add(jet.velocity.clone().multiplyScalar(delta));

  // World boundaries (wrap around)
  if (jet.position.length() > CONST.WORLD_RADIUS) {
    jet.position.negate();
  }
}

// Update missile physics
export function updateMissilePhysics(missile, jets, delta) {
  let newVelocity = missile.velocity.clone();
  const currentTarget = jets.find(j => j.id === missile.targetId && !j.isWrecked && !j.isDestroyed);

  if (currentTarget) {
    const targetForward = new THREE.Vector3(0, 0, 1).applyQuaternion(currentTarget.quaternion);
    const leadPoint = currentTarget.position.clone().add(targetForward.multiplyScalar(CONST.LEAD_TARGET_DISTANCE));

    const desiredDirection = leadPoint.sub(missile.position).normalize();
    const desiredVelocity = desiredDirection.multiplyScalar(CONST.MISSILE_SPEED);

    newVelocity.lerp(desiredVelocity, delta * CONST.MISSILE_TURN_SPEED);
  }

  newVelocity.normalize().multiplyScalar(CONST.MISSILE_SPEED);
  missile.position.add(newVelocity.clone().multiplyScalar(delta));

  const newQuaternion = new THREE.Quaternion();
  newQuaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), newVelocity.clone().normalize());

  missile.velocity = newVelocity;
  missile.quaternion = newQuaternion;
  missile.life -= delta;
}

// Update tracer physics
export function updateTracerPhysics(tracer, delta) {
  tracer.position.add(tracer.velocity.clone().multiplyScalar(delta));
  tracer.life -= delta;
}

// Update flare physics
export function updateFlarePhysics(flare, delta) {
  flare.velocity.y -= 9.8 * delta; // Gravity
  flare.velocity.multiplyScalar(1 - (delta * CONST.FLARE_DRAG));
  flare.position.add(flare.velocity.clone().multiplyScalar(delta));
  flare.life -= delta;
}

// Handle respawns
export function handleRespawn(jet) {
  if ((jet.isDestroyed || jet.isWrecked) && jet.destroyedAt && Date.now() - jet.destroyedAt > CONST.RESPAWN_TIME) {
    jet.isDestroyed = false;
    jet.isWrecked = false;
    jet.wreckageAngularVelocity = null;
    jet.position.set(
      (Math.random() - 0.5) * CONST.WORLD_RADIUS,
      (Math.random() - 0.5) * CONST.WORLD_RADIUS,
      (Math.random() - 0.5) * CONST.WORLD_RADIUS
    );

    // Create random direction vector
    const theta = Math.random() * Math.PI * 2;
    const phi = Math.acos(2 * Math.random() - 1);
    jet.velocity.set(
      Math.sin(phi) * Math.cos(theta) * CONST.JET_SPEED,
      Math.sin(phi) * Math.sin(theta) * CONST.JET_SPEED,
      Math.cos(phi) * CONST.JET_SPEED
    );

    jet.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), jet.velocity.clone().normalize());
  }
}

// Check missile detonation
export function checkMissileDetonation(missiles, jets) {
  const destroyedJetIds = new Set();
  const survivingMissiles = missiles.filter(m => {
    const targetJet = jets.find(j => j.id === m.targetId && !j.isWrecked && !j.isDestroyed);
    if (targetJet && m.position.distanceTo(targetJet.position) < CONST.MISSILE_PROXIMITY_DETONATION_RANGE) {
      if (m.willDetonate) {
        if (!destroyedJetIds.has(targetJet.id)) {
          destroyedJetIds.add(targetJet.id);
        }
        return false;
      } else {
        m.targetId = null;
      }
    }
    return m.life > 0;
  });

  // Apply destruction
  if (destroyedJetIds.size > 0) {
    jets.forEach(jet => {
      if (destroyedJetIds.has(jet.id)) {
        jet.isWrecked = true;
        jet.destroyedAt = Date.now();
        jet.velocity.add(new THREE.Vector3((Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20));
        jet.wreckageAngularVelocity = new THREE.Vector3(
          (Math.random() - 0.5) * 10,
          (Math.random() - 0.5) * 5,
          (Math.random() - 0.5) * 10
        );
      }
    });
  }

  return survivingMissiles;
}
