# SeaVerse Project

AI-driven frontend template. Users describe what they want, AI implements it.

## Essence

- Pure frontend (Vite + vanilla JS)
- Single-page app, all code lives in `index.html`
- Users see the rendered page, not the tech stack

## File Structure

```
project/
├── index.html      # The only file to modify (HTML + CSS + JS all here)
├── package.json    # Dependencies
├── vite.config.js  # Vite config (API proxy pre-configured)
└── Makefile        # Build commands
```

## Architecture

**All changes go in `index.html`:**

| Section | Location | Purpose |
|---------|----------|---------|
| CSS | `<style>` tag in `<head>` | All styles, variables in `:root` |
| HTML | `<body>` | Page structure |
| JS | `<script type="module">` at end of `<body>` | All logic |

**API Proxy (pre-configured in vite.config.js):**

| Route | Target | Type |
|-------|--------|------|
| `/api/*` | Backend server | HTTP |
| `/ws/*` | Backend server | WebSocket |

## Design Conventions

- Dark theme, CSS variables in `:root`
- Responsive, mobile-first
- Apple-style rounded corners and transitions

## Common Patterns

Add a section:
```html
<section class="your-section">
  <div class="container">
    <!-- content -->
  </div>
</section>
```

Add CSS variables:
```css
:root {
  --your-color: #xxx;
}
```

Add interactivity:
```js
document.getElementById('your-element').addEventListener('click', () => {
  // logic
});
```
