// Player controls - Strategic input, not direct flight control

export class PlayerControls {
  constructor() {
    this.targetSwitchRequest = false;
    this.keys = {};
    this.setupControls();
  }

  setupControls() {
    document.addEventListener('keydown', (e) => {
      this.keys[e.key.toLowerCase()] = true;

      // Spacebar to request target switch (coordinates with wingman)
      if (e.key === ' ') {
        this.targetSwitchRequest = true;
      }
    });

    document.addEventListener('keyup', (e) => {
      this.keys[e.key.toLowerCase()] = false;
    });
  }

  update() {
    const request = this.targetSwitchRequest;
    this.targetSwitchRequest = false; // Reset after reading
    return { targetSwitchRequest: request };
  }
}

export function createHUD() {
  // HUD removed - not working
  return null;
}

export function updateHUD(green0Jet, green1Jet, jets, camera, cameraMode) {
  // HUD removed - not working
}
