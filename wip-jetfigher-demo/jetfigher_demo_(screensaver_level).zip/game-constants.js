// Game Constants
export const DEBUG = false;
export const RESPAWN_TIME = 5000; // ms
export const JET_SPEED = 35;
export const TURN_SPEED = 1.8;
export const WORLD_RADIUS = 120;
export const ROLE_SWAP_BASE_TIME = 10;
export const ROLE_SWAP_RANDOMNESS = 2;

// Weapons
export const TRACER_SPEED = 150;
export const TRACER_LIFESPAN = 2; // seconds
export const FIRING_COOLDOWN = 3; // seconds
export const BURST_COUNT = 3;
export const TRACERS_PER_BURST = 5;
export const TIME_BETWEEN_TRACERS = 0.06; // seconds
export const TIME_BETWEEN_BURSTS = 0.3; // seconds
export const FIRING_CONE_DOT_PRODUCT = 0.97;
export const WEAPON_RANGE_THRESHOLD = 60;

// Missiles
export const MISSILE_SPEED = 100;
export const MISSILE_LIFESPAN = 5; // seconds
export const MISSILE_PROXIMITY_DETONATION_RANGE = 10;
export const LEAD_TARGET_DISTANCE = 10;
export const MISSILE_TURN_SPEED = 3.0;

// Flares
export const FLARE_LIFESPAN = 3; // seconds
export const FLARE_EJECTION_SPEED = 15;
export const FLARES_TO_DEPLOY = 6;
export const TIME_BETWEEN_FLARE_PAIRS = 0.2;
export const FLARE_DRAG = 0.5;
export const FLARE_WING_OFFSET = 3;

// AI
export const DISENGAGE_ALTITUDE_RANGE = 30;
export const GREEN_COHESION_RADIUS = 40;
export const GREEN_COHESION_STRENGTH = 0.3;
export const GREEN_AVOIDANCE_RADIUS = 15;
export const GREEN_AVOIDANCE_STRENGTH = 1.5;
export const GREEN_TARGET_SWAP_TIME = 10; // seconds
