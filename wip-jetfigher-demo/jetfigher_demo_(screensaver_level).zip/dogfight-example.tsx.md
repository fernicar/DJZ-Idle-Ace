/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
*/
/// <reference types="@react-three/fiber" />
import React, { useRef, useState, useEffect, useMemo } from 'react';
import { createRoot } from 'react-dom/client';
import { Canvas, useFrame } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import * as THREE from 'three';
import type { OrbitControls as OrbitControlsImpl } from 'three-stdlib';


// --- Simulation Constants ---
const DEBUG = false;
const RESPAWN_TIME = 5000; // ms
const JET_SPEED = 35;
const TURN_SPEED = 1.8;
const WORLD_RADIUS = 120;
const ROLE_SWAP_BASE_TIME = 10;
const ROLE_SWAP_RANDOMNESS = 2;
const TRACER_SPEED = 150;
const TRACER_LIFESPAN = 2; // seconds
const FIRING_COOLDOWN = 3; // seconds
const BURST_COUNT = 3;
const TRACERS_PER_BURST = 5;
const TIME_BETWEEN_TRACERS = 0.06; // seconds
const TIME_BETWEEN_BURSTS = 0.3; // seconds
const DISENGAGE_ALTITUDE_RANGE = 30;
const GREEN_COHESION_RADIUS = 40;
const GREEN_COHESION_STRENGTH = 0.3;
const GREEN_AVOIDANCE_RADIUS = 15;
const GREEN_AVOIDANCE_STRENGTH = 1.5;
const FIRING_CONE_DOT_PRODUCT = 0.97; // Target must be within this cone to fire
const GREEN_TARGET_SWAP_TIME = 10; // seconds
const MISSILE_SPEED = 100;
const MISSILE_LIFESPAN = 5; // seconds
const MISSILE_PROXIMITY_DETONATION_RANGE = 10;
const LEAD_TARGET_DISTANCE = 10;
const MISSILE_TURN_SPEED = 3.0;
const FLARE_LIFESPAN = 3; // seconds
const FLARE_EJECTION_SPEED = 15; // Relative to the jet
const FLARES_TO_DEPLOY = 6; // 3 pairs
const TIME_BETWEEN_FLARE_PAIRS = 0.2; // 200ms
const FLARE_DRAG = 0.5;
const FLARE_WING_OFFSET = 3;
const CAMERA_TARGET_LERP_SPEED = 1.0;
const WEAPON_RANGE_THRESHOLD = 60;

// --- Types ---
interface TracerState {
  id: string;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  quaternion: THREE.Quaternion;
  life: number;
}

interface FlareState {
    id: string;
    position: THREE.Vector3;
    velocity: THREE.Vector3;
    life: number;
}

interface MissileState {
  id: string;
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  quaternion: THREE.Quaternion;
  life: number;
  targetId: string | null;
  willDetonate: boolean;
}

interface BurstState {
  active: boolean;
  burstsLeft: number;
  tracersLeftInBurst: number;
  nextShotTimer: number;
  isKillShot: boolean;
}

interface FlareDeploymentState {
  deploying: boolean;
  flaresLeft: number;
  nextFlareTimer: number;
}

interface BattleEntity {
  id:string;
  team: 'green' | 'red';
  position: THREE.Vector3;
  velocity: THREE.Vector3;
  quaternion: THREE.Quaternion;
  isDestroyed: boolean;
  isWrecked: boolean;
  destroyedAt: number | null;
  // AI
  aiState: 'attacking' | 'following';
  targetId: string | null;
  partnerId: string | null;
  roleChangeTimer: number;
  disengagementAltitude: number | null; // For red team followers
  // Combat
  fireCooldown: number;
  burstState: BurstState;
  flareState: FlareDeploymentState;
  wreckageAngularVelocity: THREE.Vector3 | null;
}

// --- Initial State Factory ---
function createInitialState(): { jets: BattleEntity[] } {
  const jets: BattleEntity[] = [];
  
  const createJet = (
    id: string, team: 'green' | 'red', position: THREE.Vector3, velocity: THREE.Vector3,
    quaternion: THREE.Quaternion, aiState: 'attacking' | 'following', targetId: string | null, partnerId: string | null
  ): BattleEntity => ({
    id, team, position, velocity, quaternion, aiState, targetId, partnerId,
    isDestroyed: false, isWrecked: false, destroyedAt: null,
    roleChangeTimer: aiState === 'attacking' ? ROLE_SWAP_BASE_TIME + (Math.random() - 0.5) * 2 * ROLE_SWAP_RANDOMNESS : 0,
    fireCooldown: Math.random() * FIRING_COOLDOWN,
    burstState: { active: false, burstsLeft: 0, tracersLeftInBurst: 0, nextShotTimer: 0, isKillShot: false },
    flareState: { deploying: false, flaresLeft: 0, nextFlareTimer: 0 },
    disengagementAltitude: null,
    wreckageAngularVelocity: null,
  });

  // Green jets (2)
  // FIX: Use THREE.Vector3 and THREE.Quaternion
  jets.push(createJet(
    'green_0', 'green', new THREE.Vector3(0, 0, -20), new THREE.Vector3(0, 0, JET_SPEED),
    new THREE.Quaternion(), 'attacking', 'red_0', null
  ));
  // FIX: Use THREE.Vector3 and THREE.Quaternion
  jets.push(createJet(
    'green_1', 'green', new THREE.Vector3(0, 0, 20), new THREE.Vector3(0, 0, -JET_SPEED),
    new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI), 'attacking', 'red_2', null
  ));

  // Red jets (4)
  // FIX: Use THREE.Vector3 and THREE.Quaternion
  const redJetVelocity = new THREE.Vector3(0, 0, -JET_SPEED);
  const redJetQuaternion = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI);

  jets.push(createJet('red_0', 'red', new THREE.Vector3(80, 5, -20), redJetVelocity.clone(), redJetQuaternion.clone(), 'attacking', 'green_0', 'red_1'));
  jets.push(createJet('red_1', 'red', new THREE.Vector3(95, 5, -20), redJetVelocity.clone(), redJetQuaternion.clone(), 'following', 'red_0', 'red_0'));
  jets.push(createJet('red_2', 'red', new THREE.Vector3(-80, -5, 20), redJetVelocity.clone(), redJetQuaternion.clone(), 'attacking', 'green_1', 'red_3'));
  jets.push(createJet('red_3', 'red', new THREE.Vector3(-95, -5, 20), redJetVelocity.clone(), redJetQuaternion.clone(), 'following', 'red_2', 'red_2'));
  
  return { jets };
}


// --- Components ---

const Skybox = () => (
    <mesh scale={[5, 5, 5]}>
        <sphereGeometry args={[150, 32, 32]} />
        <meshStandardMaterial color="#1a1a2e" wireframe transparent opacity={0.3} />
    </mesh>
);

const Jet: React.FC<{ jet: BattleEntity }> = ({ jet }) => {
    // FIX: Destructured 'team' instead of 'color' from the jet state, as 'color' does not exist on JetState.
    const { position, quaternion, team, isWrecked } = jet;
    // FIX: Use THREE.Group for ref type
    const groupRef = React.useRef<THREE.Group>(null!);

    // Normal trail
    // FIX: Correct useRef initialization
    const trailPoints = useRef<THREE.Vector3[]>([]);
    const maxTrailPoints = 50;
    const trailColor = team === 'green' ? '#4ADE80' : '#F87171';
    const trailLine = useMemo(() => {
        // FIX: Use THREE.BufferGeometry and THREE.LineBasicMaterial, THREE.Line
        const geometry = new THREE.BufferGeometry();
        const material = new THREE.LineBasicMaterial({ color: trailColor, transparent: true, opacity: 0.6 });
        return new THREE.Line(geometry, material);
    }, [trailColor]);
    
    // Wreckage smoke trail
    // FIX: Correct useRef initialization
    const smokeTrailPoints = useRef<THREE.Vector3[]>([]);
    const maxSmokeTrailPoints = 400; // Increased for a thicker/longer trail
    const smokeTrailLine = useMemo(() => {
        // FIX: Use THREE.BufferGeometry and THREE.LineBasicMaterial, THREE.Line
        const geometry = new THREE.BufferGeometry();
        const material = new THREE.LineBasicMaterial({ vertexColors: true, transparent: true, opacity: 1.0, linewidth: 3 }); // Thicker line
        return new THREE.Line(geometry, material);
    }, []);

    useFrame(() => {
        if (groupRef.current) {
            groupRef.current.position.copy(position);
            groupRef.current.quaternion.copy(quaternion);
            const newPosition = groupRef.current.position.clone();

            if (isWrecked) {
                // Clear normal trail if it exists
                if(trailPoints.current.length > 0) {
                    trailPoints.current.length = 0;
                    // FIX: Use THREE.BufferGeometry
                    trailLine.geometry.dispose();
                    trailLine.geometry = new THREE.BufferGeometry();
                }

                // Update smoke trail
                smokeTrailPoints.current.push(newPosition);
                if (smokeTrailPoints.current.length > maxSmokeTrailPoints) smokeTrailPoints.current.shift();
                
                if (smokeTrailPoints.current.length > 1) {
                    smokeTrailLine.geometry.dispose();
                    // FIX: Use THREE.BufferGeometry
                    smokeTrailLine.geometry = new THREE.BufferGeometry().setFromPoints(smokeTrailPoints.current);
                    const colors = [];
                    // FIX: Use THREE.Color
                    const yellow = new THREE.Color(0xffff99); // Fiery core
                    const orange = new THREE.Color(0xffa500); // Orange fire
                    const darkGray = new THREE.Color(0x222222); // Black smoke
                    for (let i = 0; i < smokeTrailPoints.current.length; i++) {
                        const t = i / (smokeTrailPoints.current.length - 1);
                        // FIX: Use THREE.Color
                        const color = new THREE.Color();
                        if (t > 0.8) { // Last 20% of the trail (closest to jet) is fiery yellow
                            color.lerpColors(orange, yellow, (t - 0.8) / 0.2);
                        } else { // First 80% is a gradient from dark gray to orange
                            color.lerpColors(darkGray, orange, t / 0.8);
                        }
                        colors.push(color.r, color.g, color.b);
                    }
                    // FIX: Use THREE.Float32BufferAttribute
                    smokeTrailLine.geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
                }
            } else {
                groupRef.current.visible = true;
                 // Clear smoke trail if it exists
                if(smokeTrailPoints.current.length > 0) {
                    smokeTrailPoints.current.length = 0;
                    smokeTrailLine.geometry.dispose();
                    // FIX: Use THREE.BufferGeometry
                    smokeTrailLine.geometry = new THREE.BufferGeometry();
                }

                // Update normal trail
                if (trailPoints.current.length > 0) {
                    const lastPoint = trailPoints.current[trailPoints.current.length - 1];
                    const teleportThreshold = WORLD_RADIUS;
                    if (newPosition.distanceTo(lastPoint) > teleportThreshold) {
                        trailPoints.current.length = 0;
                    }
                }
                trailPoints.current.push(newPosition);
                if (trailPoints.current.length > maxTrailPoints) trailPoints.current.shift();
                
                trailLine.geometry.dispose();
                if (trailPoints.current.length > 1) {
                    // FIX: Use THREE.BufferGeometry
                    trailLine.geometry = new THREE.BufferGeometry().setFromPoints(trailPoints.current);
                } else {
                    // FIX: Use THREE.BufferGeometry
                    trailLine.geometry = new THREE.BufferGeometry();
                }
            }
        }
    });

    const baseColor = team === 'green' ? '#2E8B57' : '#C41E3A';
    
    return (
        <group>
            <group ref={groupRef} scale={0.5}>
                <mesh position={[0, 0, 0]}><boxGeometry args={[1, 0.8, 5]} /><meshStandardMaterial color={baseColor} /></mesh>
                <mesh position={[0, 0, -0.5]}><boxGeometry args={[7, 0.2, 1.5]} /><meshStandardMaterial color={baseColor} /></mesh>
                <mesh position={[0, 0.65, 1.5]}><boxGeometry args={[0.8, 0.5, 1]} /><meshStandardMaterial color={'#9999ff'} /></mesh>
                <mesh position={[0, 1, -2]}><boxGeometry args={[0.2, 1.2, 0.8]} /><meshStandardMaterial color={baseColor} /></mesh>
                <mesh position={[0, 0, -2]}><boxGeometry args={[2.5, 0.1, 0.8]} /><meshStandardMaterial color={baseColor} /></mesh>
                {isWrecked && (
                    <mesh scale={[0.5, 0.5, 1.5]}>
                        <sphereGeometry args={[1, 32, 16]} />
                        <meshStandardMaterial
                            color="orange"
                            emissive="orange"
                            emissiveIntensity={4}
                            transparent
                            opacity={0.6}
                            toneMapped={false}
                        />
                    </mesh>
                )}
            </group>
            {isWrecked ? <primitive object={smokeTrailLine} /> : <primitive object={trailLine} />}
        </group>
    );
};

// FIX: Use THREE.Vector3 and THREE.Quaternion for props
const Tracer: React.FC<{ position: THREE.Vector3, quaternion: THREE.Quaternion }> = ({ position, quaternion }) => {
    // FIX: Use THREE.Mesh for ref type
    const ref = React.useRef<THREE.Mesh>(null!);
    useFrame(() => {
        if (ref.current) {
            ref.current.position.copy(position);
            ref.current.quaternion.copy(quaternion);
        }
    });
    return (
        <mesh ref={ref}>
            <capsuleGeometry args={[0.1, 1.5, 4, 8]} />
            <meshStandardMaterial color="yellow" emissive="yellow" emissiveIntensity={2} toneMapped={false} />
        </mesh>
    );
};

// FIX: Use THREE.Vector3 and THREE.Quaternion for props
const Missile: React.FC<{ position: THREE.Vector3, quaternion: THREE.Quaternion }> = ({ position, quaternion }) => {
    // FIX: Use THREE.Mesh and THREE.Vector3 for ref types, and correct useRef initialization
    const ref = React.useRef<THREE.Mesh>(null!);
    const trailPoints = useRef<THREE.Vector3[]>([]);
    const maxTrailPoints = 30;

    const trailLine = useMemo(() => {
        // FIX: Use THREE.BufferGeometry, THREE.LineBasicMaterial, THREE.Line
        const geometry = new THREE.BufferGeometry();
        const material = new THREE.LineBasicMaterial({ color: '#CCCCCC', transparent: true, opacity: 0.5 });
        return new THREE.Line(geometry, material);
    }, []);

    useFrame(() => {
        if (ref.current) {
            ref.current.position.copy(position);
            ref.current.quaternion.copy(quaternion);

            trailPoints.current.push(ref.current.position.clone());
            if (trailPoints.current.length > maxTrailPoints) {
                trailPoints.current.shift();
            }

            if (trailPoints.current.length > 1) {
                trailLine.geometry.dispose();
                // FIX: Use THREE.BufferGeometry
                trailLine.geometry = new THREE.BufferGeometry().setFromPoints(trailPoints.current);
            }
        }
    });
    return (
        <group>
            <mesh ref={ref}>
                <cylinderGeometry args={[0.2, 0.2, 3, 8]} />
                <meshStandardMaterial color="white" emissive="white" emissiveIntensity={1} toneMapped={false} />
            </mesh>
            <primitive object={trailLine} />
        </group>
    );
};

// FIX: Use THREE.Vector3 for props
const Flare: React.FC<{ position: THREE.Vector3 }> = ({ position }) => {
    // FIX: Use THREE.Mesh and THREE.Vector3 for ref types, and correct useRef initialization
    const ref = React.useRef<THREE.Mesh>(null!);
    const trailPoints = useRef<THREE.Vector3[]>([]);
    const maxTrailPoints = 20;

    const trailLine = useMemo(() => {
        // FIX: Use THREE.BufferGeometry and THREE.LineBasicMaterial, THREE.Line
        const geometry = new THREE.BufferGeometry();
        const material = new THREE.LineBasicMaterial({ color: '#FFFFFF', transparent: true, opacity: 0.8, vertexColors: true });
        return new THREE.Line(geometry, material);
    }, []);

    useFrame(() => {
        if (ref.current) {
            ref.current.position.copy(position);
            trailPoints.current.push(ref.current.position.clone());
            if (trailPoints.current.length > maxTrailPoints) {
                trailPoints.current.shift();
            }

            if (trailPoints.current.length > 1) {
                trailLine.geometry.dispose();
                // FIX: Use THREE.BufferGeometry
                trailLine.geometry = new THREE.BufferGeometry().setFromPoints(trailPoints.current);
                const colors = [];
                // FIX: Use THREE.Color
                const white = new THREE.Color(0xffffff);
                const gray = new THREE.Color(0x888888);
                for (let i = 0; i < trailPoints.current.length; i++) {
                    const t = i / (trailPoints.current.length - 1);
                    // FIX: Use THREE.Color
                    const color = new THREE.Color().lerpColors(gray, white, t);
                    colors.push(color.r, color.g, color.b);
                }
                // FIX: Use THREE.Float32BufferAttribute
                trailLine.geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
            }
        }
    });

    return (
        <group>
            <mesh ref={ref}>
                <sphereGeometry args={[0.3, 8, 8]} />
                <meshStandardMaterial color="white" emissive="white" emissiveIntensity={4} toneMapped={false} />
            </mesh>
            <primitive object={trailLine} />
        </group>
    );
};


const Scene = () => {
    const [jets, setJets] = useState<BattleEntity[]>([]);
    const [tracers, setTracers] = useState<TracerState[]>([]);
    const [missiles, setMissiles] = useState<MissileState[]>([]);
    const [flares, setFlares] = useState<FlareState[]>([]);
    // FIX: Use THREE.Matrix4 and THREE.Quaternion
    const tempMatrix = useMemo(() => new THREE.Matrix4(), []);
    const targetQuaternion = useMemo(() => new THREE.Quaternion(), []);
    const greenSwapTimerRef = useRef(GREEN_TARGET_SWAP_TIME);
    const controlsRef = useRef<OrbitControlsImpl>(null!);


    useEffect(() => {
        setJets(createInitialState().jets);
    }, []);

    useFrame((_state, delta) => {
        if (delta > 0.1) delta = 0.1; // Frame rate limiter
        
        let newTracers = [...tracers];
        let newFlares = [...flares];
        const newJets = jets.map(jet => ({
            ...jet,
            position: jet.position.clone(),
            velocity: jet.velocity.clone(),
            quaternion: jet.quaternion.clone(),
            burstState: {...jet.burstState},
            flareState: {...jet.flareState},
            wreckageAngularVelocity: jet.wreckageAngularVelocity ? jet.wreckageAngularVelocity.clone() : null,
        }));

        // --- Missile Detonation & Wreckage Creation ---
        const destroyedJetIds = new Set<string>();
        const newMissiles = missiles.map(m => ({...m})).filter(m => {
             const targetJet = newJets.find(j => j.id === m.targetId && !j.isWrecked && !j.isDestroyed);
            if (targetJet && m.position.distanceTo(targetJet.position) < MISSILE_PROXIMITY_DETONATION_RANGE) {
                if (m.willDetonate) {
                    if (!destroyedJetIds.has(targetJet.id)) {
                        destroyedJetIds.add(targetJet.id);
                    }
                    return false; // Missile is consumed
                } else {
                    m.targetId = null; // Dud missile, continues on its path
                }
            }
            return true;
        });

        if (destroyedJetIds.size > 0) {
            newJets.forEach(jet => {
                if (destroyedJetIds.has(jet.id)) {
                    jet.isWrecked = true;
                    jet.destroyedAt = Date.now();
                    // Add explosion impulse
                    // FIX: Use THREE.Vector3
                    jet.velocity.add(new THREE.Vector3((Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20, (Math.random() - 0.5) * 20));
                    // Add initial angular velocity for spinning
                    // FIX: Use THREE.Vector3
                    jet.wreckageAngularVelocity = new THREE.Vector3(
                        (Math.random() - 0.5) * 10, // roll
                        (Math.random() - 0.5) * 5, // pitch
                        (Math.random() - 0.5) * 10  // yaw
                    );
                }
            });
        }
        
        // --- Green Team Target Swapping ---
        greenSwapTimerRef.current -= delta;
        if (greenSwapTimerRef.current <= 0) {
            greenSwapTimerRef.current = GREEN_TARGET_SWAP_TIME;
            const greenJetsToSwap = newJets.filter(j => j.team === 'green' && !j.isDestroyed && !j.isWrecked);
            if (greenJetsToSwap.length === 2) {
                const tempTargetId = greenJetsToSwap[0].targetId;
                greenJetsToSwap[0].targetId = greenJetsToSwap[1].targetId;
                greenJetsToSwap[1].targetId = tempTargetId;
            }
        }

        // Handle respawns
        newJets.forEach(jet => {
            if ((jet.isDestroyed || jet.isWrecked) && jet.destroyedAt && Date.now() - jet.destroyedAt > RESPAWN_TIME) {
                jet.isDestroyed = false;
                jet.isWrecked = false;
                jet.wreckageAngularVelocity = null;
                jet.position.set((Math.random() - 0.5) * WORLD_RADIUS, (Math.random() - 0.5) * WORLD_RADIUS, (Math.random() - 0.5) * WORLD_RADIUS);
                jet.velocity.randomDirection().multiplyScalar(JET_SPEED);
                // FIX: Use THREE.Vector3
                jet.quaternion.setFromUnitVectors(new THREE.Vector3(0,0,1), jet.velocity.clone().normalize());
            }
        });
        
        // --- Pre-computation for AI ---
        const activeGreenJets = newJets.filter(j => j.team === 'green' && !j.isDestroyed && !j.isWrecked);
        // FIX: Use THREE.Vector3
        const greenBarycenter = new THREE.Vector3();
        if (activeGreenJets.length > 0) {
            activeGreenJets.forEach(j => greenBarycenter.add(j.position));
            greenBarycenter.divideScalar(activeGreenJets.length);
        }

        // --- Camera Controls ---
        if (controlsRef.current && activeGreenJets.length > 0) {
            controlsRef.current.target.lerp(greenBarycenter, delta * CAMERA_TARGET_LERP_SPEED);
            controlsRef.current.update();
        }

        for (const jet of newJets) {
            try {
                if (jet.isWrecked) {
                    // Wreckage physics
                    jet.velocity.multiplyScalar(1 - (delta * 0.9)); // Air resistance / drag
                    jet.velocity.y -= 9.8 * delta; // Gravity
                    jet.position.add(jet.velocity.clone().multiplyScalar(delta));

                    // Uncontrollable spin
                    if (jet.wreckageAngularVelocity) {
                        // FIX: Use THREE.Quaternion and THREE.Euler
                        const deltaRotation = new THREE.Quaternion().setFromEuler(
                            new THREE.Euler(
                                jet.wreckageAngularVelocity.x * delta,
                                jet.wreckageAngularVelocity.y * delta,
                                jet.wreckageAngularVelocity.z * delta
                            )
                        );
                        jet.quaternion.multiply(deltaRotation).normalize();
                    }
                    
                    // World boundaries for wreckage (disappear instead of teleport)
                    if (jet.position.length() > WORLD_RADIUS) {
                        jet.destroyedAt = Date.now() - RESPAWN_TIME - 1; // Mark for immediate cleanup
                    }
                    continue;
                }
                
                if (jet.isDestroyed) continue;

                // --- AI LOGIC ---
                let target = newJets.find(j => j.id === jet.targetId && !j.isDestroyed && !j.isWrecked);

                if (jet.team === 'red' && jet.aiState === 'attacking') {
                    jet.roleChangeTimer -= delta;
                    if (jet.roleChangeTimer <= 0) {
                        const partner = newJets.find(j => j.id === jet.partnerId);
                        if (partner) {
                            const oldTargetId = jet.targetId;
                            jet.aiState = 'following';
                            jet.targetId = partner.id;
                            jet.disengagementAltitude = jet.position.y + (Math.random() > 0.5 ? 1 : -1) * DISENGAGE_ALTITUDE_RANGE;
                            
                            partner.aiState = 'attacking';
                            partner.targetId = oldTargetId;
                            partner.roleChangeTimer = ROLE_SWAP_BASE_TIME + (Math.random() - 0.5) * 2 * ROLE_SWAP_RANDOMNESS;
                            partner.disengagementAltitude = null;
                        }
                        jet.roleChangeTimer = 999; // wait for partner to assign new time
                    }
                }

                if(jet.team === 'green') {
                    if(!target) {
                        const attackers = newJets.filter(j => j.team === 'red' && j.targetId === jet.id && !j.isDestroyed && !j.isWrecked);
                        if(attackers.length > 0) {
                            jet.targetId = attackers[0].id;
                        } else { // find a new target if current is destroyed or not attacking
                            const closestEnemy = newJets
                                .filter(j => j.team === 'red' && !j.isDestroyed && !j.isWrecked)
                                .sort((a,b) => a.position.distanceTo(jet.position) - b.position.distanceTo(jet.position));
                            if(closestEnemy.length > 0) {
                                jet.targetId = closestEnemy[0].id;
                            } else {
                                jet.targetId = null; // No valid targets left
                            }
                        }
                        target = newJets.find(j => j.id === jet.targetId);
                    }
                }
                
                // --- STEERING & PHYSICS ---
                if (target) {
                    let pointToLookAt: THREE.Vector3;

                    if (jet.aiState === 'following') {
                        const leader = newJets.find(j => j.id === jet.targetId);
                        if (leader) {
                            // FIX: Use THREE.Vector3
                            const leaderForward = new THREE.Vector3(0, 0, 1).applyQuaternion(leader.quaternion);
                            pointToLookAt = leader.position.clone().sub(leaderForward.multiplyScalar(15));
                            if (jet.team === 'red' && jet.disengagementAltitude !== null) {
                                pointToLookAt.y = jet.disengagementAltitude;
                            }
                        } else {
                            // FIX: Use THREE.Vector3
                            pointToLookAt = jet.position.clone().add(new THREE.Vector3(0,0,1).applyQuaternion(jet.quaternion));
                        }
                    } else {
                        pointToLookAt = target.position.clone();
                        // --- Lead Shot Prediction (for Kill Shot aiming) ---
                        if (jet.burstState.isKillShot && target) {
                            const distance = jet.position.distanceTo(target.position);
                            const timeToTarget = distance / TRACER_SPEED;
                            // Predict target's future position
                            const leadPoint = target.position.clone().add(target.velocity.clone().multiplyScalar(timeToTarget));
                            pointToLookAt = leadPoint;
                        }

                         if (jet.team === 'green' && activeGreenJets.length > 1) {
                            // --- Cohesion ---
                            const distToBarycenter = jet.position.distanceTo(greenBarycenter);
                            if (distToBarycenter > GREEN_COHESION_RADIUS) {
                                const pullFactor = Math.min(1, (distToBarycenter - GREEN_COHESION_RADIUS) / GREEN_COHESION_RADIUS);
                                pointToLookAt.lerp(greenBarycenter, pullFactor * GREEN_COHESION_STRENGTH);
                            }

                            // --- Avoidance ---
                            for (const otherJet of activeGreenJets) {
                                if (jet.id === otherJet.id) continue;
                        
                                const distanceToOther = jet.position.distanceTo(otherJet.position);
                        
                                if (distanceToOther < GREEN_AVOIDANCE_RADIUS) {
                                    // FIX: Use THREE.Vector3
                                    const repulsionVector = new THREE.Vector3().subVectors(jet.position, otherJet.position).normalize();
                                    // Strength increases quadratically as jets get closer
                                    const avoidanceStrength = Math.pow(1 - (distanceToOther / GREEN_AVOIDANCE_RADIUS), 2) * GREEN_AVOIDANCE_STRENGTH;
                                    
                                    // The point to steer towards to avoid the other jet
                                    const avoidancePoint = jet.position.clone().add(repulsionVector.multiplyScalar(WORLD_RADIUS)); 
                                    
                                    // Blend the original target point with the avoidance point
                                    pointToLookAt.lerp(avoidancePoint, avoidanceStrength);
                                }
                            }
                        }
                    }

                    const directionToTarget = pointToLookAt.clone().sub(jet.position).normalize();
                    // FIX: Use THREE.Vector3
                    const forward = new THREE.Vector3(0, 0, 1).applyQuaternion(jet.quaternion);
                    
                    const rotationAxis = forward.clone().cross(directionToTarget).normalize();
                    
                    if (rotationAxis.lengthSq() > 0.001) {
                        const targetUp = directionToTarget.clone().cross(rotationAxis).normalize().negate();
                        tempMatrix.lookAt(pointToLookAt, jet.position, targetUp);
                    } else {
                         // FIX: Use THREE.Vector3
                         tempMatrix.lookAt(pointToLookAt, jet.position, new THREE.Vector3(0, 1, 0));
                    }
                   
                    targetQuaternion.setFromRotationMatrix(tempMatrix);

                    let currentTurnSpeed = TURN_SPEED;
                    if (jet.burstState.isKillShot) {
                        currentTurnSpeed = TURN_SPEED * 3.0; // Hard turn for the kill shot
                    }

                    jet.quaternion.slerp(targetQuaternion, delta * currentTurnSpeed);
                }

                // FIX: Use THREE.Vector3
                const forward = new THREE.Vector3(0, 0, 1).applyQuaternion(jet.quaternion);
                jet.velocity.lerp(forward.clone().multiplyScalar(JET_SPEED), delta * 2.0);
                jet.position.add(jet.velocity.clone().multiplyScalar(delta));

                // --- FIRING LOGIC ---
                if (jet.aiState === 'attacking' && target) {
                    // FIX: Use THREE.Vector3
                    const forwardDir = new THREE.Vector3(0, 0, 1).applyQuaternion(jet.quaternion);
                    const dirToTarget = target.position.clone().sub(jet.position).normalize();
                    const dotProduct = forwardDir.dot(dirToTarget);
                    const isTargetInFront = dotProduct > FIRING_CONE_DOT_PRODUCT;
                    const distanceToTarget = jet.position.distanceTo(target.position);

                    jet.fireCooldown -= delta;
                    if (jet.fireCooldown <= 0 && !jet.burstState.active && isTargetInFront) {
                        
                        if (distanceToTarget > WEAPON_RANGE_THRESHOLD) { // Long range: Fire missile
                            // FIX: Use THREE.Vector3 and THREE.Quaternion
                            const fireDirection = new THREE.Vector3(0, 0, 1).applyQuaternion(jet.quaternion);
                            const missileVelocity = fireDirection.multiplyScalar(MISSILE_SPEED);
                            const finalVelocity = jet.velocity.clone().add(missileVelocity);
                            const missileQuaternion = new THREE.Quaternion();
                            missileQuaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), finalVelocity.clone().normalize());

                            newMissiles.push({
                                id: `m_${jet.id}_${Date.now()}`,
                                position: jet.position.clone(),
                                velocity: finalVelocity,
                                quaternion: missileQuaternion,
                                life: MISSILE_LIFESPAN,
                                targetId: jet.targetId,
                                willDetonate: Math.random() < 0.8,
                            });
                            
                            // --- TRIGGER FLARES on target ---
                            const targetJet = newJets.find(j => j.id === jet.targetId && !j.isDestroyed && !j.isWrecked);
                            if (targetJet && !targetJet.flareState.deploying) {
                                targetJet.flareState.deploying = true;
                                targetJet.flareState.flaresLeft = FLARES_TO_DEPLOY;
                                targetJet.flareState.nextFlareTimer = 0;
                            }

                            jet.fireCooldown = FIRING_COOLDOWN + (Math.random() - 0.5);
                        } else { // Close range: Fire tracers
                            jet.burstState.active = true;
                            jet.burstState.burstsLeft = BURST_COUNT;
                            jet.burstState.tracersLeftInBurst = TRACERS_PER_BURST;
                            jet.burstState.nextShotTimer = 0;
                            jet.fireCooldown = FIRING_COOLDOWN + (Math.random() - 0.5);
                        }
                    }
                }
                
                if (jet.burstState.active && target) {
                    jet.burstState.nextShotTimer -= delta;
                    if (jet.burstState.nextShotTimer <= 0) {
                        // FIX: Use THREE.Vector3 and THREE.Quaternion
                        const fireDirection = new THREE.Vector3(0, 0, 1).applyQuaternion(jet.quaternion);
                        fireDirection.add(new THREE.Vector3(Math.random() - 0.5, Math.random() - 0.5, Math.random() - 0.5).multiplyScalar(0.02)).normalize();

                        const tracerVelocity = jet.velocity.clone().add(fireDirection.multiplyScalar(TRACER_SPEED));
                        const tracerQuaternion = new THREE.Quaternion();
                        tracerQuaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), tracerVelocity.clone().normalize());

                        newTracers.push({
                            id: `t_${jet.id}_${Date.now()}_${Math.random()}`,
                            position: jet.position.clone(),
                            velocity: tracerVelocity,
                            quaternion: tracerQuaternion,
                            life: TRACER_LIFESPAN
                        });

                        // --- Kill Shot Execution ---
                        if (jet.burstState.isKillShot) {
                            const targetJet = newJets.find(j => j.id === jet.targetId && !j.isDestroyed && !j.isWrecked);
                            if (targetJet) {
                                targetJet.isWrecked = true;
                                targetJet.destroyedAt = Date.now();
                                // FIX: Use THREE.Vector3
                                targetJet.wreckageAngularVelocity = new THREE.Vector3(
                                    (Math.random() - 0.5) * 10,
                                    (Math.random() - 0.5) * 5,
                                    (Math.random() - 0.5) * 10
                                );
                            }
                            // End the burst immediately after the kill shot is fired.
                            jet.burstState.active = false;
                            jet.burstState.isKillShot = false;
                        }

                        if (jet.burstState.active) { // Only continue if not a kill shot
                            jet.burstState.tracersLeftInBurst--;
                            if (jet.burstState.tracersLeftInBurst <= 0) {
                                jet.burstState.burstsLeft--;
                                if (jet.burstState.burstsLeft <= 0) {
                                    jet.burstState.active = false;
                                    jet.burstState.isKillShot = false; // Reset
                                } else {
                                    jet.burstState.tracersLeftInBurst = TRACERS_PER_BURST;
                                    jet.burstState.nextShotTimer = TIME_BETWEEN_BURSTS;
                                    // Decide if the next burst (the 3rd one) is a kill shot
                                    if (jet.burstState.burstsLeft === 1 && Math.random() < 0.5) {
                                        jet.burstState.isKillShot = true;
                                    } else {
                                        jet.burstState.isKillShot = false;
                                    }
                                }
                            } else {
                                jet.burstState.nextShotTimer = TIME_BETWEEN_TRACERS;
                            }
                        }
                    }
                }
                
                 // --- FLARE DEPLOYMENT ---
                if (jet.flareState.deploying) {
                    jet.flareState.nextFlareTimer -= delta;
                    if (jet.flareState.nextFlareTimer <= 0 && jet.flareState.flaresLeft > 0) {
                        // FIX: Use THREE.Vector3
                        const right = new THREE.Vector3(1, 0, 0).applyQuaternion(jet.quaternion);
                        const back = new THREE.Vector3(0, 0, -1).applyQuaternion(jet.quaternion);

                        // Left flare
                        const leftVel = right.clone().negate().add(back.clone().multiplyScalar(0.5)).normalize().multiplyScalar(FLARE_EJECTION_SPEED);
                        const leftPos = jet.position.clone().add(right.clone().negate().multiplyScalar(FLARE_WING_OFFSET));
                        newFlares.push({
                            id: `f_${jet.id}_${Date.now()}_l`,
                            position: leftPos,
                            velocity: leftVel,
                            life: FLARE_LIFESPAN
                        });

                        // Right flare
                        const rightVel = right.clone().add(back.clone().multiplyScalar(0.5)).normalize().multiplyScalar(FLARE_EJECTION_SPEED);
                        const rightPos = jet.position.clone().add(right.clone().multiplyScalar(FLARE_WING_OFFSET));
                        newFlares.push({
                            id: `f_${jet.id}_${Date.now()}_r`,
                            position: rightPos,
                            velocity: rightVel,
                            life: FLARE_LIFESPAN
                        });

                        jet.flareState.flaresLeft -= 2;
                        if (jet.flareState.flaresLeft <= 0) {
                            jet.flareState.deploying = false;
                        } else {
                            jet.flareState.nextFlareTimer = TIME_BETWEEN_FLARE_PAIRS;
                        }
                    }
                }

                // World boundaries
                if (jet.position.length() > WORLD_RADIUS) {
                    jet.position.negate();
                }

            } catch (e) {
                console.error(`--- JET UPDATE ERROR [${jet.id}] ---`);
                console.error('An error occurred while updating a jet. The jet will be safely removed to prevent a crash.');
                console.error('Jet State:', jet);
                console.error(e);
                jet.isDestroyed = true;
                jet.destroyedAt = Date.now();
            }
        }
        
        // Update tracers
        const updatedTracers = newTracers.map(t => ({
            ...t,
            position: t.position.clone().add(t.velocity.clone().multiplyScalar(delta)),
            life: t.life - delta,
        })).filter(t => t.life > 0);

        // Update flares
        const updatedFlares = newFlares.map(f => {
            const newVelocity = f.velocity.clone();
            newVelocity.y -= 9.8 * delta; // Gravity
            newVelocity.multiplyScalar(1 - (delta * FLARE_DRAG)); // Drag

            return {
                ...f,
                position: f.position.clone().add(newVelocity.clone().multiplyScalar(delta)),
                velocity: newVelocity,
                life: f.life - delta,
            };
        }).filter(f => f.life > 0);

        // Update missiles
        const updatedMissiles = newMissiles.map(m => {
            let missileState = {...m};
            
            let newVelocity = missileState.velocity.clone();
            const currentTarget = newJets.find(j => j.id === missileState.targetId && !j.isWrecked && !j.isDestroyed);

            if (currentTarget) {
                // FIX: Use THREE.Vector3
                const targetForward = new THREE.Vector3(0, 0, 1).applyQuaternion(currentTarget.quaternion);
                const leadPoint = currentTarget.position.clone().add(targetForward.multiplyScalar(LEAD_TARGET_DISTANCE));
                
                const desiredDirection = leadPoint.sub(missileState.position).normalize();
                const desiredVelocity = desiredDirection.multiplyScalar(MISSILE_SPEED);
                
                newVelocity.lerp(desiredVelocity, delta * MISSILE_TURN_SPEED);
            }
            
            newVelocity.normalize().multiplyScalar(MISSILE_SPEED);
            const newPosition = missileState.position.clone().add(newVelocity.clone().multiplyScalar(delta));
            // FIX: Use THREE.Quaternion and THREE.Vector3
            const newQuaternion = new THREE.Quaternion();
            newQuaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), newVelocity.clone().normalize());

            return {
                ...missileState,
                position: newPosition,
                velocity: newVelocity,
                quaternion: newQuaternion,
                life: missileState.life - delta,
            };
        }).filter(m => m.life > 0);
        
        setJets(newJets);
        setTracers(updatedTracers);
        setMissiles(updatedMissiles);
        setFlares(updatedFlares);
    });

    return (
        <>
            <ambientLight intensity={0.8} />
            <directionalLight position={[10, 20, 5]} intensity={1.5} />
            <Skybox />
            {jets.map(jet => !jet.isDestroyed && (
                <Jet key={jet.id} jet={jet} />
            ))}
            {tracers.map(tracer => (
                <Tracer key={tracer.id} position={tracer.position} quaternion={tracer.quaternion} />
            ))}
            {missiles.map(missile => (
                <Missile key={missile.id} position={missile.position} quaternion={missile.quaternion} />
            ))}
             {flares.map(flare => (
                <Flare key={flare.id} position={flare.position} />
            ))}
            <OrbitControls ref={controlsRef} enablePan={true} minDistance={30} maxDistance={400} />
        </>
    );
}

const App = () => {
    return (
        <div id="app-container">
            <header>
                <h1>Dogfight Simulation</h1>
                <p>2 Green vs 4 Red Jets</p>
            </header>
            <Canvas camera={{ position: [0, 60, 150], fov: 60 }}>
                <Scene />
            </Canvas>
        </div>
    );
};

const container = document.getElementById('root');
if (container) {
    const root = createRoot(container);
    root.render(<App />);
}
