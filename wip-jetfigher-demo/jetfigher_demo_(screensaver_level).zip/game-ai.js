import * as CONST from './game-constants.js';

// Calculate AI steering for jets
export function calculateAISteering(jet, jets, greenBarycenter, tempMatrix, targetQuaternion) {
  const target = jets.find(j => j.id === jet.targetId && !j.isDestroyed && !j.isWrecked);
  if (!target) return null;

  let pointToLookAt;

  if (jet.aiState === 'following') {
    const leader = jets.find(j => j.id === jet.targetId);
    if (leader) {
      const leaderForward = new THREE.Vector3(0, 0, 1).applyQuaternion(leader.quaternion);
      pointToLookAt = leader.position.clone().sub(leaderForward.multiplyScalar(15));
      if (jet.team === 'red' && jet.disengagementAltitude !== null) {
        pointToLookAt.y = jet.disengagementAltitude;
      }
    } else {
      pointToLookAt = jet.position.clone().add(new THREE.Vector3(0, 0, 1).applyQuaternion(jet.quaternion));
    }
  } else {
    pointToLookAt = target.position.clone();

    // Lead shot prediction for kill shots
    if (jet.burstState.isKillShot && target) {
      const distance = jet.position.distanceTo(target.position);
      const timeToTarget = distance / CONST.TRACER_SPEED;
      const leadPoint = target.position.clone().add(target.velocity.clone().multiplyScalar(timeToTarget));
      pointToLookAt = leadPoint;
    }

    // Green team cohesion and avoidance
    if (jet.team === 'green') {
      const activeGreenJets = jets.filter(j => j.team === 'green' && !j.isDestroyed && !j.isWrecked);
      if (activeGreenJets.length > 1) {
        // Cohesion
        const distToBarycenter = jet.position.distanceTo(greenBarycenter);
        if (distToBarycenter > CONST.GREEN_COHESION_RADIUS) {
          const pullFactor = Math.min(1, (distToBarycenter - CONST.GREEN_COHESION_RADIUS) / CONST.GREEN_COHESION_RADIUS);
          pointToLookAt.lerp(greenBarycenter, pullFactor * CONST.GREEN_COHESION_STRENGTH);
        }

        // Avoidance
        for (const otherJet of activeGreenJets) {
          if (jet.id === otherJet.id) continue;
          const distanceToOther = jet.position.distanceTo(otherJet.position);
          if (distanceToOther < CONST.GREEN_AVOIDANCE_RADIUS) {
            const repulsionVector = new THREE.Vector3().subVectors(jet.position, otherJet.position).normalize();
            const avoidanceStrength = Math.pow(1 - (distanceToOther / CONST.GREEN_AVOIDANCE_RADIUS), 2) * CONST.GREEN_AVOIDANCE_STRENGTH;
            const avoidancePoint = jet.position.clone().add(repulsionVector.multiplyScalar(CONST.WORLD_RADIUS));
            pointToLookAt.lerp(avoidancePoint, avoidanceStrength);
          }
        }
      }
    }
  }

  const directionToTarget = pointToLookAt.clone().sub(jet.position).normalize();
  const forward = new THREE.Vector3(0, 0, 1).applyQuaternion(jet.quaternion);
  const rotationAxis = forward.clone().cross(directionToTarget).normalize();

  if (rotationAxis.lengthSq() > 0.001) {
    const targetUp = directionToTarget.clone().cross(rotationAxis).normalize().negate();
    tempMatrix.lookAt(pointToLookAt, jet.position, targetUp);
  } else {
    tempMatrix.lookAt(pointToLookAt, jet.position, new THREE.Vector3(0, 1, 0));
  }

  targetQuaternion.setFromRotationMatrix(tempMatrix);

  let currentTurnSpeed = CONST.TURN_SPEED;
  if (jet.burstState.isKillShot) {
    currentTurnSpeed = CONST.TURN_SPEED * 3.0;
  }

  return { targetQuaternion, turnSpeed: currentTurnSpeed, target };
}

// Handle red team role swapping
export function handleRedTeamRoleSwap(jet, jets, delta) {
  if (jet.team === 'red' && jet.aiState === 'attacking') {
    jet.roleChangeTimer -= delta;
    if (jet.roleChangeTimer <= 0) {
      const partner = jets.find(j => j.id === jet.partnerId);
      if (partner) {
        const oldTargetId = jet.targetId;
        jet.aiState = 'following';
        jet.targetId = partner.id;
        jet.disengagementAltitude = jet.position.y + (Math.random() > 0.5 ? 1 : -1) * CONST.DISENGAGE_ALTITUDE_RANGE;

        partner.aiState = 'attacking';
        partner.targetId = oldTargetId;
        partner.roleChangeTimer = CONST.ROLE_SWAP_BASE_TIME + (Math.random() - 0.5) * 2 * CONST.ROLE_SWAP_RANDOMNESS;
        partner.disengagementAltitude = null;
      }
      jet.roleChangeTimer = 999;
    }
  }
}

// Handle green team target assignment
export function handleGreenTargetAssignment(jet, jets) {
  if (jet.team === 'green') {
    const target = jets.find(j => j.id === jet.targetId && !j.isDestroyed && !j.isWrecked);
    if (!target) {
      const attackers = jets.filter(j => j.team === 'red' && j.targetId === jet.id && !j.isDestroyed && !j.isWrecked);
      if (attackers.length > 0) {
        jet.targetId = attackers[0].id;
      } else {
        const closestEnemy = jets
          .filter(j => j.team === 'red' && !j.isDestroyed && !j.isWrecked)
          .sort((a, b) => a.position.distanceTo(jet.position) - b.position.distanceTo(jet.position));
        if (closestEnemy.length > 0) {
          jet.targetId = closestEnemy[0].id;
        } else {
          jet.targetId = null;
        }
      }
    }
  }
}
