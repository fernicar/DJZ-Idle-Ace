import * as CONST from './game-constants.js';

// Create initial game state
export function createInitialState() {
  const jets = [];

  // Green team leader (player-controlled)
  jets.push(createJet(
    'green_0', 'green',
    new THREE.Vector3(0, 0, -20),
    new THREE.Vector3(0, 0, CONST.JET_SPEED),
    new THREE.Quaternion(),
    'attacking', 'red_0', 'green_1'
  ));

  // Green wingman (AI-controlled, mirrors player)
  jets.push(createJet(
    'green_1', 'green',
    new THREE.Vector3(-15, 0, -20),
    new THREE.Vector3(0, 0, CONST.JET_SPEED),
    new THREE.Quaternion(),
    'attacking', 'red_1', 'green_0'
  ));

  // Purple team (4 jets)
  const purpleVel = new THREE.Vector3(0, 0, -CONST.JET_SPEED);
  const purpleQuat = new THREE.Quaternion().setFromAxisAngle(new THREE.Vector3(0, 1, 0), Math.PI);

  jets.push(createJet('red_0', 'red', new THREE.Vector3(80, 5, -20), purpleVel.clone(), purpleQuat.clone(), 'attacking', 'green_0', 'red_1'));
  jets.push(createJet('red_1', 'red', new THREE.Vector3(95, 5, -20), purpleVel.clone(), purpleQuat.clone(), 'following', 'red_0', 'red_0'));
  jets.push(createJet('red_2', 'red', new THREE.Vector3(-80, -5, 20), purpleVel.clone(), purpleQuat.clone(), 'attacking', 'green_1', 'red_3'));
  jets.push(createJet('red_3', 'red', new THREE.Vector3(-95, -5, 20), purpleVel.clone(), purpleQuat.clone(), 'following', 'red_2', 'red_2'));

  return {
    jets,
    tracers: [],
    missiles: [],
    flares: [],
    playerControls: { turn: 0, pitch: 0, bank: 0 },
    greenSwapTimer: CONST.GREEN_TARGET_SWAP_TIME
  };
}

function createJet(id, team, position, velocity, quaternion, aiState, targetId, partnerId) {
  return {
    id, team, position, velocity, quaternion, aiState, targetId, partnerId,
    isDestroyed: false,
    isWrecked: false,
    destroyedAt: null,
    roleChangeTimer: aiState === 'attacking' ? CONST.ROLE_SWAP_BASE_TIME + (Math.random() - 0.5) * 2 * CONST.ROLE_SWAP_RANDOMNESS : 0,
    fireCooldown: Math.random() * CONST.FIRING_COOLDOWN,
    burstState: { active: false, burstsLeft: 0, tracersLeftInBurst: 0, nextShotTimer: 0, isKillShot: false },
    flareState: { deploying: false, flaresLeft: 0, nextFlareTimer: 0 },
    disengagementAltitude: null,
    wreckageAngularVelocity: null,
  };
}
