import { createInitialState } from './game-state.js';
import * as AI from './game-ai.js';
import * as Physics from './game-physics.js';
import * as Weapons from './game-weapons.js';
import { PlayerControls, createHUD, updateHUD } from './game-controls.js';
import * as CONST from './game-constants.js';

let gameState = null;
let playerControls = null;
let scene, camera, renderer;
let tempMatrix, targetQuaternion;
let animationId = null;

// Camera system
let currentCameraMode = 'overview'; // 'overview' or 'thirdPerson'
let thirdPersonCamera = null;

// Green team target swap timer
let greenSwapTimer = 10; // seconds

// Mesh caching
let jetMeshes = new Map();
let tracerMeshes = new Map();
let missileMeshes = new Map();
let flareMeshes = new Map();
let jetTrails = new Map(); // Trail position history
let missileTrails = new Map();
let flareTrails = new Map();
let targetMarkers = new Map(); // 3D target markers for green team

// Jet fighter model data (loaded from jetfighter.json)
let jetFighterModel = null;

// Sky and water references
let sky, sun, water;
let islands = [];

export function startGame() {
  // Initialize game state
  gameState = createInitialState();
  playerControls = new PlayerControls();

  // Load jet fighter model first
  loadJetFighterModel().then(() => {
    // Setup Three.js scene
    setupScene();

    // HUD removed - not working
    // Start game loop
    animate();
  });
}

export function stopGame() {
  if (animationId) {
    cancelAnimationFrame(animationId);
    animationId = null;
  }

  // Clean up scene
  if (renderer) {
    document.getElementById('gameContainer').innerHTML = '';
  }

  // HUD removed - not working

  // Clear mesh caches
  jetMeshes.clear();
  tracerMeshes.clear();
  missileMeshes.clear();
  flareMeshes.clear();
  jetTrails.clear();
  missileTrails.clear();
  flareTrails.clear();
  targetMarkers.clear();

  gameState = null;
  playerControls = null;
}

// Create procedural terrain - coastal landscape with water-colored low areas
function createIslands() {
  // Create a coastal terrain - land transitions to water-colored flat areas
  // Sun is at (300, 200, 100), so put water area on the positive X side (right)
  // Land will be on the negative X side (left)

  // Main terrain - single surface from land to water
  const terrainGeometry = new THREE.PlaneGeometry(10000, 10000, 150, 150);
  const terrainMaterial = new THREE.MeshStandardMaterial({
    color: 0x4a7c59, // Green land (will be overridden by vertex colors)
    flatShading: false,
    roughness: 0.8,
    metalness: 0.2,
    vertexColors: true
  });

  const terrain = new THREE.Mesh(terrainGeometry, terrainMaterial);

  // Position much deeper - well below the dogfight
  terrain.position.set(0, -450, 0);
  terrain.rotation.x = -Math.PI / 2;

  // Create coastal terrain with land-to-water transition
  const positions = terrain.geometry.attributes.position;
  const colors = [];

  for (let i = 0; i < positions.count; i++) {
    const x = positions.getX(i);
    const y = positions.getY(i);

    // Organic coastline with variation - not a straight line
    // Base coastline position varies with Y coordinate
    const coastlineVariation = Math.sin(y * 0.003) * 300 + Math.cos(y * 0.007) * 150 + Math.sin(y * 0.015) * 80;
    const coastlineX = 1000 + coastlineVariation;
    const distanceFromCoast = x - coastlineX;

    let height = 0;
    let color;

    if (x < coastlineX - 500) {
      // LAND AREA (left side, away from coast)
      // Multi-layered terrain with mountains and valleys
      height = 20 + Math.sin(x * 0.002) * 15;
      height += Math.cos(y * 0.0015) * 12;
      height += Math.sin(x * 0.005 + y * 0.005) * 10;
      height += Math.cos(x * 0.008 - y * 0.006) * 7;
      height += Math.sin(x * 0.015) * 5;
      height += Math.cos(y * 0.012) * 4;
      height += (Math.random() - 0.5) * 3;
      height = Math.max(height, 0);

      // Color based on height - more saturated, less pastel
      if (height > 45) {
        color = new THREE.Color(0x6b5d48); // Mountain peaks - darker brown
      } else if (height > 30) {
        color = new THREE.Color(0x556b3a); // High elevation - olive green
      } else if (height > 15) {
        color = new THREE.Color(0x2d6b2d); // Mid elevation - forest green
      } else {
        color = new THREE.Color(0x1a5c1a); // Low elevation - dark forest green
      }
    } else if (x < coastlineX) {
      // COASTAL TRANSITION (beach area with natural variation)
      const transitionWidth = 500 + Math.sin(y * 0.01) * 100; // Variable beach width
      const transitionFactor = (x - (coastlineX - transitionWidth)) / transitionWidth;

      height = 20 * (1 - transitionFactor);
      height += Math.sin(x * 0.01 + y * 0.008) * 3 * (1 - transitionFactor);
      height += Math.cos(y * 0.02) * 2 * (1 - transitionFactor);
      height = Math.max(height, 0);

      // Sandy beach color - more saturated
      color = new THREE.Color(0xa89968).lerp(new THREE.Color(0xc4b896), transitionFactor * 0.5);
    } else {
      // WATER AREA (right side, toward sun) - FLAT
      height = 0; // Completely flat water surface

      // Water blue color - more saturated, deeper blues
      const distVariation = Math.sin(x * 0.005 + y * 0.005) * 0.1;
      if (distVariation > 0.05) {
        color = new THREE.Color(0x1a7fb8); // Saturated light blue
      } else if (distVariation > 0) {
        color = new THREE.Color(0x0d6ba0); // Saturated medium blue
      } else if (distVariation > -0.05) {
        color = new THREE.Color(0x065788); // Saturated standard blue
      } else {
        color = new THREE.Color(0x004370); // Deep saturated blue
      }
    }

    positions.setZ(i, height);
    colors.push(color.r, color.g, color.b);
  }

  positions.needsUpdate = true;
  terrain.geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
  terrain.geometry.computeVertexNormals();

  scene.add(terrain);
  islands.push(terrain);
}

function setupScene() {
  const container = document.getElementById('gameContainer');
  container.innerHTML = '';

  scene = new THREE.Scene();
  scene.background = new THREE.Color(0x5090c0); // Darker sky blue fallback
  scene.fog = new THREE.Fog(0x5090c0, 500, 8000); // Atmospheric fog - darker to match sky

  camera = new THREE.PerspectiveCamera(60, window.innerWidth / window.innerHeight, 0.1, 100000);
  camera.position.set(0, 60, 150);

  renderer = new THREE.WebGLRenderer({ antialias: true });
  renderer.setSize(window.innerWidth, window.innerHeight);
  container.appendChild(renderer.domElement);

  // Lights
  const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
  scene.add(ambientLight);

  const dirLight = new THREE.DirectionalLight(0xfff4e6, 1.8);
  dirLight.position.set(300, 200, 100);
  scene.add(dirLight);

  // Add procedural sky with better colors - matched to terrain size
  sky = new THREE.Mesh(
    new THREE.SphereGeometry(5000, 32, 15),
    new THREE.ShaderMaterial({
      uniforms: {
        sunPosition: { value: new THREE.Vector3(300, 200, 100) },
        time: { value: 0 }
      },
      vertexShader: `
        varying vec3 vWorldPosition;
        void main() {
          vec4 worldPosition = modelMatrix * vec4(position, 1.0);
          vWorldPosition = worldPosition.xyz;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0);
        }
      `,
      fragmentShader: `
        uniform vec3 sunPosition;
        varying vec3 vWorldPosition;

        void main() {
          vec3 direction = normalize(vWorldPosition);
          float sunAngle = dot(direction, normalize(sunPosition));

          // Enhanced sky gradient - darker, more saturated
          float elevation = direction.y;
          vec3 zenithColor = vec3(0.1, 0.3, 0.7);      // Darker blue at top
          vec3 horizonColor = vec3(0.5, 0.65, 0.85);    // Medium blue at horizon

          vec3 skyColor = mix(
            horizonColor,
            zenithColor,
            pow(max(elevation, 0.0), 0.4)
          );

          // Sun disc (visible sun)
          float sunSize = 0.999875; // Larger value = smaller sun (closer to 1.0 = smaller)
          float sunDisc = step(sunSize, sunAngle);
          vec3 sunColor = vec3(1.0, 1.0, 0.95) * sunDisc * 10.0;

          // Sun glow (halo around sun)
          float sunGlow = pow(max(sunAngle, 0.0), 50.0) * 0.5;
          vec3 glowColor = vec3(1.0, 0.95, 0.8) * sunGlow;

          gl_FragColor = vec4(skyColor + sunColor + glowColor, 1.0);
        }
      `,
      side: THREE.BackSide
    })
  );
  // Position sky sphere so its equator aligns with the ocean/terrain height (y = -450)
  sky.position.set(0, -450, 0);
  scene.add(sky);

  // Sun position (over the ocean on the right side)
  sun = new THREE.Vector3(300, 200, 100);

  // Add terrain (includes ocean surface)
  createIslands();

  tempMatrix = new THREE.Matrix4();
  targetQuaternion = new THREE.Quaternion();

  // Setup third-person camera (will be mounted to green_0 jet when it's created)
  thirdPersonCamera = new THREE.PerspectiveCamera(90, window.innerWidth / window.innerHeight, 0.1, 100000);

  // Camera toggle with 'C' key and Esc to return to menu
  window.addEventListener('keydown', (e) => {
    if (e.key === 'c' || e.key === 'C') {
      currentCameraMode = currentCameraMode === 'overview' ? 'thirdPerson' : 'overview';
      console.log(`Camera mode switched to: ${currentCameraMode}`);
    }
    if (e.key === 'Escape') {
      // Return to main menu without confirmation (development mode)
      stopGame();
      document.getElementById('mainMenu').style.display = 'flex';
      document.getElementById('gameContainer').classList.remove('active');
      console.log('Returned to main menu (Esc pressed)');
    }
  });

  // Handle window resize
  window.addEventListener('resize', () => {
    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();
    thirdPersonCamera.aspect = window.innerWidth / window.innerHeight;
    thirdPersonCamera.updateProjectionMatrix();
    renderer.setSize(window.innerWidth, window.innerHeight);
  });
}

function animate() {
  animationId = requestAnimationFrame(animate);

  const delta = Math.min(0.1, 1 / 60);

  if (!gameState) return;

  updateGame(delta);
  renderScene();
}

function updateGame(delta) {
  // Update player input
  const input = playerControls.update();

  // Handle target switch request
  if (input.targetSwitchRequest) {
    const playerJet = gameState.jets.find(j => j.id === 'green_0');
    const wingmanJet = gameState.jets.find(j => j.id === 'green_1');
    if (playerJet && wingmanJet) {
      // Swap targets between player and wingman
      const tempTarget = playerJet.targetId;
      playerJet.targetId = wingmanJet.targetId;
      wingmanJet.targetId = tempTarget;
    }
  }

  // Calculate green barycenter for AI
  const activeGreenJets = gameState.jets.filter(j => j.team === 'green' && !j.isDestroyed && !j.isWrecked);
  const greenBarycenter = new THREE.Vector3();
  if (activeGreenJets.length > 0) {
    activeGreenJets.forEach(j => greenBarycenter.add(j.position));
    greenBarycenter.divideScalar(activeGreenJets.length);
  }

  // Update overview camera to follow green barycenter
  camera.position.lerp(
    greenBarycenter.clone().add(new THREE.Vector3(0, 60, 150)),
    delta * 1.0
  );
  camera.lookAt(greenBarycenter);

  // Update third-person camera pitch compensation
  const greenLeader = gameState.jets.find(j => j.id === 'green_0');
  if (greenLeader && thirdPersonCamera) {
    if (greenLeader.isWrecked) {
      // When wrecked: unmount camera from spinning jet, make it follow smoothly
      if (thirdPersonCamera.parent && thirdPersonCamera.parent.parent) { // Camera is still mounted on jet
        const jetMesh = jetMeshes.get('green_0');
        if (jetMesh) {
          // Get world position/rotation before unmounting
          const worldPos = new THREE.Vector3();
          const worldQuat = new THREE.Quaternion();
          thirdPersonCamera.getWorldPosition(worldPos);
          thirdPersonCamera.getWorldQuaternion(worldQuat);

          // Unmount from jet
          thirdPersonCamera.parent.remove(thirdPersonCamera);
          scene.add(thirdPersonCamera);

          // Set to world position/rotation
          thirdPersonCamera.position.copy(worldPos);
          thirdPersonCamera.quaternion.copy(worldQuat);

          console.log('Camera unmounted from wrecked jet');
        }
      }

      // Smoothly align camera to falling direction (no chaotic spin)
      const fallingDirection = greenLeader.velocity.clone().normalize();
      const targetUp = new THREE.Vector3(0, 1, 0);
      const lookMatrix = new THREE.Matrix4();
      lookMatrix.lookAt(
        new THREE.Vector3(0, 0, 0),
        fallingDirection,
        targetUp
      );
      const smoothQuaternion = new THREE.Quaternion().setFromRotationMatrix(lookMatrix);

      // Smoothly follow jet position and rotation
      thirdPersonCamera.position.lerp(
        greenLeader.position.clone().add(fallingDirection.clone().multiplyScalar(-15)),
        delta * 2.0
      );
      thirdPersonCamera.quaternion.slerp(smoothQuaternion, delta * 2.0);
    } else {
      // Normal flight: check if camera needs to be re-mounted (after respawn)
      if (!thirdPersonCamera.parent || thirdPersonCamera.parent === scene) {
        // Camera is not mounted, need to remount it to the jet
        const jetMesh = jetMeshes.get('green_0');
        if (jetMesh) {
          // Find the camera arm in the jet mesh
          const cameraArm = jetMesh.getObjectByName('cameraArm');
          if (cameraArm) {
            // Remove camera from scene
            scene.remove(thirdPersonCamera);

            // Re-mount to camera arm
            cameraArm.add(thirdPersonCamera);
            thirdPersonCamera.position.set(0, 7, -15); // Camera at end of arm
            thirdPersonCamera.rotation.set(0, Math.PI, 0); // Look forward

            console.log('Camera re-mounted to respawned jet');
          }
        }
      } else {
        // Camera is already mounted, apply pitch compensation to camera arm
        const cameraArm = thirdPersonCamera.parent;
        if (cameraArm && cameraArm.name === 'cameraArm') {
          // Calculate pitch compensation for the arm to see both target and jet belly
          // Get target jet
          const target = gameState.jets.find(j => j.id === greenLeader.targetId);

          if (target) {
            // Calculate direction from jet to target in jet's local space
            const jetToTarget = new THREE.Vector3().subVectors(target.position, greenLeader.position);

            // Transform to jet's local space
            const jetWorldQuatInverse = greenLeader.quaternion.clone().invert();
            jetToTarget.applyQuaternion(jetWorldQuatInverse);

            // Calculate raw pitch angle to target
            const distanceXZ = Math.sqrt(jetToTarget.x * jetToTarget.x + jetToTarget.z * jetToTarget.z);
            let rawPitch = 0;

            if (distanceXZ > 0.1) {
              // Raw angle to target (positive = target below, negative = target above)
              rawPitch = Math.atan2(-jetToTarget.y, jetToTarget.z);

              // Apply compensation curve: smoothly increase compensation as target gets further off-axis
              // Using a power curve to make small angles have minimal compensation, large angles get more
              const maxCompensation = Math.PI / 32; // Maximum 5.625 degrees
              const compensationStrength = 2.0; // Power curve factor (higher = more gradual)

              // Normalize raw pitch to 0-1 range based on maximum we care about
              const normalizedPitch = Math.abs(rawPitch) / (Math.PI / 4); // Normalize against 45° max

              // Apply power curve: compensation = max * (normalized ^ strength)
              const compensationFactor = Math.pow(Math.min(normalizedPitch, 1.0), compensationStrength);
              const desiredPitch = Math.sign(rawPitch) * maxCompensation * compensationFactor;

              // Rotate the arm around X axis at its attachment point
              cameraArm.rotation.x = desiredPitch;

              // Also rotate the camera itself by the same angle for combined effect
              thirdPersonCamera.rotation.set(desiredPitch, Math.PI, 0);
            } else {
              // Target too close or invalid
              cameraArm.rotation.x = 0;
              thirdPersonCamera.rotation.set(0, Math.PI, 0);
            }
          } else {
            // No target: default position (level)
            cameraArm.rotation.x = 0;
            thirdPersonCamera.rotation.set(0, Math.PI, 0);
          }
        }
      }
    }
  }

  // Green team target swapping (every 10 seconds)
  greenSwapTimer -= delta;
  if (greenSwapTimer <= 0) {
    greenSwapTimer = 10; // Reset timer
    const greenJetsToSwap = gameState.jets.filter(j => j.team === 'green' && !j.isDestroyed && !j.isWrecked);
    if (greenJetsToSwap.length === 2) {
      const tempTargetId = greenJetsToSwap[0].targetId;
      greenJetsToSwap[0].targetId = greenJetsToSwap[1].targetId;
      greenJetsToSwap[1].targetId = tempTargetId;
      console.log('Green team swapped targets:', greenJetsToSwap[0].id, '→', greenJetsToSwap[0].targetId, '|', greenJetsToSwap[1].id, '→', greenJetsToSwap[1].targetId);
    }
  }

  // Process each jet (ALL use AI including green_0)
  gameState.jets.forEach(jet => {
    if (jet.isWrecked || jet.isDestroyed) {
      Physics.handleRespawn(jet);
      Physics.updateJetPhysics(jet, delta);
      return;
    }

    // AI behavior for ALL jets (including player's green_0)
    AI.handleRedTeamRoleSwap(jet, gameState.jets, delta);
    AI.handleGreenTargetAssignment(jet, gameState.jets);

    const steering = AI.calculateAISteering(jet, gameState.jets, greenBarycenter, tempMatrix, targetQuaternion);
    if (steering) {
      jet.quaternion.slerp(steering.targetQuaternion, delta * steering.turnSpeed);
    }

    // Update physics (automated for ALL)
    Physics.updateJetPhysics(jet, delta);

    // Weapons (automated for ALL attacking jets)
    if (jet.aiState === 'attacking') {
      const weaponType = Weapons.fireBurst(jet, gameState.jets, gameState.tracers);
      if (weaponType === 'missile') {
        Weapons.fireMissile(jet, gameState.jets, gameState.missiles);
      }
      Weapons.updateBurst(jet, gameState.jets, gameState.tracers, delta);
    }

    Weapons.deployFlares(jet, gameState.flares, delta);
  });

  // Update missiles
  gameState.missiles = Physics.checkMissileDetonation(gameState.missiles, gameState.jets);
  gameState.missiles.forEach(m => Physics.updateMissilePhysics(m, gameState.jets, delta));
  gameState.missiles = gameState.missiles.filter(m => m.life > 0);

  // Update tracers
  gameState.tracers.forEach(t => Physics.updateTracerPhysics(t, delta));
  gameState.tracers = gameState.tracers.filter(t => t.life > 0);

  // Update flares
  gameState.flares.forEach(f => Physics.updateFlarePhysics(f, delta));
  gameState.flares = gameState.flares.filter(f => f.life > 0);

  // HUD removed - not working
}

function renderScene() {
  // Update existing jet meshes or create new ones
  gameState.jets.forEach(jet => {
    if (jet.isDestroyed) {
      if (jetMeshes.has(jet.id)) {
        scene.remove(jetMeshes.get(jet.id));
        jetMeshes.delete(jet.id);
      }
      if (jetTrails.has(jet.id)) {
        const trail = jetTrails.get(jet.id);
        scene.remove(trail.line);
        trail.line.geometry.dispose();
        trail.line.material.dispose();
        jetTrails.delete(jet.id);
      }
      return;
    }

    let jetMesh = jetMeshes.get(jet.id);
    if (!jetMesh) {
      jetMesh = createJetMesh(jet);
      jetMeshes.set(jet.id, jetMesh);
      scene.add(jetMesh);
    }

    // Update position and rotation
    jetMesh.position.copy(jet.position);
    jetMesh.quaternion.copy(jet.quaternion);

    // Show/hide explosion sphere based on wreckage state
    const explosionSphere = jetMesh.getObjectByName('explosionSphere');
    if (explosionSphere) {
      explosionSphere.visible = jet.isWrecked;
    }

    // Update engine exhaust cones based on speed
    const speedFactor = jet.velocity.length() / CONST.JET_SPEED; // Normalize to 0-1+ range
    const exhaustScale = 0.5 + speedFactor * 0.5; // Scale from 0.5x to 1.0x+ based on speed
    const exhaustOffset = speedFactor * 0.3; // Offset toward tail when speeding up

    if (jet.id === 'green_0') {
      // User jet: animate both outer and inner cones
      const exhaustOuterLeft = jetMesh.getObjectByName('exhaustOuterLeft');
      const exhaustInnerLeft = jetMesh.getObjectByName('exhaustInnerLeft');
      const exhaustOuterRight = jetMesh.getObjectByName('exhaustOuterRight');
      const exhaustInnerRight = jetMesh.getObjectByName('exhaustInnerRight');

      if (exhaustOuterLeft) {
        exhaustOuterLeft.scale.set(1, exhaustScale, 1);
        exhaustOuterLeft.position.z = -3.2 - exhaustOffset;
      }
      if (exhaustInnerLeft) {
        exhaustInnerLeft.scale.set(1, exhaustScale, 1);
        exhaustInnerLeft.position.z = -3.2 - exhaustOffset;
      }
      if (exhaustOuterRight) {
        exhaustOuterRight.scale.set(1, exhaustScale, 1);
        exhaustOuterRight.position.z = -3.2 - exhaustOffset;
      }
      if (exhaustInnerRight) {
        exhaustInnerRight.scale.set(1, exhaustScale, 1);
        exhaustInnerRight.position.z = -3.2 - exhaustOffset;
      }
    } else {
      // Other jets: animate single cones
      const exhaustLeft = jetMesh.getObjectByName('exhaustLeft');
      const exhaustRight = jetMesh.getObjectByName('exhaustRight');

      if (exhaustLeft) {
        exhaustLeft.scale.set(1, exhaustScale, 1);
        exhaustLeft.position.z = -3.2 - exhaustOffset;
      }
      if (exhaustRight) {
        exhaustRight.scale.set(1, exhaustScale, 1);
        exhaustRight.position.z = -3.2 - exhaustOffset;
      }
    }

    // Update trail (different handling for wrecked vs normal)
    if (!jetTrails.has(jet.id)) {
      const trailColor = jet.team === 'green' ? 0x4ADE80 : 0xF87171;
      console.log(`Creating trail for ${jet.id}, team: ${jet.team}, color: ${trailColor.toString(16)}`);
      const geometry = new THREE.BufferGeometry();
      const material = new THREE.LineBasicMaterial({
        color: trailColor,
        transparent: true,
        opacity: 0.6,
        vertexColors: false, // Will be enabled for smoke trails
        linewidth: 2
      });
      const line = new THREE.Line(geometry, material);
      scene.add(line);
      jetTrails.set(jet.id, { points: [], line, isWrecked: false, team: jet.team });
    }

    const trail = jetTrails.get(jet.id);

    // Delete and recreate trail if team changed (respawn scenario)
    if (trail.team !== jet.team) {
      console.log(`Team mismatch for ${jet.id}: trail.team=${trail.team}, jet.team=${jet.team}`);
      scene.remove(trail.line);
      trail.line.geometry.dispose();
      trail.line.material.dispose();
      jetTrails.delete(jet.id);

      // Create new trail with correct color
      const trailColor = jet.team === 'green' ? 0x4ADE80 : 0xF87171;
      console.log(`Recreating trail for ${jet.id}, team: ${jet.team}, color: ${trailColor.toString(16)}`);
      const geometry = new THREE.BufferGeometry();
      const material = new THREE.LineBasicMaterial({
        color: trailColor,
        transparent: true,
        opacity: 0.6,
        vertexColors: false,
        linewidth: 2
      });
      const line = new THREE.Line(geometry, material);
      scene.add(line);
      jetTrails.set(jet.id, { points: [], line, isWrecked: false, team: jet.team });
      return; // Skip rest of trail updates this frame
    }

    if (jet.isWrecked) {
      // Wreckage smoke trail - longer, with bright color gradient
      if (!trail.isWrecked) {
        trail.isWrecked = true;
        trail.points.length = 0; // Reset trail when transitioning to wreckage
        // Enable vertex colors for smoke gradient
        trail.line.material.vertexColors = true;
        trail.line.material.opacity = 1.0; // Full opacity for smoke visibility
        trail.line.material.linewidth = 10; // Try thicker (though WebGL may limit this)
        trail.line.material.needsUpdate = true;
      }

      trail.points.push(jet.position.clone());
      if (trail.points.length > 400) trail.points.shift(); // Longer smoke trail

      if (trail.points.length > 1) {
        trail.line.geometry.dispose();
        trail.line.geometry = new THREE.BufferGeometry().setFromPoints(trail.points);

        // Add BRIGHT smoke color gradient (bright yellow/orange at jet, orange at tail)
        const colors = [];
        const brightYellow = new THREE.Color(0xffff00); // Bright yellow
        const brightOrange = new THREE.Color(0xff6600); // Bright orange
        const darkOrange = new THREE.Color(0xcc4400); // Dark orange (not gray)

        for (let i = 0; i < trail.points.length; i++) {
          const t = i / (trail.points.length - 1);
          const color = new THREE.Color();
          if (t > 0.7) {
            // Recent trail: bright orange to bright yellow
            color.lerpColors(brightOrange, brightYellow, (t - 0.7) / 0.3);
          } else {
            // Older trail: dark orange to bright orange
            color.lerpColors(darkOrange, brightOrange, t / 0.7);
          }
          colors.push(color.r, color.g, color.b);
        }
        trail.line.geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
      }

      // Make trail visible
      trail.line.visible = true;
    } else {
      // Normal flight trail
      if (trail.isWrecked) {
        trail.isWrecked = false;
        trail.points.length = 0; // Reset trail when recovering from wreckage

        // Reset material to use team color instead of vertex colors
        trail.line.material.vertexColors = false;
        trail.line.material.opacity = 0.6; // Restore normal trail opacity
        const trailColor = jet.team === 'green' ? 0x4ADE80 : 0xF87171;
        trail.line.material.color.setHex(trailColor);
        trail.line.material.needsUpdate = true;
      }

      // Check for teleportation (world boundary wrap)
      if (trail.points.length > 0) {
        const lastPoint = trail.points[trail.points.length - 1];
        const teleportThreshold = CONST.WORLD_RADIUS;
        if (jet.position.distanceTo(lastPoint) > teleportThreshold) {
          trail.points.length = 0; // Clear trail on teleport
        }
      }

      trail.points.push(jet.position.clone());
      if (trail.points.length > 50) trail.points.shift();

      if (trail.points.length > 1) {
        trail.line.geometry.dispose();
        trail.line.geometry = new THREE.BufferGeometry().setFromPoints(trail.points);
      }
    }

    // Update wreckage effect
    const fireChild = jetMesh.children.find(c => c.userData.isFire);
    if (jet.isWrecked && !fireChild) {
      const fire = new THREE.Mesh(
        new THREE.SphereGeometry(0.5, 16, 16),
        new THREE.MeshStandardMaterial({
          color: 'orange',
          emissive: 'orange',
          emissiveIntensity: 4,
          transparent: true,
          opacity: 0.6
        })
      );
      fire.scale.set(0.5, 0.5, 1.5);
      fire.userData.isFire = true;
      jetMesh.add(fire);
    } else if (!jet.isWrecked && fireChild) {
      jetMesh.remove(fireChild);
    }
  });

  // Remove jets that no longer exist
  jetMeshes.forEach((mesh, id) => {
    if (!gameState.jets.find(j => j.id === id)) {
      scene.remove(mesh);
      jetMeshes.delete(id);
    }
  });

  jetTrails.forEach((trail, id) => {
    if (!gameState.jets.find(j => j.id === id)) {
      scene.remove(trail.line);
      jetTrails.delete(id);
    }
  });

  // Update tracers
  const currentTracerIds = new Set(gameState.tracers.map(t => t.id));
  tracerMeshes.forEach((mesh, id) => {
    if (!currentTracerIds.has(id)) {
      scene.remove(mesh);
      tracerMeshes.delete(id);
    }
  });

  gameState.tracers.forEach(tracer => {
    let mesh = tracerMeshes.get(tracer.id);
    if (!mesh) {
      mesh = createTracerMesh(tracer);
      tracerMeshes.set(tracer.id, mesh);
      scene.add(mesh);
    }
    mesh.position.copy(tracer.position);
    mesh.quaternion.copy(tracer.quaternion);
  });

  // Update missiles
  const currentMissileIds = new Set(gameState.missiles.map(m => m.id));
  missileMeshes.forEach((mesh, id) => {
    if (!currentMissileIds.has(id)) {
      scene.remove(mesh);
      missileMeshes.delete(id);
    }
  });

  missileTrails.forEach((trail, id) => {
    if (!currentMissileIds.has(id)) {
      scene.remove(trail.line);
      missileTrails.delete(id);
    }
  });

  gameState.missiles.forEach(missile => {
    let mesh = missileMeshes.get(missile.id);
    if (!mesh) {
      mesh = createMissileMesh(missile);
      missileMeshes.set(missile.id, mesh);
      scene.add(mesh);
    }
    mesh.position.copy(missile.position);
    mesh.quaternion.copy(missile.quaternion);

    // Add missile trail
    if (!missileTrails.has(missile.id)) {
      const geometry = new THREE.BufferGeometry();
      const material = new THREE.LineBasicMaterial({ color: 0xCCCCCC, transparent: true, opacity: 0.5 });
      const line = new THREE.Line(geometry, material);
      scene.add(line);
      missileTrails.set(missile.id, { points: [], line });
    }

    const trail = missileTrails.get(missile.id);
    trail.points.push(missile.position.clone());
    if (trail.points.length > 30) trail.points.shift();

    if (trail.points.length > 1) {
      trail.line.geometry.dispose();
      trail.line.geometry = new THREE.BufferGeometry().setFromPoints(trail.points);
    }
  });

  // Update flares
  const currentFlareIds = new Set(gameState.flares.map(f => f.id));
  flareMeshes.forEach((mesh, id) => {
    if (!currentFlareIds.has(id)) {
      scene.remove(mesh);
      flareMeshes.delete(id);
    }
  });

  flareTrails.forEach((trail, id) => {
    if (!currentFlareIds.has(id)) {
      scene.remove(trail.line);
      flareTrails.delete(id);
    }
  });

  gameState.flares.forEach(flare => {
    let mesh = flareMeshes.get(flare.id);
    if (!mesh) {
      mesh = createFlareMesh(flare);
      flareMeshes.set(flare.id, mesh);
      scene.add(mesh);
    }
    mesh.position.copy(flare.position);

    // Add flare trail with color gradient
    if (!flareTrails.has(flare.id)) {
      const geometry = new THREE.BufferGeometry();
      const material = new THREE.LineBasicMaterial({
        color: 0xFFFFFF,
        transparent: true,
        opacity: 0.8,
        vertexColors: true
      });
      const line = new THREE.Line(geometry, material);
      scene.add(line);
      flareTrails.set(flare.id, { points: [], line });
    }

    const trail = flareTrails.get(flare.id);
    trail.points.push(flare.position.clone());
    if (trail.points.length > 20) trail.points.shift();

    if (trail.points.length > 1) {
      trail.line.geometry.dispose();
      trail.line.geometry = new THREE.BufferGeometry().setFromPoints(trail.points);

      // Add white to gray gradient
      const colors = [];
      const white = new THREE.Color(0xffffff);
      const gray = new THREE.Color(0x888888);
      for (let i = 0; i < trail.points.length; i++) {
        const t = i / (trail.points.length - 1);
        const color = new THREE.Color().lerpColors(gray, white, t);
        colors.push(color.r, color.g, color.b);
      }
      trail.line.geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
    }
  });

  // Update 3D target markers for green team
  const green0Jet = gameState.jets.find(j => j.id === 'green_0');
  const green1Jet = gameState.jets.find(j => j.id === 'green_1');

  // Get active camera for billboard rotation
  const activeCamera = currentCameraMode === 'thirdPerson' ? thirdPersonCamera : camera;

  // Green_0 target marker (yellow) - always follows green_0's current target
  if (green0Jet && green0Jet.targetId) {
    const target = gameState.jets.find(j => j.id === green0Jet.targetId && !j.isDestroyed && !j.isWrecked);
    if (target) {
      if (!targetMarkers.has('green_0_marker')) {
        const marker = createTargetMarker(0xffff00, 1.0); // Yellow
        scene.add(marker);
        targetMarkers.set('green_0_marker', marker);
      }
      const marker = targetMarkers.get('green_0_marker');

      // Update color to ensure it stays yellow (in case of target swap)
      marker.material.color.setHex(0xffff00);

      marker.position.copy(target.position);

      // Billboard: make diamond face camera AND align up/down with camera
      // Get camera world position and quaternion
      const cameraWorldPos = new THREE.Vector3();
      const cameraWorldQuat = new THREE.Quaternion();
      activeCamera.getWorldPosition(cameraWorldPos);
      activeCamera.getWorldQuaternion(cameraWorldQuat);

      // Make marker copy camera's orientation (billboard effect)
      marker.quaternion.copy(cameraWorldQuat);

      // Scale based on distance to camera (constant screen size)
      const distanceToCamera = target.position.distanceTo(cameraWorldPos);
      const scale = distanceToCamera * 0.015; // Adjust this multiplier for desired size
      marker.scale.set(scale, scale, scale);

      marker.visible = true;
    } else if (targetMarkers.has('green_0_marker')) {
      targetMarkers.get('green_0_marker').visible = false;
    }
  } else if (targetMarkers.has('green_0_marker')) {
    targetMarkers.get('green_0_marker').visible = false;
  }

  // Green_1 target marker (blue) - always follows green_1's current target
  if (green1Jet && green1Jet.targetId) {
    const target = gameState.jets.find(j => j.id === green1Jet.targetId && !j.isDestroyed && !j.isWrecked);
    if (target) {
      if (!targetMarkers.has('green_1_marker')) {
        const marker = createTargetMarker(0x00bfff, 1.0); // Blue
        scene.add(marker);
        targetMarkers.set('green_1_marker', marker);
      }
      const marker = targetMarkers.get('green_1_marker');

      // Update color to ensure it stays blue (in case of target swap)
      marker.material.color.setHex(0x00bfff);

      marker.position.copy(target.position);

      // Billboard: make diamond face camera AND align up/down with camera
      // Get camera world position and quaternion
      const cameraWorldPos = new THREE.Vector3();
      const cameraWorldQuat = new THREE.Quaternion();
      activeCamera.getWorldPosition(cameraWorldPos);
      activeCamera.getWorldQuaternion(cameraWorldQuat);

      // Make marker copy camera's orientation (billboard effect)
      marker.quaternion.copy(cameraWorldQuat);

      // Scale based on distance to camera (constant screen size)
      const distanceToCamera = target.position.distanceTo(cameraWorldPos);
      const scale = distanceToCamera * 0.015; // Adjust this multiplier for desired size
      marker.scale.set(scale, scale, scale);

      marker.visible = true;
    } else if (targetMarkers.has('green_1_marker')) {
      targetMarkers.get('green_1_marker').visible = false;
    }
  } else if (targetMarkers.has('green_1_marker')) {
    targetMarkers.get('green_1_marker').visible = false;
  }

  // Render with the active camera
  renderer.render(scene, activeCamera);
}

// Load jet fighter model from JSON
async function loadJetFighterModel() {
  try {
    const response = await fetch('./jetfighter.json');
    jetFighterModel = await response.json();
    console.log('Jet fighter model loaded:', jetFighterModel);
  } catch (error) {
    console.error('Failed to load jet fighter model:', error);
  }
}

function createJetMesh(jet) {
  const group = new THREE.Group();

  if (!jetFighterModel) {
    console.error('Jet fighter model not loaded yet');
    return group;
  }

  // Use low poly (3 segments) for all jets except green_0 (leader uses 8 segments)
  const segments = jet.id === 'green_0' ? 8 : 3;

  // Process each component from the model
  jetFighterModel.components.forEach(compData => {
    let geometry, material;

    // Get base color from model and replace based on team
    let color = compData.color;

    // Color replacement logic:
    // Green team: keep original colors from modeler (#132853, #13502b, etc.)
    // Purple team: replace blue/green/gray colors with purple variants
    if (jet.team === 'red') {
      // Replace blue (#132853, etc.) with purple
      if (color === '#132853') color = '#4a1370'; // Dark purple
      if (color === '#13502b') color = '#6b1a8f'; // Medium purple
      if (color === '#00ffff') color = '#ff00ff'; // Magenta for cockpit
      if (color === '#888888') color = '#9d4edd'; // Purple for gray wings/parts
      if (color === '#aaaaaa') color = '#b388eb'; // Light purple for light gray parts
      if (color === '#222222') color = '#3a0d5c'; // Very dark purple for dark parts
    }

    // Create material with team-adjusted color
    const isTransparent = compData.type === 'cockpit';
    material = new THREE.MeshStandardMaterial({
      color: color,
      transparent: isTransparent,
      opacity: isTransparent ? 0.7 : 1.0,
      emissive: isTransparent ? color : 0x000000,
      emissiveIntensity: isTransparent ? 0.3 : 0
    });

    // Create geometry based on type
    switch(compData.type) {
      case 'box':
        geometry = new THREE.BoxGeometry(1, 1, 1);
        break;
      case 'cylinder':
        geometry = new THREE.CylinderGeometry(0.5, 0.5, 1, segments);
        break;
      case 'sphere':
        geometry = new THREE.SphereGeometry(0.5, segments, segments);
        break;
      case 'cone':
        geometry = new THREE.ConeGeometry(0.5, 1, segments);
        break;
      case 'torus':
        geometry = new THREE.TorusGeometry(0.5, 0.2, segments, segments * 2);
        break;
      case 'wing':
        geometry = new THREE.BoxGeometry(2, 4, 0.1);
        break;
      case 'engine':
        geometry = new THREE.CylinderGeometry(0.3, 0.35, 1, segments);
        break;
      case 'cockpit':
        geometry = new THREE.SphereGeometry(0.5, segments, segments);
        break;
      case 'missile':
        geometry = new THREE.CylinderGeometry(0.08, 0.08, 1.2, 8);
        break;
      default:
        console.warn('Unknown component type:', compData.type);
        return;
    }

    const mesh = new THREE.Mesh(geometry, material);

    // Apply transformations from the model
    mesh.position.set(compData.position.x, compData.position.y, compData.position.z);
    mesh.rotation.set(
      compData.rotation.x * Math.PI / 180,
      compData.rotation.y * Math.PI / 180,
      compData.rotation.z * Math.PI / 180
    );
    mesh.scale.set(compData.scale.x, compData.scale.y, compData.scale.z);

    group.add(mesh);
  });

  // Scale the entire group to fit the game
  group.scale.set(0.15, 0.15, 0.15);

  // Add engine exhaust cones (positioned at smaller cap of engine cylinders)
  // Engine geometry: CylinderGeometry(0.3, 0.35, 1), with rotation x=-90
  // The smaller end (radius 0.3) points toward -Z (tail)

  if (jet.id === 'green_0') {
    // User jet: 2 cones per engine (outer reddish transparent + inner yellow solid)
    // Left engine exhaust
    const exhaustOuterLeft = new THREE.Mesh(
      new THREE.ConeGeometry(0.3, 2, 8), // Base matches engine smaller cap
      new THREE.MeshStandardMaterial({
        color: 0xff3333,
        emissive: 0xff3333,
        emissiveIntensity: 1.5,
        transparent: true,
        opacity: 0.33,
        toneMapped: false
      })
    );
    exhaustOuterLeft.position.set(0.4, 0, -3.2); // Behind engine_left
    exhaustOuterLeft.rotation.set(-Math.PI / 2, 0, 0); // Point toward -Z
    exhaustOuterLeft.name = 'exhaustOuterLeft';
    group.add(exhaustOuterLeft);

    const exhaustInnerLeft = new THREE.Mesh(
      new THREE.ConeGeometry(0.15, 1.5, 8),
      new THREE.MeshStandardMaterial({
        color: 0xffff00,
        emissive: 0xffff00,
        emissiveIntensity: 3,
        toneMapped: false
      })
    );
    exhaustInnerLeft.position.set(0.4, 0, -3.2);
    exhaustInnerLeft.rotation.set(-Math.PI / 2, 0, 0);
    exhaustInnerLeft.name = 'exhaustInnerLeft';
    group.add(exhaustInnerLeft);

    // Right engine exhaust
    const exhaustOuterRight = new THREE.Mesh(
      new THREE.ConeGeometry(0.3, 2, 8),
      new THREE.MeshStandardMaterial({
        color: 0xff3333,
        emissive: 0xff3333,
        emissiveIntensity: 1.5,
        transparent: true,
        opacity: 0.33,
        toneMapped: false
      })
    );
    exhaustOuterRight.position.set(-0.4, 0, -3.2); // Behind engine_right
    exhaustOuterRight.rotation.set(-Math.PI / 2, 0, 0);
    exhaustOuterRight.name = 'exhaustOuterRight';
    group.add(exhaustOuterRight);

    const exhaustInnerRight = new THREE.Mesh(
      new THREE.ConeGeometry(0.15, 1.5, 8),
      new THREE.MeshStandardMaterial({
        color: 0xffff00,
        emissive: 0xffff00,
        emissiveIntensity: 3,
        toneMapped: false
      })
    );
    exhaustInnerRight.position.set(-0.4, 0, -3.2);
    exhaustInnerRight.rotation.set(-Math.PI / 2, 0, 0);
    exhaustInnerRight.name = 'exhaustInnerRight';
    group.add(exhaustInnerRight);
  } else {
    // Other jets: 1 yellow cone per engine
    const exhaustLeft = new THREE.Mesh(
      new THREE.ConeGeometry(0.3, 1.5, 3), // Low poly (3 segments)
      new THREE.MeshStandardMaterial({
        color: 0xffff00,
        emissive: 0xffff00,
        emissiveIntensity: 2,
        toneMapped: false
      })
    );
    exhaustLeft.position.set(0.4, 0, -3.2);
    exhaustLeft.rotation.set(-Math.PI / 2, 0, 0);
    exhaustLeft.name = 'exhaustLeft';
    group.add(exhaustLeft);

    const exhaustRight = new THREE.Mesh(
      new THREE.ConeGeometry(0.3, 1.5, 3),
      new THREE.MeshStandardMaterial({
        color: 0xffff00,
        emissive: 0xffff00,
        emissiveIntensity: 2,
        toneMapped: false
      })
    );
    exhaustRight.position.set(-0.4, 0, -3.2);
    exhaustRight.rotation.set(-Math.PI / 2, 0, 0);
    exhaustRight.name = 'exhaustRight';
    group.add(exhaustRight);
  }

  // Add explosion sphere effect (initially hidden, shown when wrecked)
  const explosionSphere = new THREE.Mesh(
    new THREE.SphereGeometry(1, 16, 16),
    new THREE.MeshStandardMaterial({
      color: 'orange',
      emissive: 'orange',
      emissiveIntensity: 4,
      transparent: true,
      opacity: 0.6,
      toneMapped: false
    })
  );
  explosionSphere.scale.set(3, 3, 3); // Spherical shape (reduced elongation)
  explosionSphere.name = 'explosionSphere';
  explosionSphere.visible = false; // Hidden by default
  group.add(explosionSphere);

  // For green_0 only: add camera arm and mount third-person camera
  if (jet.id === 'green_0') {
    // Create camera arm with origin at jetfighter center
    const cameraArm = new THREE.Group();
    cameraArm.name = 'cameraArm';
    cameraArm.position.set(0, 0, 0); // Origin at jetfighter center
    group.add(cameraArm); // Arm is child of jet mesh

    // Mount third-person camera on the arm at the end position
    if (thirdPersonCamera && !thirdPersonCamera.parent) {
      cameraArm.add(thirdPersonCamera); // Camera is child of arm
      thirdPersonCamera.position.set(0, 7, -15); // Camera at end of arm (behind and above)

      // Camera is "soldered" to the arm - no rotation needed
      // Camera looks in default direction, will inherit arm's rotation
      thirdPersonCamera.rotation.set(0, Math.PI, 0); // Look forward

      console.log('Third-person camera mounted on green_0 jet');
    }
  }

  return group;
}

function createTracerMesh(tracer) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.1, 0.1, 1.5, 8),
    new THREE.MeshStandardMaterial({ color: 'yellow', emissive: 'yellow', emissiveIntensity: 2 })
  );
  return mesh;
}

function createMissileMesh(missile) {
  const mesh = new THREE.Mesh(
    new THREE.CylinderGeometry(0.2, 0.2, 3, 8),
    new THREE.MeshStandardMaterial({ color: 'white', emissive: 'white', emissiveIntensity: 1 })
  );
  return mesh;
}

function createFlareMesh(flare) {
  const mesh = new THREE.Mesh(
    new THREE.SphereGeometry(0.3, 8, 8),
    new THREE.MeshStandardMaterial({ color: 'white', emissive: 'white', emissiveIntensity: 4 })
  );
  return mesh;
}

function createTargetMarker(color, scale = 5) {
  // Create 2D billboard diamond marker (flat diamond that always faces camera)
  const points = [
    new THREE.Vector3(0, scale, 0),      // Top
    new THREE.Vector3(scale, 0, 0),      // Right
    new THREE.Vector3(0, -scale, 0),     // Bottom
    new THREE.Vector3(-scale, 0, 0),     // Left
    new THREE.Vector3(0, scale, 0)       // Back to top to close the diamond
  ];

  const geometry = new THREE.BufferGeometry().setFromPoints(points);
  const material = new THREE.LineBasicMaterial({
    color: color,
    transparent: true,
    opacity: 0.9,
    linewidth: 2
  });

  const line = new THREE.Line(geometry, material);
  line.userData.isBillboard = true; // Mark as billboard for camera-facing behavior

  return line;
}
